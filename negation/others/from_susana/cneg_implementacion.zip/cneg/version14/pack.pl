:- use_module(dist,[dist/2]).

pack(X):-
	dist(X,1).


