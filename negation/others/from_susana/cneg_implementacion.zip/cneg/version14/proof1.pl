:- module(proof1,_,[.(pack1)]).
   
:- use_module(dist,[dist/2]).
    
p(X):- dist(X,1).

    