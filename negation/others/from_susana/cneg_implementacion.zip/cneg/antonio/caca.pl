stored_clauses(p(X),[a,X,c]).
