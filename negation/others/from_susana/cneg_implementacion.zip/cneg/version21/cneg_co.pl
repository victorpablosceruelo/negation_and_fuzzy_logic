:- use_package( assertions ).

:- use_module(engine(term_basic),[functor/3]).

:- use_module(engine(arithmetic)).

:- use_module(engine(atomic_basic)).

:- use_module(engine(attributes)).

:- use_module(engine(mattr_global)).

:- use_module(engine(basic_props)).

:- use_module(engine(basiccontrol)).

:- use_module(engine(data_facts)).

:- use_module(engine(exceptions)).

:- use_module(engine(io_aux)).

:- use_module(engine(io_basic)).

:- use_module(engine(prolog_flags)).

:- use_module(engine(streams_basic)).

:- use_module(engine(system_info)).

:- use_module(engine(term_basic)).

:- use_module(engine(term_compare)).

:- use_module(engine(term_typing)).

:- use_module(engine(hiord_rt),[call/1]).

:- use_module(engine(debugger_support),[srcdbg_spy/6]).

:- use_module(library(operators),[op/3]).

:- load_compilation_module(library(runtime_ops_tr)).

:- add_sentence_trans(runtime_op/2).

:- include(library(runtime_ops)).

:- load_compilation_module(library(dcg_expansion)).

:- add_sentence_trans(dcg_translation/2).

:- op(1200,xfx,[-->]).

:- initialization(op(1200,xfx,[-->])).

:- op(1100,xfy,'|').

:- initialization(op(1100,xfy,'|')).

:- include(library(dcg)).

:- use_module(library(default_predicates)).

:- meta_predicate cneg(goal).

:- meta_predicate stored_pred(goal,?).

:- use_module(library(lists),[append/3]).

:- use_module(library(idlists),[memberchk/2]).

:- use_module(library(aggregates),[setof/3]).

:- use_module(engine(internals),[term_to_meta/2]).

:- use_module(library(terms_vars),[varset/2,varsbag/3]).

:- data stored_clause/2.

:- data stored_pred/2.

cneg(true) :-
        !,
        fail.
cneg('basiccontrol:fail') :- !.
cneg(Meta) :-
        term_to_meta(Goal,Meta),
        user:compound_to_term(Goal,Term),
        varset(Term,GoalVars),
        user:cneg_auxiliar(Term,GoalVars,[]).

cneg_auxiliar(Goal,GoalVarsI,UnivVars) :-
        user:cneg_aux(Goal,GoalVarsI,UnivVars),
        user:put_universal(UnivVars).

cneg_aux(Goal,GoalVarsI,UnivVars) :-
        varset(GoalVarsI,GoalVars),
        user:no_unifications(GoalVars,UnivVars),
        user:frontier(Goal,Frontier),
        user:negate_conj_frontier(Frontier,Goal,GoalVars,UnivVars,LSolutions),
        user:no_unifications(UnivVars,UnivVars),
        user:combine(LSolutions),
        varset(LSolutions,VarsSol),
        user:no_unifications(VarsSol,UnivVars).

rm_cons_fA([],[]).
rm_cons_fA([V|Vars],[V|Vars1]) :-
        var(V),
        !,
        user:rm_cons_fA(Vars,Vars1).
rm_cons_fA([fA(V)|Vars],[V|Vars1]) :-
        !,
        user:rm_cons_fA(Vars,Vars1).

put_universal([]).
put_universal([Var|UnivVars]) :-
        var(Var),
        !,
        Var=fA(_NewVar),
        user:put_universal(UnivVars).
put_universal([_Value|UnivVars]) :-
        user:put_universal(UnivVars).

compound_to_term((M1;M2),(G1;G2)) :-
        !,
        user:compound_to_term(M1,G1),
        user:compound_to_term(M2,G2).
compound_to_term((M1,M2),(G1,G2)) :-
        !,
        user:compound_to_term(M1,G1),
        user:compound_to_term(M2,G2).
compound_to_term('basiccontrol:;'(M1,M2),(G1;G2)) :-
        !,
        user:compound_to_term(M1,G1),
        user:compound_to_term(M2,G2).
compound_to_term('basiccontrol:,'(M1,M2),(G1,G2)) :-
        !,
        user:compound_to_term(M1,G1),
        user:compound_to_term(M2,G2).
compound_to_term(T,T) :-
        user:is_eq_diseq(T),
        !.
compound_to_term(T,G) :-
        term_to_meta(T,M),
        user:stored_pred(M,G),
        !.

is_eq_diseq(dist(_1,_2)).
is_eq_diseq(_1=_2).

frontier((G1;G2),Frontier) :-
        !,
        user:frontier(G1,F1),
        user:frontier(G2,F2),
        append(F1,F2,Front),
        user:filter_frontier(Front,(G1;G2),Frontier1),
        user:simple_frontier(Frontier1,Frontier).
frontier((G1,G2),Frontier) :-
        !,
        user:frontier(G1,F1),
        user:frontier(G2,F2),
        user:conjunction(F1,F2,Front),
        user:filter_frontier(Front,(G1,G2),Frontier1),
        user:simple_frontier(Frontier1,Frontier).
frontier(dist(X,Y),[(dist(X,Y),[dist(X,Y)])]) :- !.
frontier(X=_Y,[(X=X,[])]) :- !.
frontier(Goal,Frontier) :-
        setof((Goal,Body),user:stored_clause(Goal,Body),Front),
        !,
        user:simple_frontier(Front,Frontier).
frontier(_Goal,[]).

filter_frontier([],_G,[]).
filter_frontier([(H,B)|Front],G,[(H1,B1)|Frontier]) :-
        copy_term((H,B),(H1,B1)),
        copy_term(G,G1),
        G1=H1,
        !,
        user:filter_frontier(Front,G,Frontier).
filter_frontier([(_H,_B)|Front],G,Frontier) :-
        user:filter_frontier(Front,G,Frontier).

simple_frontier([],[]).
simple_frontier([(H,B)|Front],Frontier) :-
        user:simple_body(B,B1),
        user:simple_frontier(Front,Frontier1),
        user:'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1).

'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1) :-
        B1==fail,
        !,
        Frontier=Frontier1.
'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1) :-
        Frontier=[(H,B1)|Frontier1].