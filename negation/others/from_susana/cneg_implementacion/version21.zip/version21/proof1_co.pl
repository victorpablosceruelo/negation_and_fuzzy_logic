:- module(_proof1,[stored_clause/2,stored_pred/2,cneg/1,cneg_auxiliar/3,cneg_aux/3,rm_cons_fA/2,put_universal/1,compound_to_term/2,is_eq_diseq/1,frontier/2,filter_frontier/3,simple_frontier/2,simple_body/2,conjunction/3,distributive/3,conj_clauses/3,negate_conj_frontier/5,negate_conj/5,varset_order/2,organization_conj/6,unifications_nonGoalvars/2,get_eq_head/3,organization_body/4,detach_attribute_all/1,detach_att_if_needed1/1,organization_body_diseq/6,organization_body_diseq_aux/6,replace_dist/2,remove_duplicates/2,obtain_diseq/2,normalization_conj/10,difference/3,union/3,eliminate_redundant_var/8,eliminate_repeated_eq/2,eliminate_irrelevant_disequalities/4,negation_conj/8,rm_redundant_eqs/3,eq_useful/2,asigned_vars/3,divide_formula/4,negation_formula/9,negation_formula1/7,negate_I/3,negate_eq/3,new_Vars/2,replace/4,replace_all/4,replace_list/4,negate_Dimp/2,negate_Rimp/2,negate_Dexp_Rexp/4,get_conjunction/2,combine/1,call_all/1,no_unifications/2,no_unify/2,check_is_true/2,check_all_true/2,simple_disj_true/2,skolem/3,skolem_term/3,unify_neg_disj/1,dc/2,dc2/3,dc3/4,check_desig/3,p/3],ciaopp).

:- meta_predicate cneg(goal).

:- meta_predicate stored_pred(goal,?).

:- use_module(library(lists),[append/3]).

:- use_module(library(idlists),[memberchk/2]).

:- use_module(library(aggregates),[setof/3]).

:- use_module(engine(internals),[term_to_meta/2]).

:- use_module(library(terms_vars),[varset/2,varsbag/3]).

:- data stored_clause/2.

:- data stored_pred/2.

cneg(true) :-
        !,
        fail.

cneg(fail) :- !.

cneg(Meta) :-
        term_to_meta(Goal,Meta),
        compound_to_term(Goal,Term),
        varset(Term,GoalVars),
        cneg_auxiliar(Term,GoalVars,[]).

cneg_auxiliar(Goal,GoalVarsI,UnivVars) :-
        cneg_aux(Goal,GoalVarsI,UnivVars),
        put_universal(UnivVars).

cneg_aux(Goal,GoalVarsI,UnivVars) :-
        varset(GoalVarsI,GoalVars),
        no_unifications(GoalVars,UnivVars),
        frontier(Goal,Frontier),
        negate_conj_frontier(Frontier,Goal,GoalVars,UnivVars,LSolutions),
        no_unifications(UnivVars,UnivVars),
        combine(LSolutions),
        varset(LSolutions,VarsSol),
        no_unifications(VarsSol,UnivVars).

rm_cons_fA([],[]).

rm_cons_fA([V|Vars],[V|Vars1]) :-
        var(V),
        !,
        rm_cons_fA(Vars,Vars1).

rm_cons_fA([fA(V)|Vars],[V|Vars1]) :-
        !,
        rm_cons_fA(Vars,Vars1).

put_universal([]).

put_universal([Var|UnivVars]) :-
        var(Var),
        !,
        Var=fA(_NewVar),
        put_universal(UnivVars).

put_universal([_Value|UnivVars]) :-
        put_universal(UnivVars).

compound_to_term((M1;M2),(G1;G2)) :-
        !,
        compound_to_term(M1,G1),
        compound_to_term(M2,G2).

compound_to_term((M1,M2),(G1,G2)) :-
        !,
        compound_to_term(M1,G1),
        compound_to_term(M2,G2).

compound_to_term(T,T) :-
        is_eq_diseq(T),
        !.

compound_to_term(T,G) :-
        term_to_meta(T,M),
        stored_pred(M,G),
        !.

is_eq_diseq(dist(_1,_2)).

is_eq_diseq(_1=_2).

frontier((G1;G2),Frontier) :-
        !,
        frontier(G1,F1),
        frontier(G2,F2),
        append(F1,F2,Front),
        filter_frontier(Front,(G1;G2),Frontier1),
        simple_frontier(Frontier1,Frontier).

frontier((G1,G2),Frontier) :-
        !,
        frontier(G1,F1),
        frontier(G2,F2),
        conjunction(F1,F2,Front),
        filter_frontier(Front,(G1,G2),Frontier1),
        simple_frontier(Frontier1,Frontier).

frontier(dist(X,Y),[(dist(X,Y),[dist(X,Y)])]) :- !.

frontier(X=_Y,[(X=X,[])]) :- !.

frontier(Goal,Frontier) :-
        setof((Goal,Body),stored_clause(Goal,Body),Front),
        !,
        simple_frontier(Front,Frontier).

frontier(_Goal,[]).

filter_frontier([],_G,[]).

filter_frontier([(H,B)|Front],G,[(H1,B1)|Frontier]) :-
        copy_term((H,B),(H1,B1)),
        copy_term(G,G1),
        G1=H1,
        !,
        filter_frontier(Front,G,Frontier).

filter_frontier([(_H,_B)|Front],G,Frontier) :-
        filter_frontier(Front,G,Frontier).

simple_frontier([],[]).

simple_frontier([(H,B)|Front],Frontier) :-
        simple_body(B,B1),
        simple_frontier(Front,Frontier1),
        'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1).

'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1) :-
        B1==fail,
        !,
        Frontier=Frontier1.

'simple_frontier/2/2/$disj/1'(Frontier,H,B1,Frontier1) :-
        Frontier=[(H,B1)|Frontier1].

simple_body([],[]).

simple_body([Goal|Body],B1) :-
        ground(Goal),
        call(Goal),
        !,
        simple_body(Body,B1).

simple_body([Goal|_Body],fail) :-
        ground(Goal),
        !.

simple_body([Goal|Body],B) :-
        simple_body(Body,B1),
        'simple_body/2/4/$disj/1'(B,Goal,B1).

'simple_body/2/4/$disj/1'(B,Goal,B1) :-
        B1==fail,
        !,
        B=fail.

'simple_body/2/4/$disj/1'(B,Goal,B1) :-
        B=[Goal|B1].

conjunction([],_F2,[]) :- !.

conjunction([Conj|F1],F2,F5) :-
        distributive(F2,Conj,F3),
        conjunction(F1,F2,F4),
        append(F3,F4,F5).

distributive([],_Conj,[]).

distributive([Conj2|L],Conj1,[Conj3|L3]) :-
        conj_clauses(Conj1,Conj2,Conj3),
        distributive(L,Conj1,L3).

conj_clauses((H1,B1),(H2,B2),((H1,H2),B3)) :-
        append(B1,B2,B3).

negate_conj_frontier([],_Goal,_GoalVars,_UnivVars,[]).

negate_conj_frontier([Conj|Frontier],Goal,GoalVars,UnivVars,[SolConj|LSolutions]) :-
        negate_conj(Conj,Goal,GoalVars,UnivVars,SolConj),
        negate_conj_frontier(Frontier,Goal,GoalVars,UnivVars,LSolutions).

negate_conj(C,G,GoalVars,_UnivVars,[]) :-
        organization_conj(C,G,GoalVars,[fail],_D,_R),
        !.

negate_conj(C,G,GoalVars,UnivVars,SolC) :-
        organization_conj(C,G,GoalVars,I,D,R),
        'negate_conj/5/2/$disj/1'(G,GoalVars,UnivVars,SolC,I,D,R).

'negate_conj/5/2/$disj/1'(G,GoalVars,UnivVars,SolC,I,D,R) :-
        I=[],
        D=[],
        R=[],
        !,
        fail.

'negate_conj/5/2/$disj/1'(G,GoalVars,UnivVars,SolC,I,D,R) :-
        varset(G,NowGoalVars),
        normalization_conj(I,D,R,GoalVars,NowGoalVars,In,Dn,Rn,ImpVars,ExpVars),
        negation_conj(In,Dn,Rn,GoalVars,ImpVars,ExpVars,UnivVars,SolC).

varset_order(Term,Vars) :-
        varsbag(Term,VarsDup,[]),
        remove_duplicates(VarsDup,Vars).

organization_conj((Head,BodyList),G,_GoalVars,I,D,R) :-
        copy_term(G,G1),
        copy_term(Head,Head1),
        varset_order(G1,GoalVars1),
        varset_order(G,GVars),
        varset_order(Head,HeadVars),
        varset_order(Head1,HeadVars1),
        setof(GoalVars1,G1=Head1,[Values]),
        !,
        unifications_nonGoalvars(HeadVars1,HeadVars),
        'organization_conj/6/1/$disj/1'(I,D,R,BodyList,GVars,HeadVars,HeadVars1,Values).

organization_conj((_Head,BodyList),_G,_GoalVars,I,D,R) :-
        organization_body(BodyList,I,D,R).

'organization_conj/6/1/$disj/1'(I,D,R,BodyList,GVars,HeadVars,HeadVars1,Values) :-
        Values=[],
        !,
        organization_body(BodyList,I,D,R).

'organization_conj/6/1/$disj/1'(I,D,R,BodyList,GVars,HeadVars,HeadVars1,Values) :-
        replace_list(HeadVars1,HeadVars,Values,Values1),
        get_eq_head(GVars,Values1,Ih),
        organization_body(BodyList,Ib,D,R),
        'organization_conj/6/1/$disj/1/8/2/$disj/1'(I,Ih,Ib).

'organization_conj/6/1/$disj/1/8/2/$disj/1'(I,Ih,Ib) :-
        Ib==[fail],
        !,
        I=Ib.

'organization_conj/6/1/$disj/1/8/2/$disj/1'(I,Ih,Ib) :-
        append(Ih,Ib,I).

unifications_nonGoalvars([],[]).

unifications_nonGoalvars([Value|HeadVars1],[_Var|HeadVars]) :-
        var(Value),
        !,
        unifications_nonGoalvars(HeadVars1,HeadVars).

unifications_nonGoalvars([Value|HeadVars1],[Var|HeadVars]) :-
        Var=Value,
        unifications_nonGoalvars(HeadVars1,HeadVars).

get_eq_head([],[],[]).

get_eq_head([Var|GoalVars],[X|Vs],[Var=X|I]) :-
        get_eq_head(GoalVars,Vs,I).

organization_body([],[],[],[]).

organization_body([T1=T2|BodyList],I,D,R) :-
        varset_order(T1,T1Vars),
        varset_order(T2,T2Vars),
        append(T1Vars,T2Vars,T12Vars),
        remove_duplicates(T12Vars,Vars),
        setof(Vars,T1=T2,[Values]),
        !,
        'organization_body/4/2/$disj/1'(I,D,R,BodyList,Vars,Values).

organization_body([_T1=_T2|_BodyList],[fail],_D,_R) :- !.

organization_body([dist(T1,T2)|BodyList],I,D,R) :-
        varset_order(dist(T1,T2),VarsI),
        copy_term(dist(T1,T2),DNew),
        varset_order(DNew,VarsNew),
        detach_attribute_all(VarsNew),
        remove_duplicates(VarsNew,Vars),
        setof(VarsNew,DNew,Values),
        !,
        'organization_body/4/4/$disj/1'(I,D,R,BodyList,VarsI,VarsNew,Vars,Values).

organization_body([dist(_T1,_T2)|_BodyList],[fail],_D,_R) :- !.

organization_body([Other|BodyList],I,D,[Other|R]) :-
        organization_body(BodyList,I,D,R).

'organization_body/4/2/$disj/1'(I,D,R,BodyList,Vars,Values) :-
        Values=[],
        !,
        organization_body(BodyList,I,D,R).

'organization_body/4/2/$disj/1'(I,D,R,BodyList,Vars,Values) :-
        get_eq_head(Vars,Values,Ih),
        organization_body(BodyList,Ib,D,R),
        append(Ih,Ib,I).

'organization_body/4/4/$disj/1'(I,D,R,BodyList,VarsI,VarsNew,Vars,Values) :-
        Values=[[]],
        !,
        organization_body(BodyList,I,D,R).

'organization_body/4/4/$disj/1'(I,D,R,BodyList,VarsI,VarsNew,Vars,Values) :-
        organization_body_diseq(Values,Vars,BodyList,I1,D1,R1),
        replace_list(VarsNew,VarsI,(I1,D1,R1),(I,D,R)).

detach_attribute_all([]).

detach_attribute_all([V|Vars]) :-
        detach_att_if_needed1(V),
        detach_attribute_all(Vars).

detach_att_if_needed1(Var) :-
        get_attribute(Var,_1),
        !,
        detach_attribute(Var).

detach_att_if_needed1(_1).

organization_body_diseq([],_Vars,BodyList,I,D,R) :-
        !,
        organization_body(BodyList,I,D,R).

organization_body_diseq(Values,Vars,BodyList,I,D,R) :-
        member(ValueVars,Values),
        organization_body_diseq_aux(ValueVars,Vars,BodyList,I,D,R).

organization_body_diseq_aux([V|ValueVars],Vars,BodyList,I,D,R) :-
        obtain_diseq(V,D1),
        replace_list([V|ValueVars],Vars,D1,Dh),
        replace_dist(Dh,Daux),
        organization_body(BodyList,I,Db,R),
        append(Daux,Db,D).

replace_dist([],[]).

replace_dist([X/Y|List],[dist(X,Y)|ListD]) :-
        replace_dist(List,ListD).

remove_duplicates([],[]).

remove_duplicates([X|L1],L2) :-
        memberchk(X,L1),
        !,
        remove_duplicates(L1,L2).

remove_duplicates([X|L1],[X|L2]) :-
        remove_duplicates(L1,L2).

obtain_diseq(Value,D) :-
        get_attribute(Value,formula(Value,Form)),
        member(D,Form).

normalization_conj(I,D,R,GoalVars,_NowGoalVars,I1,D1,Rv,ImpVars,ExpVars) :-
        eliminate_redundant_var(I,D,R,GoalVars,[],Iv,Dv,Rv),
        eliminate_repeated_eq(Iv,I1),
        varset(I1,IVars),
        union(IVars,GoalVars,ImpVars),
        varset(Rv,RVars),
        difference(RVars,ImpVars,ExpVars),
        difference(RVars,GoalVars,RelVars),
        eliminate_irrelevant_disequalities(Dv,ImpVars,RelVars,D1).

difference([],_NFVars,[]).

difference([Var|Vars],NFVars,FreeVars) :-
        memberchk(Var,NFVars),
        !,
        difference(Vars,NFVars,FreeVars).

difference([Var|Vars],NFVars,[Var|FreeVars]) :-
        difference(Vars,NFVars,FreeVars).

union([],Vars2,Vars2).

union([Var|Vars1],Vars2,Vars) :-
        memberchk(Var,Vars2),
        !,
        union(Vars1,Vars2,Vars).

union([Var|Vars1],Vars2,[Var|Vars]) :-
        union(Vars1,Vars2,Vars).

eliminate_redundant_var([],D,R,_GoalVars,Iac,Iac,D,R).

eliminate_redundant_var([Var=Value|I],D,R,GoalVars,Iac,Iv,Dv,Rv) :-
        var(Var),
        \+memberchk(Var,GoalVars),
        !,
        replace((Iac,I,D,R),Var,Value,(Iac1,I1,D1,R1)),
        eliminate_redundant_var(I1,D1,R1,GoalVars,Iac1,Iv,Dv,Rv).

eliminate_redundant_var([Var=Value|I],D,R,GoalVars,Iac,Iv,Dv,Rv) :-
        var(Value),
        \+memberchk(Value,GoalVars),
        !,
        replace((Iac,I,D,R),Value,Var,(Iac1,I1,D1,R1)),
        eliminate_redundant_var(I1,D1,R1,GoalVars,Iac1,Iv,Dv,Rv).

eliminate_redundant_var([Var=Value|I],D,R,GoalVars,Iac,Iv,Dv,Rv) :-
        eliminate_redundant_var(I,D,R,GoalVars,[Var=Value|Iac],Iv,Dv,Rv).

eliminate_repeated_eq([],[]).

eliminate_repeated_eq([X=Y|L1],L2) :-
        X==Y,
        !,
        eliminate_repeated_eq(L1,L2).

eliminate_repeated_eq([X=Y|L1],L2) :-
        memberchk(X=Y,L1),
        !,
        eliminate_repeated_eq(L1,L2).

eliminate_repeated_eq([X=Y|L1],L2) :-
        memberchk(Y=X,L1),
        !,
        eliminate_repeated_eq(L1,L2).

eliminate_repeated_eq([E|L1],[E|L2]) :-
        eliminate_repeated_eq(L1,L2).

eliminate_irrelevant_disequalities([],_ImpVars,_RelVars,[]).

eliminate_irrelevant_disequalities([Diseq|D],ImpVars,RelVars,D1) :-
        varset(Diseq,Vars),
        member(V,Vars),
        \+memberchk(V,ImpVars),
        \+memberchk(V,RelVars),
        !,
        eliminate_irrelevant_disequalities(D,ImpVars,RelVars,D1).

eliminate_irrelevant_disequalities([Diseq|D],ImpVars,RelVars,[Diseq|D1]) :-
        eliminate_irrelevant_disequalities(D,ImpVars,RelVars,D1).

negation_conj(I,D,R,GoalVars,ImpVars,ExpVars,UnivVars,SolC) :-
        divide_formula(D,ExpVars,Dimp,Dexp),
        divide_formula(R,ExpVars,Rimp,Rexp),
        copy_term(UnivVars,ExistVars),
        replace_list(UnivVars,ExistVars,(Dexp,Rexp),(Dexp1,Rexp1)),
        varset((Dimp,Dexp1,Rimp,Rexp1),VarsRest),
        union(VarsRest,GoalVars,VarsImportant),
        rm_redundant_eqs(I,VarsImportant,I1),
        negation_formula(I1,Dimp,Dexp1,GoalVars,Rimp,Rexp1,ImpVars,ExpVars,SolC).

rm_redundant_eqs([],_VarsRest,[]).

rm_redundant_eqs([Eq|I],VarsRest,[Eq|I1]) :-
        eq_useful(Eq,VarsRest),
        !,
        rm_redundant_eqs(I,VarsRest,I1).

rm_redundant_eqs([_Eq|I],VarsRest,I1) :-
        rm_redundant_eqs(I,VarsRest,I1).

eq_useful(X=Y,VarsRest) :-
        memberchk(X,VarsRest),
        memberchk(Y,VarsRest).

eq_useful(Eq,VarsRest) :-
        copy_term((Eq,VarsRest),(Eq1,VarsRest1)),
        varset(Eq1,Vars),
        setof(Vars,Eq1,[Values]),
        asigned_vars(Vars,Values,VarsAsig),
        member(Var,VarsAsig),
        memberchk(Var,VarsRest1).

asigned_vars([],_Values,[]).

asigned_vars([_Var|Vars],[Value|Values],VarsAsig) :-
        var(Value),
        !,
        asigned_vars(Vars,Values,VarsAsig).

asigned_vars([Var|Vars],[_Value|Values],[Var|VarsAsig]) :-
        asigned_vars(Vars,Values,VarsAsig).

divide_formula([],_ExpVars,[],[]).

divide_formula([Term|F],ExpVars,Fimp,[Term|Fexp]) :-
        varset(Term,Vars),
        member(V,Vars),
        memberchk(V,ExpVars),
        !,
        divide_formula(F,ExpVars,Fimp,Fexp).

divide_formula([Term|F],ExpVars,[Term|Fimp],Fexp) :-
        divide_formula(F,ExpVars,Fimp,Fexp).

negation_formula(I,_Dimp,_Dexp,GoalVars,_Rimp,_Rexp,_ImpV,_ExpV,[Sol]) :-
        negate_I(I,GoalVars,Sol).

negation_formula(I,Dimp,_Dexp,_GoalVars,_Rimp,_Rexp,_ImpV,_ExpV,SolC) :-
        negate_Dimp(Dimp,Sol),
        append(I,Sol,SolC).

negation_formula(I,Dimp,Dexp,_GoalVars,Rimp,Rexp,ImpVars,ExpsVars,SolC) :-
        append(I,Dimp,I_Dimp),
        negation_formula1(I_Dimp,Dexp,Rimp,Rexp,ImpVars,ExpsVars,SolC).

negation_formula1(I_Dimp,_Dexp,Rimp,_Rexp,_ImpsV,_ExpsV,SolC) :-
        negate_Rimp(Rimp,Sol),
        append(I_Dimp,Sol,SolC).

negation_formula1(I_Dimp,Dexp,Rimp,Rexp,ImpVars,ExpVars,SolC) :-
        append(I_Dimp,Rimp,I_Dimp_Rimp),
        append(Dexp,Rexp,DRexp),
        negate_Dexp_Rexp(DRexp,ImpVars,ExpVars,Sol),
        append(I_Dimp_Rimp,Sol,SolC).

negate_I(I,GoalVars,Sol) :-
        member(Eq,I),
        negate_eq(Eq,GoalVars,Sol).

negate_eq(T1=T2,GoalVars,dist(Tn1,Tn2)) :-
        varset(T1=T2,Vars),
        difference(Vars,GoalVars,FreeVars),
        new_Vars(FreeVars,UnivVars),
        put_universal(UnivVars),
        replace_list(FreeVars,UnivVars,(T1,T2),(Tn1,Tn2)).

new_Vars([],[]).

new_Vars([_Term|R],[_New|N]) :-
        new_Vars(R,N).

replace(Term,Var,Value,Value) :-
        Term==Var,
        !.

replace(Term,Var,_Value,Term) :-
        var(Term),
        Term\==Var,
        !.

replace(Term,Var,Value,Term1) :-
        Term=..[Functor|Args],
        replace_all(Args,Var,Value,Args1),
        Term1=..[Functor|Args1].

replace_all([],_1,_2,[]).

replace_all([Arg|Rest],Var,Value,[Arg1|Rest1]) :-
        replace(Arg,Var,Value,Arg1),
        replace_all(Rest,Var,Value,Rest1).

replace_list([],[],Term,Term).

replace_list([Var|LVars],[Value|LValues],Term1,Term2) :-
        var(Var),
        !,
        replace(Term1,Var,Value,TermAux),
        replace_list(LVars,LValues,TermAux,Term2).

replace_list([_Var|LVars],[_Value|LValues],Term1,Term2) :-
        replace_list(LVars,LValues,Term1,Term2).

negate_Dimp([dist(T1,T2)|_Dimp],[T1=T2]).

negate_Dimp([D|Dimp],[D|SolC]) :-
        negate_Dimp(Dimp,SolC).

negate_Rimp([R|_Rimp],[cneg(R)]).

negate_Rimp([R|Rimp],[R|SolC]) :-
        negate_Rimp(Rimp,SolC).

negate_Dexp_Rexp([],_1,_2,_3) :-
        !,
        fail.

negate_Dexp_Rexp(DRexp,ImpVs,ExpVs,[cneg_aux(DR,ImpVs,ExpVs)]) :-
        get_conjunction(DRexp,DR).

get_conjunction([X],X).

get_conjunction([X|L],(X,C)) :-
        get_conjunction(L,C).

combine([]).

combine([Sol|Rest]) :-
        call_all(Sol),
        combine(Rest).

call_all([]).

call_all([G|L]) :-
        call(G),
        call_all(L).

no_unifications([],_UnivVars).

no_unifications([Var|Vars],UnivVars) :-
        no_unify(Var,UnivVars),
        no_unifications(Vars,UnivVars).

no_unify(Var,UnivVars) :-
        var(Var),
        get_attribute(Var,Attribute),
        !,
        check_is_true(Attribute,UnivVars).

no_unify(Var,_UnivVars) :-
        var(Var),
        !.

check_is_true(formula(_Var,true),_UnivVars) :- !.

check_is_true(formula(_Var,fail),_UnivVars) :-
        !,
        fail.

check_is_true(formula(_Var,[]),_UnivVars) :- !.

check_is_true(formula(_Var,[Conj]),UnivVars) :-
        varset(Conj,Vars),
        member(Var1,Vars),
        memberchk(Var1,UnivVars),
        !,
        fail.

check_is_true(formula(_Var,[Conj]),_UnivVars) :-
        member(Diseq,Conj),
        check_desig(Diseq,_VarfA,_T),
        !,
        fail.

check_is_true(formula(_Var,F),UnivVars) :-
        dc(F,Lc),
        check_all_true(Lc,UnivVars).

check_all_true([],_UnivVars).

check_all_true([Disj|Lc],UnivVars) :-
        simple_disj_true(Disj,UnivVars),
        check_all_true(Lc,UnivVars).

simple_disj_true(Disj,UnivVars) :-
        skolem(Disj,SkDisj,UnivVars),
        \+unify_neg_disj(SkDisj).

skolem([],[],_UnivVars).

skolem([Diseq|Disj],[SkDiseq|SkDisj],UnivVars) :-
        skolem_term(Diseq,SkDiseq,UnivVars),
        skolem(Disj,SkDisj,UnivVars).

skolem_term(Term,Term,_UnivVars) :-
        ground(Term),
        !.

skolem_term(Var,Var,UnivVars) :-
        var(Var),
        memberchk(Var,UnivVars),
        !.

skolem_term(Term,$(_1),_UnivVars) :-
        var(Term),
        !.

skolem_term(fA(Var),Var,_UnivVars) :-
        var(Var),
        !.

skolem_term(Term,Term1,UnivVars) :-
        Term=..[Functor|Args],
        skolem(Args,Args1,UnivVars),
        Term1=..[Functor|Args1].

unify_neg_disj([]).

unify_neg_disj([T1/_T2|_DisjExist]) :-
        nonvar(T1),
        T1= $(_N),
        !,
        fail.

unify_neg_disj([_T1/T2|_DisjExist]) :-
        nonvar(T2),
        T2= $(_N),
        !,
        fail.

unify_neg_disj([T1/T2|DisjExist]) :-
        T1=T2,
        unify_neg_disj(DisjExist).

dc([],[[]]).

dc([L1|Ls],Lds) :-
        dc(Ls,Lda),
        dc2(L1,Lda,Lds).

dc2([],_1,[]).

dc2([X|Xs],Lda,Lds) :-
        dc3(Lda,X,Lds,Lds_),
        dc2(Xs,Lda,Lds_).

dc3([],_X,Lds,Lds).

dc3([L|Ls],X,[[X|L]|XLs],Lds_) :-
        dc3(Ls,X,XLs,Lds_).

check_desig(T1/T2,Var,T2) :-
        nonvar(T1),
        T1=fA(Var).

check_desig(T1/T2,Var,T1) :-
        nonvar(T2),
        T2=fA(Var).

:- use_module(dist).

p(a,b,c).

p(b,a,c).

p(c,a,b).

stored_clause(p(a,b,c),[]).

stored_clause(p(b,a,c),[]).

stored_clause(p(c,a,b),[]).

stored_pred(p(_1,_2,_3),p(_1,_2,_3)).

stored_pred(p(_1,_2,_3),p(_1,_2,_3)).

stored_pred(p(_1,_2,_3),p(_1,_2,_3)).

stored_pred('dist:dist'(_1,_2),dist(_1,_2)).

