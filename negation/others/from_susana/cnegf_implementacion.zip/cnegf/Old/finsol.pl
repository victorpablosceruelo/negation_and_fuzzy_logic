% compilation module that contains the predicate in_cnegf/3
:- load_compilation_module(.(neg_tr)).

:- add_sentence_trans(in_cnegf/3).


