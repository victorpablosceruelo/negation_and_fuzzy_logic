:- module(_qsort1_typesfd_shfr_upper_nf_co_new,[neq_list/2,qsort/2,finite/2],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- include(library(assertions)).

:- use_module(library('assertions/native_props')).

:- include(library(nativeprops)).

:- redefining(indep/1).

:- redefining(indep/2).

:- op(950,xf,[&]).

:- op(975,xfx,[=>]).

:- use_module(library('andprolog/andprolog_rt')).

:- include(library(cges)).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- data finite/2.

:- trust success neg(_97448).

:- true pred neq_list(_97599,_97616)
         : ( list(_97599,num), list(_97616,num) )
        => ( list(_97599,num), list(_97616,num) )
         + ( possibly_fails(neq_list(_97599,_97616)), covered(neq_list(_97599,_97616)) ).

:- true pred neq_list(_98084,_98101)
         : ( ground(_98084), ground(_98101) )
        => ( ground(_98084), ground(_98101) ).

:- entry neq_list(_98439,_98458)
         : ( list(_98439,num), list(_98458,num), ground(_98439), ground(_98458) ).

neq_list(_98787,_98806) :-
        qsort(_98787,_98861),
        neg(qsort(_98806,_98861)).

:- true pred qsort(_99083,_99100)
         : ( list(_99083,num), var(_99100) )
        => ( list(_99083,num), list(_99100,num), size_ub(_99083,length(_99083)), size_ub(_99100,exp(2,length(_99083))-1.0) )
         + ( not_fails(qsort(_99083,_99100)), covered(qsort(_99083,_99100)), steps_ub(qsort(_99083,_99100),sum($(j),1,length(_99083),exp(2,length(_99083)- $(j))* $(j))+exp(2,length(_99083)-1)*length(_99083)+2.0*exp(2,length(_99083))-1.0) ).

finite(qsort,2).

:- true pred qsort(_100350,_100367)
         : ( ground(_100350), var(_100367), mshare([[_100367]]) )
        => ( ground(_100350), ground(_100367) ).

:- entry qsort(_100745,_100762)
         : ( list(_100745,num), var(_100762), ground(_100745) ).

qsort([_101020|_101037],_101056) :-
        partition(_101037,_101020,_101125,_101144),
        qsort(_101144,_101193),
        qsort(_101125,_101242),
        append(_101242,[_101020|_101193],_101056).

qsort([],[]).

:- true pred partition(_101614,_101631,_101648,_101665)
         : ( list(_101614,num), num(_101631), var(_101648), var(_101665) )
        => ( list(_101614,num), num(_101631), list(_101648,num), list(_101665,num), size_ub(_101614,length(_101614)), size_ub(_101631,int(_101631)), size_ub(_101648,length(_101614)), size_ub(_101665,length(_101614)) )
         + ( not_fails(partition(_101614,_101631,_101648,_101665)), covered(partition(_101614,_101631,_101648,_101665)), steps_ub(partition(_101614,_101631,_101648,_101665),length(_101614)+1) ).

finite(partition,4).

:- true pred partition(_102683,_102700,_102717,_102734)
         : ( ground(_102683), ground(_102700), var(_102717), var(_102734), mshare([[_102717],[_102734]]), indep(_102717,_102734) )
        => ( ground(_102683), ground(_102700), ground(_102717), ground(_102734) ).

partition([],_103333,[],[]).

partition([_103464|_103481],_103500,[_103464|_103529],_103556) :-
        _103464<_103500,
        !,
        partition(_103481,_103500,_103529,_103556).

partition([_103841|_103858],_103877,_103894,[_103841|_103929]) :-
        _103841>=_103877,
        partition(_103858,_103877,_103894,_103929).

:- true pred append(_104235,_104252,_104269)
         : ( list(_104235,num), list1(_104252,num), var(_104269) )
        => ( list(_104235,num), list1(_104252,num), list1(_104269,num), size_ub(_104235,length(_104235)), size_ub(_104252,length(_104252)), size_ub(_104269,length(_104252)+length(_104235)) )
         + ( not_fails(append(_104235,_104252,_104269)), covered(append(_104235,_104252,_104269)), steps_ub(append(_104235,_104252,_104269),length(_104235)+1) ).

finite(append,3).

:- true pred append(_105209,_105226,_105243)
         : ( ground(_105209), ground(_105226), var(_105243), mshare([[_105243]]) )
        => ( ground(_105209), ground(_105226), ground(_105243) ).

append([],_105690,_105690).

append([_105804|_105821],_105840,[_105804|_105869]) :-
        append(_105821,_105840,_105869).

:- true pred finite(_106087,_106104)
         : ( term(_106087), term(_106104) )
        => ( term(_106087), term(_106104) ).

:- true pred finite(_106432,_106449)
         : mshare([[_106432],[_106432,_106449],[_106449]])
         + fails(finite(_106432,_106449)).

:- regtype t217/1.

t217(qsort(_106855,_106872)) :-
        list(_106855,num),
        list(_106872,num).

