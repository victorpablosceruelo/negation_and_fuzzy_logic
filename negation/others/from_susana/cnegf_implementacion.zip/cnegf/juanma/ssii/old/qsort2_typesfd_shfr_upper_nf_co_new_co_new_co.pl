:- module(_qsort2_typesfd_shfr_upper_nf_co_new_co_new,[qsort/2,partition/4,append/3,less/2,greatereq/2,prueba_2/2,prueba_3/3,prueba_4/4],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- include(library(assertions)).

:- use_module(library('assertions/native_props')).

:- include(library(nativeprops)).

:- redefining(indep/1).

:- redefining(indep/2).

:- op(950,xf,[&]).

:- op(975,xfx,[=>]).

:- use_module(library('andprolog/andprolog_rt')).

:- include(library(cges)).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- include(library(assertions)).

:- use_module(library('assertions/native_props')).

:- use_module(library('assertions/native_props')).

:- include(library(nativeprops)).

:- redefining(indep/1).

:- redefining(indep/2).

:- op(950,xf,[&]).

:- op(975,xfx,[=>]).

:- use_module(library('andprolog/andprolog_rt')).

:- op(950,xf,[&]).

:- op(975,xfx,[=>]).

:- use_module(library('andprolog/andprolog_rt')).

:- include(library(cges)).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- trust success neg(_217679).

:- true pred qsort(_217836,_217865)
         : ( list(_217836,numexp), var(_217865) )
        => ( list(_217836,numexp), ground(_217865) )
         + ( possibly_fails(qsort(_217836,_217865),qsort(_217836,_217865)), covered(qsort(_217836,_217865),qsort(_217836,_217865)) ).

:- true pred qsort(_218533,_218562)
         : ( ground(_218533), var(_218562), mshare([[_218562]]) )
        => ( ground(_218533), ground(_218562) ).

:- entry qsort(_219012,_219041)
         : ( list(_219012,num), var(_219041), ground(_219012) ).

qsort([_219347|_219376],_219407) :-
        partition(_219376,_219347,_219512,_219541),
        qsort(_219541,_219610),
        qsort(_219512,_219679),
        append(_219679,[_219347|_219610],_219407).

qsort([],[]).

:- true pred partition(_220105,_220134,_220163,_220192)
         : ( term(_220105), term(_220134), term(_220163), term(_220192) )
        => ( list(_220105,numexp), term(_220134), list(_220163,numexp), list(_220192,numexp) )
         + ( possibly_fails(partition(_220105,_220134,_220163,_220192),partition(_220105,_220134,_220163,_220192)), not_covered(partition(_220105,_220134,_220163,_220192),partition(_220105,_220134,_220163,_220192)) ).

:- true pred partition(_221209,_221238,_221267,_221296)
         : mshare([[_221209],[_221209,_221238],[_221209,_221238,_221267],[_221209,_221238,_221267,_221296],[_221209,_221238,_221296],[_221209,_221267],[_221209,_221267,_221296],[_221209,_221296],[_221238],[_221238,_221267],[_221238,_221267,_221296],[_221238,_221296],[_221267],[_221267,_221296],[_221296]])
        => ( ground(_221209), ground(_221267), ground(_221296), mshare([[_221238]]) ).

partition([],_222586,[],[]).

partition([_222727|_222756],_222787,[_222727|_222840],_222871) :-
        less(_222727,_222787),
        partition(_222756,_222787,_222840,_222871).

partition([_223218|_223247],_223278,_223307,[_223218|_223360]) :-
        greatereq(_223218,_223278),
        partition(_223247,_223278,_223307,_223360).

:- true pred append(_223743,_223772,_223801)
         : ( term(_223743), term(_223772), term(_223801) )
        => ( list(_223743,term), term(_223772), term(_223801) )
         + ( possibly_fails(append(_223743,_223772,_223801),append(_223743,_223772,_223801)), not_covered(append(_223743,_223772,_223801),append(_223743,_223772,_223801)) ).

:- true pred append(_224605,_224634,_224663)
         : mshare([[_224605],[_224605,_224634],[_224605,_224634,_224663],[_224605,_224663],[_224634],[_224634,_224663],[_224663]])
        => mshare([[_224605,_224634,_224663],[_224605,_224663],[_224634,_224663]]).

append([],_225412,_225412).

append([_225550|_225579],_225610,[_225550|_225663]) :-
        append(_225579,_225610,_225663).

:- true pred less(_225925,_225954)
         : ( term(_225925), term(_225954) )
        => ( numexp(_225925), numexp(_225954) )
         + ( possibly_fails(less(_225925,_225954),less(_225925,_225954)), not_covered(less(_225925,_225954),less(_225925,_225954)) ).

:- true pred less(_226588,_226617)
         : mshare([[_226588],[_226588,_226617],[_226617]])
        => ( ground(_226588), ground(_226617) ).

less(_227025,_227054) :-
        _227025<_227054.

:- true pred greatereq(_227277,_227306)
         : ( term(_227277), term(_227306) )
        => ( numexp(_227277), numexp(_227306) )
         + ( possibly_fails(greatereq(_227277,_227306),greatereq(_227277,_227306)), not_covered(greatereq(_227277,_227306),greatereq(_227277,_227306)) ).

:- true pred greatereq(_227970,_227999)
         : mshare([[_227970],[_227970,_227999],[_227999]])
        => ( ground(_227970), ground(_227999) ).

greatereq(_228417,_228446) :-
        _228417>=_228446.

:- true pred prueba_2(_228669,_228698)
         : ( term(_228669), term(_228698) )
        => ( term(_228669), term(_228698) )
         + ( possibly_fails(prueba_2(_228669,_228698),prueba_2(_228669,_228698)), covered(prueba_2(_228669,_228698),prueba_2(_228669,_228698)) ).

:- true pred prueba_2(_229340,_229369)
         : mshare([[_229340],[_229340,_229369],[_229369]])
        => mshare([[_229340],[_229340,_229369],[_229369]]).

prueba_2(_229825,_229854) :-
        neg(qsort(_229825,_229854)).

:- true pred prueba_3(_230109,_230138,_230167)
         : ( term(_230109), term(_230138), term(_230167) )
        => ( term(_230109), term(_230138), term(_230167) )
         + ( possibly_fails(prueba_3(_230109,_230138,_230167),prueba_3(_230109,_230138,_230167)), covered(prueba_3(_230109,_230138,_230167),prueba_3(_230109,_230138,_230167)) ).

:- true pred prueba_3(_230958,_230987,_231016)
         : mshare([[_230958],[_230958,_230987],[_230958,_230987,_231016],[_230958,_231016],[_230987],[_230987,_231016],[_231016]])
        => mshare([[_230958],[_230958,_230987],[_230958,_230987,_231016],[_230958,_231016],[_230987],[_230987,_231016],[_231016]]).

prueba_3(_231907,_231936,_231965) :-
        neg(append(_231907,_231936,_231965)).

:- true pred prueba_4(_232250,_232279,_232308,_232337)
         : ( term(_232250), term(_232279), term(_232308), term(_232337) )
        => ( term(_232250), term(_232279), term(_232308), term(_232337) )
         + ( possibly_fails(prueba_4(_232250,_232279,_232308,_232337),prueba_4(_232250,_232279,_232308,_232337)), covered(prueba_4(_232250,_232279,_232308,_232337),prueba_4(_232250,_232279,_232308,_232337)) ).

:- true pred prueba_4(_233277,_233306,_233335,_233364)
         : mshare([[_233277],[_233277,_233306],[_233277,_233306,_233335],[_233277,_233306,_233335,_233364],[_233277,_233306,_233364],[_233277,_233335],[_233277,_233335,_233364],[_233277,_233364],[_233306],[_233306,_233335],[_233306,_233335,_233364],[_233306,_233364],[_233335],[_233335,_233364],[_233364]])
        => mshare([[_233277],[_233277,_233306],[_233277,_233306,_233335],[_233277,_233306,_233335,_233364],[_233277,_233306,_233364],[_233277,_233335],[_233277,_233335,_233364],[_233277,_233364],[_233306],[_233306,_233335],[_233306,_233335,_233364],[_233306,_233364],[_233335],[_233335,_233364],[_233364]]).

prueba_4(_235314,_235343,_235372,_235401) :-
        neg(partition(_235314,_235343,_235372,_235401)).

:- regtype t199/1.

t199(partition(_235837,_235866,_235895,_235924)) :-
        term(_235837),
        term(_235866),
        term(_235895),
        term(_235924).

t199(qsort(_236266,_236295)) :-
        term(_236266),
        term(_236295).

t199(append(_236537,_236566,_236595)) :-
        term(_236537),
        term(_236566),
        term(_236595).

