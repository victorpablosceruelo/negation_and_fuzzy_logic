:- module(_qsort2,[qsort/2,partition/4,append/3,less/2,greatereq/2,prueba_2/2,prueba_3/3,prueba_4/4],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration((decl)/1).

:- op(1150,fx,decl).

:- new_declaration((decl)/2).

:- op(1150,xfx,decl).

:- new_declaration((pred)/1).

:- op(1150,fx,pred).

:- new_declaration((pred)/2).

:- op(1150,xfx,pred).

:- new_declaration((prop)/1).

:- op(1150,fx,prop).

:- new_declaration((prop)/2).

:- op(1150,xfx,prop).

:- new_declaration((modedef)/1).

:- op(1150,fx,modedef).

:- new_declaration((calls)/1).

:- op(1150,fx,calls).

:- new_declaration((calls)/2).

:- op(1150,xfx,calls).

:- new_declaration((success)/1).

:- op(1150,fx,success).

:- new_declaration((success)/2).

:- op(1150,xfx,success).

:- new_declaration((comp)/1).

:- op(1150,fx,comp).

:- new_declaration((comp)/2).

:- op(1150,xfx,comp).

:- new_declaration((entry)/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- trust success neg(X).

:- true pred qsort(A,B)
         : ( list(A,numexp), var(B) )
        => ( list(A,numexp), ground(B) )
         + ( possibly_fails, covered ).

:- true pred qsort(A,B)
         : ( ground(A), var(B), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry qsort(A,B)
         : ( list(A,num), var(B), ground(A) ).

qsort([X|L],R) :-
        partition(L,X,L1,L2),
        qsort(L2,R2),
        qsort(L1,R1),
        append(R1,[X|R2],R).

qsort([],[]).

:- true pred partition(A,B,C,D)
         : ( term(A), term(B), term(C), term(D) )
        => ( list(A,numexp), term(B), list(C,numexp), list(D,numexp) )
         + ( possibly_fails, not_covered ).

:- true pred partition(A,B,C,D)
         : mshare([[A],[A,B],[A,B,C],[A,B,C,D],[A,B,D],[A,C],[A,C,D],[A,D],[B],[B,C],[B,C,D],[B,D],[C],[C,D],[D]])
        => ( ground(A), ground(C), ground(D), mshare([[B]]) ).

partition([],_1,[],[]).

partition([E|R],C,[E|Left1],Right) :-
        less(E,C),
        partition(R,C,Left1,Right).

partition([E|R],C,Left,[E|Right1]) :-
        greatereq(E,C),
        partition(R,C,Left,Right1).

:- true pred append(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( list(A,term), term(B), term(C) )
         + ( possibly_fails, not_covered ).

:- true pred append(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A,B,C],[A,C],[B,C]]).

append([],X,X).

append([H|X],Y,[H|Z]) :-
        append(X,Y,Z).

:- true pred less(A,B)
         : ( term(A), term(B) )
        => ( numexp(A), numexp(B) )
         + ( possibly_fails, not_covered ).

:- true pred less(A,B)
         : mshare([[A],[A,B],[B]])
        => ( ground(A), ground(B) ).

less(E,C) :-
        E<C.

:- true pred greatereq(A,B)
         : ( term(A), term(B) )
        => ( numexp(A), numexp(B) )
         + ( possibly_fails, not_covered ).

:- true pred greatereq(A,B)
         : mshare([[A],[A,B],[B]])
        => ( ground(A), ground(B) ).

greatereq(E,C) :-
        E>=C.

:- true pred prueba_2(A,B)
         : ( term(A), term(B) )
        => ( term(A), term(B) )
         + ( possibly_fails, covered ).

:- true pred prueba_2(A,B)
         : mshare([[A],[A,B],[B]])
        => mshare([[A],[A,B],[B]]).

prueba_2(A,B) :-
        neg(qsort(A,B)).

:- true pred prueba_3(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred prueba_3(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

prueba_3(A,B,C) :-
        neg(append(A,B,C)).

:- true pred prueba_4(A,B,C,D)
         : ( term(A), term(B), term(C), term(D) )
        => ( term(A), term(B), term(C), term(D) )
         + ( possibly_fails, covered ).

:- true pred prueba_4(A,B,C,D)
         : mshare([[A],[A,B],[A,B,C],[A,B,C,D],[A,B,D],[A,C],[A,C,D],[A,D],[B],[B,C],[B,C,D],[B,D],[C],[C,D],[D]])
        => mshare([[A],[A,B],[A,B,C],[A,B,C,D],[A,B,D],[A,C],[A,C,D],[A,D],[B],[B,C],[B,C,D],[B,D],[C],[C,D],[D]]).

prueba_4(A,B,C,D) :-
        neg(partition(A,B,C,D)).

:- regtype t199/1.

t199(partition(A,B,C,D)) :-
        term(A),
        term(B),
        term(C),
        term(D).
t199(qsort(A,B)) :-
        term(A),
        term(B).
t199(append(A,B,C)) :-
        term(A),
        term(B),
        term(C).

