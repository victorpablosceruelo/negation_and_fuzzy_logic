:- module(_pp,[par/1,no_par/1],ciaopp).

par(2).

par(4).

no_par(4) :-
        par(2).

multi(0,22).

multi(_1,Y) :-
        multi(0,Y).

finite(par,1).

prueba(A) :-
        neg(par(A)).

n_prueba(B) :-
        neg(no_par(B)).

