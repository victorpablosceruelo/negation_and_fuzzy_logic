:-module(finite_facts, [finite/2], []).


