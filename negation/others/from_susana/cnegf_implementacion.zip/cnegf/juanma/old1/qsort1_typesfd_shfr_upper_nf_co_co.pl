:- module(_qsort1_typesfd_shfr_upper_nf_co,[eq_list/2,neq_list/2,qsort/2],ciaopp).

:- use_package(.(cnegf)).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- include(library(assertions)).

:- use_module(library('assertions/native_props')).

:- include(library(nativeprops)).

:- redefining(indep/1).

:- redefining(indep/2).

:- op(950,xf,[&]).

:- op(975,xfx,[=>]).

:- use_module(library('andprolog/andprolog_rt')).

:- include(library(cges)).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module(neg).

:- success(trust,neg(X)).

:- true pred eq_list(A,B)
         : ( list(A,num), list(B,num) )
        => ( list(A,num), list(B,num) )
         + ( possibly_fails(eq_list(A,B)), covered(eq_list(A,B)) ).

:- true pred eq_list(A,B)
         : ( ground(A), ground(B) )
        => ( ground(A), ground(B) ).

:- entry eq_list(L1,L2)
         : ( list(L1,num), list(L2,num), ground(L1), ground(L2) ).

eq_list(L1,L2) :-
        neg(neq_list(L1,L2)).

:- true pred neq_list(A,B)
         : ( list(A,num), list(B,num) )
        => ( list(A,num), list(B,num) )
         + ( possibly_fails(neq_list(A,B)), covered(neq_list(A,B)) ).

:- true pred neq_list(A,B)
         : ( ground(A), ground(B) )
        => ( ground(A), ground(B) ).

:- entry neq_list(L1,L2)
         : ( list(L1,num), list(L2,num), ground(L1), ground(L2) ).

neq_list(L1,L2) :-
        qsort(L1,L),
        neg(qsort(L2,L)).

:- true pred qsort(A,B)
         : ( list(A,num), var(B) )
        => ( list(A,num), list(B,num), size_ub(A,length(A)), size_ub(B,exp(2,length(A))-1.0) )
         + ( not_fails(qsort(A,B)), covered(qsort(A,B)), steps_ub(qsort(A,B),sum($(j),1,length(A),exp(2,length(A)- $(j))* $(j))+exp(2,length(A)-1)*length(A)+2.0*exp(2,length(A))-1.0) ).

finite(qsort,2).

:- true pred qsort(A,B)
         : ( ground(A), var(B), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry qsort(A,B)
         : ( list(A,num), var(B), ground(A) ).

qsort([X|L],R) :-
        partition(L,X,L1,L2),
        qsort(L2,R2),
        qsort(L1,R1),
        append(R1,[X|R2],R).

qsort([],[]).

:- true pred partition(A,B,C,D)
         : ( list(A,num), num(B), var(C), var(D) )
        => ( list(A,num), num(B), list(C,num), list(D,num), size_ub(A,length(A)), size_ub(B,int(B)), size_ub(C,length(A)), size_ub(D,length(A)) )
         + ( not_fails(partition(A,B,C,D)), covered(partition(A,B,C,D)), steps_ub(partition(A,B,C,D),length(A)+1) ).

finite(partition,4).

:- true pred partition(A,B,C,D)
         : ( ground(A), ground(B), var(C), var(D), mshare([[C],[D]]), indep(C,D) )
        => ( ground(A), ground(B), ground(C), ground(D) ).

partition([],_B,[],[]).

partition([E|R],C,[E|Left1],Right) :-
        E<C,
        !,
        partition(R,C,Left1,Right).

partition([E|R],C,Left,[E|Right1]) :-
        E>=C,
        partition(R,C,Left,Right1).

:- true pred append(A,B,C)
         : ( list(A,num), list1(B,num), var(C) )
        => ( list(A,num), list1(B,num), list1(C,num), size_ub(A,length(A)), size_ub(B,length(B)), size_ub(C,length(B)+length(A)) )
         + ( not_fails(append(A,B,C)), covered(append(A,B,C)), steps_ub(append(A,B,C),length(A)+1) ).

finite(append,3).

:- true pred append(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

append([],X,X).

append([H|X],Y,[H|Z]) :-
        append(X,Y,Z).

t253(neq_list(A,B)) :-
        list(A,num),
        list(B,num).

t253(qsort(A,B)) :-
        list(A,num),
        list(B,num).

