:- module(_qsort1_typesfd_shfr_nf_co,[neq_list/2,qsort/2],ciaopp).

