:- module(_miprueba,[par/1,no_par/1],ciaopp).

:- true pred par(A)
         : term(A)
        => ( nnegint(A), size_ub(A,int(A)) )
         + ( possibly_fails, not_covered, steps_ub(1) ).

:- true pred par(A)
         : mshare([[A]])
        => ground(A).

par(2).

par(4).

:- true pred no_par(A)
         : term(A)
        => t34(A)
         + ( possibly_fails, not_covered ).

:- true pred no_par(A)
         : mshare([[A]])
        => ground(A).

no_par(4) :-
        par(2).

multi(0,22).

multi(_1,Y) :-
        multi(0,Y).

:- regtype t34/1.

t34(4).

