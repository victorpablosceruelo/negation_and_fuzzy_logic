:- module(_factorial,[multiplica/3,factorial/2,lista_factorial/2,numero_combinatorio/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- true pred multiplica(A,B,C)
         : ( numexp(A), numexp(B), term(C) )
        => ( numexp(A), numexp(B), numexp(C) )
         + ( not_fails, covered ).

:- true pred multiplica(A,B,C)
         : ( ground(A), ground(B), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry multiplica(X,Y,Z)
         : ( num(X), ground(X), num(Y), ground(Y) ).

multiplica(X,1,X) :- !.

multiplica(1,Y,Y) :- !.

multiplica(X,Y,Z) :-
        Y1 is Y-1,
        multiplica(X,Y1,Z1),
        Z is X+Z1.

:- true pred factorial(A,B)
         : ( numexp(A), term(B) )
        => ( numexp(A), numexp(B) )
         + ( not_fails, covered ).

:- true pred factorial(A,B)
         : ( ground(A), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry factorial(X,Y)
         : ( num(X), ground(X) ).

factorial(0,1) :- !.

factorial(X,Y) :-
        X1 is X-1,
        factorial(X1,Y1),
        multiplica(X,Y1,Y).

:- true pred lista_factorial(A,B)
         : ( num(A), var(B) )
        => ( num(A), list1(B,numexp) )
         + ( not_fails, covered ).

:- true pred lista_factorial(A,B)
         : ( ground(A), var(B), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry lista_factorial(X,Y)
         : ( num(X), ground(X), var(Y) ).

lista_factorial(1,[1]) :- !.

lista_factorial(N,[X|Xs]) :-
        factorial(N,X),
        N1 is N-1,
        lista_factorial(N1,Xs).

:- true pred numero_combinatorio(A,B,C)
         : ( ground(A), ground(B), var(C) )
        => ( numexp(A), numexp(B), num(C) )
         + ( not_fails, covered ).

:- true pred numero_combinatorio(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry numero_combinatorio(X,Y,Z)
         : ( number(X), ground(X), number(Y), ground(Y), var(Z) ).

numero_combinatorio(Superior,Inferior,Resultado) :-
        D is Superior-Inferior,
        factorial(Superior,FS),
        factorial(Inferior,FI),
        factorial(D,FD),
        Resultado is FS*FD/FI.

:- regtype t107/1.

t107(A+B) :-
        numexp(A),
        numexp(B).
t107(A-B) :-
        term(A),
        term(B).
t107(A*B/C) :-
        numexp(A),
        numexp(B),
        numexp(C).

