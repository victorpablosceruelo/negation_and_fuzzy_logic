:- module(_intersect,[intersect/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- true pred mimember(A,B)
         : ( num(A), list(B,num) )
        => ( num(A), list1(B,num), size_ub(A,int(A)), size_ub(B,length(B)) )
         + ( possibly_fails, not_covered, steps_ub(length(B)+1) ).

:- true pred mimember(A,B)
         : ( ground(A), ground(B) )
        => ( ground(A), ground(B) ).

:- entry mimember(X,Y)
         : ( num(X), ground(X), list(Y,num), ground(Y) ).

mimember(H,[H|_1]) :- !.

mimember(H,[_1|T]) :-
        mimember(H,T).

:- true pred intersect(A,B,C)
         : ( list(A,num), list(B,num), var(C) )
        => ( list(A,num), list(B,num), list(C,num), size_ub(A,length(A)), size_ub(B,length(B)), size_ub(C,length(A)) )
         + ( not_fails, covered, steps_ub(length(B)*length(A)+2*length(A)+1) ).

:- true pred intersect(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry intersect(X,Y,Z)
         : ( list(X,num), ground(X), list(Y,num), ground(Y), var(Z) ).

intersect([],_1,[]) :- !.

intersect([X|T],L,[X|R]) :-
        mimember(X,L),
        intersect(T,L,R),
        !.

intersect([_1|T],L,R) :-
        intersect(T,L,R).

