:- module(_miprueba,[par/1,no_par/1],ciaopp).

par(2).

par(4).

no_par(4) :-
        neg(s(0)).

