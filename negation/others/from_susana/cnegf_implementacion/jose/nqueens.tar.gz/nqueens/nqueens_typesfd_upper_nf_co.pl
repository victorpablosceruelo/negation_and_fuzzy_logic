:- use_package(ciaopp).

:- use_module(library(aggregates)).

:- use_module(library(aggregates)).

:- use_module(library(dynamic)).

:- use_module(library(iso_misc)).

:- use_module(library(iso_byte_char)).

:- use_module(library(iso_incomplete)).

:- use_module(library(operators)).

:- use_module(library(read)).

:- use_module(library(write)).

:- true pred select(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), t62(B), term(C) )
         + ( possibly_fails, not_covered ).

select(X,[X|Xs],Xs).

select(X,[Y|Ys],[Y|Zs]) :-
        select(X,Ys,Zs).

:- true pred range(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), list1(C,term) )
         + ( possibly_fails, not_covered ).

range(M,N,[M|Ns]) :-
        M<N,
        M1 is M+1,
        range(M1,N,Ns).

range(N,N,[N]).

:- true pred safe(A)
         : term(A)
        => list(A,term)
         + ( possibly_fails, not_covered ).

safe([Q|Qs]) :-
        safe(Qs),
        \+attack(Q,Qs).

safe([]).

:- true pred attack(A,B)
         : ( term(A), term(B) )
        => ( num(A), t62(B) )
         + ( possibly_fails, covered ).

attack(X,Xs) :-
        attacka(X,1,Xs).

:- true pred attacka(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( num(A), numexp(B), t62(C) )
         + ( possibly_fails, not_covered ).

attacka(X,N,[Y|_Ys]) :-
        X is Y+N.

attacka(X,N,[Y|_Ys]) :-
        X is Y-N.

attacka(X,N,[_Y|Ys]) :-
        N1 is N+1,
        attacka(X,N1,Ys).

:- true pred queens(A,B)
         : ( term(A), term(B) )
        => ( term(A), term(B) )
         + ( possibly_fails, covered ).

queens(N,Qs) :-
        range(1,N,Ns),
        queensa(Ns,[],Qs).

:- true pred queensa(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( t126(A), term(B), term(C) )
         + ( possibly_fails, covered ).

queensa(UnplacedQs,SafeQs,Qs) :-
        select(Q,UnplacedQs,UnplacedQs1),
        \+attack(Q,SafeQs),
        queensa(UnplacedQs1,[Q|SafeQs],Qs).

queensa([],Qs,Qs).

:- regtype t62/1.

t62([A|B]) :-
        term(A),
        term(B).

:- regtype t126/1.

t126([]).
t126([A|B]) :-
        term(A),
        term(B).

:- regtype t115/1.

t115(A+B) :-
        term(A),
        term(B).
t115(A-B) :-
        term(A),
        term(B).

:- regtype t121/1.

t121(attack(A,B)) :-
        term(A),
        term(B).

