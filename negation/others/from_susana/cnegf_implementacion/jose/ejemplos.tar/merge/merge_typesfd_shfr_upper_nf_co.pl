:- module(_merge,[unif/2,merge/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module(cnegf,[cnegf/1]).

:- true pred unif(A,B)
         : ( term(A), term(B) )
        => ( term(A), term(B) )
         + ( not_fails, covered ).

:- true pred unif(A,B)
         : mshare([[A],[A,B],[B]])
        => mshare([[A,B]]).

unif(X,X).

:- true pred merge(A,B,C)
         : ( list(A,num), list(B,num), list(C,num) )
        => ( list(A,num), list(B,num), list(C,num) )
         + ( possibly_fails, not_covered ).

:- true pred merge(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A,B,C],[A,C],[B,C]]).

:- entry merge(A,B,C)
         : ( list(A,num), list(B,num), list(C,num) ).

merge([X|Xs],[Y|Ys],[X|Zs]) :-
        X<Y,
        !,
        merge(Xs,[Y|Ys],Zs).

merge([X|Xs],[Y|Ys],[X,Y|Zs]) :-
        unif(X,Y),
        !,
        merge(Xs,Ys,Zs).

merge([X|Xs],[Y|Ys],[Y|Zs]) :-
        X>Y,
        !,
        merge([X|Xs],Ys,Zs).

merge(Xs,[],Xs) :- !.

merge([],Ys,Ys) :- !.

