:- module(_intersect,[intersect/3,not_intersect/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- use_module('.'(cnegf)).

:- trust success neg(X).

:- true pred mymember(A,B)
         : ( num(A), list(B,num) )
        => ( num(A), list1(B,num), size_ub(A,int(A)), size_ub(B,length(B)) )
         + ( possibly_fails, not_covered, steps_ub(length(B)+1) ).

:- true pred mymember(A,B)
         : ( ground(A), ground(B) )
        => ( ground(A), ground(B) ).

:- entry mymember(X,Y)
         : ( num(X), ground(X), list(Y,num), ground(Y) ).

mymember(H,[H|_1]) :- !.

mymember(H,[_1|T]) :-
        mymember(H,T).

:- true pred intersect(A,B,C)
         : ( list(A,num), list(B,num), var(C) )
        => ( list(A,num), list(B,num), list(C,num), size_ub(A,length(A)), size_ub(B,length(B)), size_ub(C,length(A)) )
         + ( not_fails, covered, steps_ub(length(B)*length(A)+2*length(A)+1) ).

:- true pred intersect(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry intersect(X,Y,Z)
         : ( list(X,num), ground(X), list(Y,num), ground(Y), var(Z) ).

intersect([],_1,[]) :- !.

intersect([X|T],L,[X|R]) :-
        mymember(X,L),
        intersect(T,L,R),
        !.

intersect([_1|T],L,R) :-
        intersect(T,L,R).

:- true pred not_intersect(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred not_intersect(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

not_intersect(X,Y,Z) :-
        cnegf(intersect(X,Y,Z)).

:- regtype t90/1.

t90(intersect(A,B,C)) :-
        term(A),
        term(B),
        term(C).

