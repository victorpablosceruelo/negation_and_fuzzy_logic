%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                              %%
%% intersect.pl                                                 %%
%%                                                              %%
%%                   Intersect between who lists                %%
%%                   Jose Antonio Cuesta Corpa                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(_intersect,[intersect/3,not_intersect/3],[assertions]).
:- use_module(.(neg)).
:- trust success neg(X) => true.

:- entry mymember(X,Y) : (num(X), ground(X), list(Y,num), ground(Y)).
% mymember(X,[Y|Ys[) -> true if X IN [Y|Ys]
mymember(H,[H|_]):-!.
mymember(H,[_|T]):- mymember(H,T).

% intersect(L1,L2,L3) -> L3 is L1 /\ L3
:- entry intersect(X,Y,Z) : (list(X,num), ground(X), list(Y,num), ground(Y), var(Z)).
intersect([],_,[]):-!.
intersect([X|T],L,[X|R]):- mymember(X,L),intersect(T,L,R),!.
intersect([_|T],L,R):- intersect(T,L,R).

not_intersect(X,Y,Z) :- neg(intersect(X,Y,Z)).
