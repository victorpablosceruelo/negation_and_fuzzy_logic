%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                              %%
%% triangles.pl                                                 %%
%%                                                              %%
%%                   Determines the type of a triangle          %%
%%                   Jose Antonio Cuesta Corpa                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- module(_mayor,_,[assertions]).
:- use_module(.(neg)).
:- trust success neg(X) => true.

equilateral(X,X,X).

isosceles(X,X,Y):- neg(equilateral(X,X,Y)).
isosceles(X,Y,X):- neg(equilateral(X,Y,X)).
isosceles(Y,X,X):- neg(equilateral(Y,X,X)).

scalene(X,Y,Z) :- neg(equilateral(X,Y,Z)), neg(isosceles(X,Y,Z)). 



