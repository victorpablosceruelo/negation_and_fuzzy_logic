:- module(_triangles,[equilateral/3,isosceles/3,scalene/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- trust success neg(X).

:- true pred equilateral(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( not_fails, covered ).

:- true pred equilateral(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A,B,C]]).

equilateral(X,X,X).

:- true pred isosceles(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred isosceles(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

isosceles(X,X,Y) :-
        neg(equilateral(X,X,Y)).

isosceles(X,Y,X) :-
        neg(equilateral(X,Y,X)).

isosceles(Y,X,X) :-
        neg(equilateral(Y,X,X)).

:- true pred scalene(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred scalene(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

scalene(X,Y,Z) :-
        neg(equilateral(X,Y,Z)),
        neg(isosceles(X,Y,Z)).

:- regtype t37/1.

t37(equilateral(A,B,C)) :-
        term(A),
        term(B),
        term(C).
t37(isosceles(A,B,C)) :-
        term(A),
        term(B),
        term(C).

