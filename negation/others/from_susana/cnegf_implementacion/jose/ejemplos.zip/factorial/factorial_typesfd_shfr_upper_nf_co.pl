:- module(_factorial,[multiply/3,factorial/2,list_factorial/2,numero_combinatorio/3,not_multiply/3,not_factorial/2,not_numero_combinatorio/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- trust success neg(X).

:- true pred multiply(A,B,C)
         : ( numexp(A), numexp(B), term(C) )
        => ( numexp(A), numexp(B), numexp(C), size_ub(A,0), size_ub(B,0), size_ub(C,0) )
         + ( not_fails, covered, steps_ub(inf) ).

:- true pred multiply(A,B,C)
         : ( ground(A), ground(B), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry multiply(X,Y,Z)
         : ( num(X), ground(X), num(Y), ground(Y) ).

multiply(X,1,X) :- !.

multiply(1,Y,Y) :- !.

multiply(X,Y,Z) :-
        Y1 is Y-1,
        multiply(X,Y1,Z1),
        Z is X+Z1.

:- true pred factorial(A,B)
         : ( numexp(A), term(B) )
        => ( numexp(A), numexp(B), size_ub(A,0), size_ub(B,0) )
         + ( not_fails, covered, steps_ub(inf) ).

:- true pred factorial(A,B)
         : ( ground(A), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry factorial(X,Y)
         : ( num(X), ground(X) ).

factorial(0,1) :- !.

factorial(X,Y) :-
        X1 is X-1,
        factorial(X1,Y1),
        multiply(X,Y1,Y).

:- true pred list_factorial(A,B)
         : ( num(A), var(B) )
        => ( num(A), list1(B,numexp), size_ub(A,int(A)), size_ub(B,int(A)) )
         + ( not_fails, covered, steps_ub(inf) ).

:- true pred list_factorial(A,B)
         : ( ground(A), var(B), mshare([[B]]) )
        => ( ground(A), ground(B) ).

:- entry list_factorial(X,Y)
         : ( num(X), ground(X), var(Y) ).

list_factorial(1,[1]) :- !.

list_factorial(N,[X|Xs]) :-
        factorial(N,X),
        N1 is N-1,
        list_factorial(N1,Xs).

:- true pred numero_combinatorio(A,B,C)
         : ( ground(A), ground(B), var(C) )
        => ( numexp(A), numexp(B), num(C) )
         + ( not_fails, covered ).

:- true pred numero_combinatorio(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry numero_combinatorio(X,Y,Z)
         : ( number(X), ground(X), number(Y), ground(Y), var(Z) ).

numero_combinatorio(Superior,Inferior,Resultado) :-
        D is Superior-Inferior,
        factorial(Superior,FS),
        factorial(Inferior,FI),
        factorial(D,FD),
        Resultado is FS*FD/FI.

:- true pred not_multiply(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred not_multiply(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

not_multiply(X,Y,Z) :-
        neg(multiply(X,Y,Z)).

:- true pred not_factorial(A,B)
         : ( term(A), term(B) )
        => ( term(A), term(B) )
         + ( possibly_fails, covered ).

:- true pred not_factorial(A,B)
         : mshare([[A],[A,B],[B]])
        => mshare([[A],[A,B],[B]]).

not_factorial(X,Y) :-
        neg(factorial(X,Y)).

:- true pred not_numero_combinatorio(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred not_numero_combinatorio(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

not_numero_combinatorio(X,Y,Z) :-
        neg(numero_combinatorio(X,Y,Z)).

:- regtype t93/1.

t93(numero_combinatorio(A,B,C)) :-
        term(A),
        term(B),
        term(C).
t93(multiply(A,B,C)) :-
        term(A),
        term(B),
        term(C).
t93(factorial(A,B)) :-
        term(A),
        term(B).

:- regtype t123/1.

t123(A-B) :-
        term(A),
        term(B).
t123(A*B/C) :-
        numexp(A),
        numexp(B),
        numexp(C).
t123(A+B) :-
        numexp(A),
        numexp(B).

