%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                              %%
%% factorial.pl                                                 %%
%%                                                              %%
%%                   Recursive implementation of multiplication %%
%%                   Implementation of ! operation              %%
%%                   apply of ! to a list                       %%
%%                   Combinatory number calculation             %%
%%                   Jose Antonio Cuesta Corpa                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(_factorial, _ , [assertions]).
:- use_module(.(neg)).
:- trust success neg(X) => true.

% multiply(X,Y,Z) Z is X * Y
:- entry multiply(X,Y,Z) : (num(X), ground(X), num(Y), ground(Y)).
multiply(X,1,X) :- !.
multiply(1,Y,Y) :- !.
multiply(X,Y,Z) :- Y1 is Y - 1, multiply(X,Y1,Z1),Z is X + Z1.

% factorial(X,Y) Y is Y!
:- entry factorial(X,Y) : (num(X), ground(X)).
factorial(0,1) :- !.
factorial(X,Y) :- X1 is X -1, factorial(X1,Y1), multiply(X,Y1,Y).

:- entry list_factorial(X,Y) : (num(X), ground(X), var(Y)).
% list_factorial([A|Xs],[B,Ys]) B=A! factorial(Xs,Ys)
list_factorial(1,[1]) :- !.
list_factorial(N,[X|Xs]) :- factorial(N,X), N1 is N -1, list_factorial(N1,Xs).

:- entry numero_combinatorio(X,Y,Z) : (number(X), ground(X), number(Y), ground(Y), var(Z)).


%numero_combinatotio(S,I,R) R= (S-I)! * S! / I!
numero_combinatorio(Superior,Inferior,Resultado) :- D is Superior - Inferior, factorial(Superior,FS), factorial(Inferior,FI), factorial(D,FD), Resultado is FS * FD / FI.

not_multiply(X,Y,Z) :- neg(multiply(X,Y,Z)).

not_factorial(X,Y) :- neg(factorial(X,Y)).

not_numero_combinatorio(X,Y,Z) :- neg(numero_combinatorio(X,Y,Z)).

