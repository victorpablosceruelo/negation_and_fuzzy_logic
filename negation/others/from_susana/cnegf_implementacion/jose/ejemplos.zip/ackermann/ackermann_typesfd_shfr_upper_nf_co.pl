:- module(_ackermann,[ackermann/3,not_ackermann/3],ciaopp).

:- new_declaration(comment/2).

:- op(975,xfx,=>).

:- op(978,xfx,::).

:- new_declaration(decl/1).

:- op(1150,fx,decl).

:- new_declaration(decl/2).

:- op(1150,xfx,decl).

:- new_declaration(pred/1).

:- op(1150,fx,pred).

:- new_declaration(pred/2).

:- op(1150,xfx,pred).

:- new_declaration(prop/1).

:- op(1150,fx,prop).

:- new_declaration(prop/2).

:- op(1150,xfx,prop).

:- new_declaration(modedef/1).

:- op(1150,fx,modedef).

:- new_declaration(calls/1).

:- op(1150,fx,calls).

:- new_declaration(calls/2).

:- op(1150,xfx,calls).

:- new_declaration(success/1).

:- op(1150,fx,success).

:- new_declaration(success/2).

:- op(1150,xfx,success).

:- new_declaration(comp/1).

:- op(1150,fx,comp).

:- new_declaration(comp/2).

:- op(1150,xfx,comp).

:- new_declaration(entry/1).

:- op(1150,fx,entry).

:- use_module('.'(neg)).

:- trust success neg(X).

:- true pred ackermann(A,B,C)
         : ( num(A), num(B), var(C) )
        => ( num(A), num(B), num(C), size_ub(A,int(A)), size_ub(B,int(B)), size_ub(C,inf) )
         + ( not_fails, covered, steps_ub(inf) ).

:- true pred ackermann(A,B,C)
         : ( ground(A), ground(B), var(C), mshare([[C]]) )
        => ( ground(A), ground(B), ground(C) ).

:- entry ackermann(X,Y,Z)
         : ( num(X), ground(X), num(Y), ground(Y), var(Z) ).

ackermann(0,M,R) :-
        R is M+1,
        !.

ackermann(N,0,R) :-
        R1 is N-1,
        ackermann(R1,1,R),
        !.

ackermann(N,M,R) :-
        N1 is N-1,
        M1 is M-1,
        ackermann(N,M1,R1),
        ackermann(N1,R1,R),
        !.

:- true pred not_ackermann(A,B,C)
         : ( term(A), term(B), term(C) )
        => ( term(A), term(B), term(C) )
         + ( possibly_fails, covered ).

:- true pred not_ackermann(A,B,C)
         : mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]])
        => mshare([[A],[A,B],[A,B,C],[A,C],[B],[B,C],[C]]).

not_ackermann(X,Y,Z) :-
        neg(ackermann(X,Y,Z)).

:- regtype t42/1.

t42(ackermann(A,B,C)) :-
        term(A),
        term(B),
        term(C).

:- regtype t60/1.

t60(A+1) :-
        num(A).
t60(A-1) :-
        num(A).

