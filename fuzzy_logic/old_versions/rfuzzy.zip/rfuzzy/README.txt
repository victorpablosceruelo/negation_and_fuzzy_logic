This file contains three versions of rfuzzy language and some examples
of its use.

- rfuzzy_basico;

which contains the basic version of rfuzzy.


- rfuzzy_default;

improves rfuzzy_basico adding the capability to make default values explicit. 


- rfuzzy_prop;

adds properties management to rfuzzy_default.


Please follow the instructions contained in these files to install
rfuzzy library for your Ciao Prolog system.

 
