:- module(which_row,_,[rfuzzy]).

(which_row(J) cred (luka,0.9)) :~ prod people(J), products_people(J).

:- default(products_people/1, 0.5).

people(row1) value 0.6.
people(row2) value 0.15.
people(row3) value 0.95.
people(row4) value 0.7.

products_people(row2) value 0.2.
products_people(row4) value 0.8.