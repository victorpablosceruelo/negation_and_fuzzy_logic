:- module(restaurant,_,[rfuzzy]).

:- prop type_Restaurant/1.

tempting_restaurant(R) :~ prod distance(R),cheap(R),traditional(R).

type_Restaurant(kenzo).
type_Restaurant(el_rincon).
type_Restaurant(el_reventaero).
type_Restaurant(casa_juan).

:- set_prop distance(R) => type_Restaurant(R).
:- set_prop cheap(R) => type_Restaurant(R).
:- set_prop traditional(R) => type_Restaurant(R).

:- default(distance/1, 0).
:- default(cheap/1, 0.5).
:- default(traditional/1, 1).

distance(kenzo) value 1.
distance(el_rincon) value 0.6.
distance(el_reventaero) value 1.
distance(casa_juan) value 0.8.

cheap(kenzo) value 0.2.
cheap(el_rincon) value 1.
cheap(el_reventaero) value 1.

traditional(kenzo) value 0.5.
traditional(el_reventaero) value 0.87.
