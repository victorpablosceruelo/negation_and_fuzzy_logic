:- module(good_player,_,[rfuzzy]).

:- prop tipoJugador/1.

(good_player(J) cred (prod,0.8)) :~ prod swift(J), tall(J), experience(J).

tipoJugador(john).
tipoJugador(karl).
tipoJugador(mike).
tipoJugador(lebron).
tipoJugador(deron).

:- set_prop experience(J) => tipoJugador(J).

:- default(experience/1, 0.9).
:- default(tall/1,0.6).
:- default(swift/1,0.7).

experience(lebron) value 0.4.
experience(deron) value 0.3.

tall(john) value 0.4 .
tall(karl) value 0.8 .
tall(lebron) value 0.7.
tall(deron) value 0.5.

swift(john) value 1.
swift(karl) value 0.6 .
swift(mike) value 0.9 .
swift(lebron) value 1.
swift(deron) value 0.8.