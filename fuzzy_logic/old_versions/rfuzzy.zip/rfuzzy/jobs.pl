:- module(jobs,_,[rfuzzy]).

(job_offer(J) cred (min,0.8)) :~ prod interest(J), distance(J), salary(J), future_development(J).


interest(consultant) value 0.6 .
interest(systems_analyst) value 0.8 .
interest(developer) value 0.6 .
interest(programmer) value 0.4.
interest(teacher) value 0.4.

distance(consultant) value 0.4.
distance(systems_analyst) value 0.1 .
distance(developer) value 0.5 .
distance(programmer) value 0.5.
distance(teacher) value 0.85.

salary(consultant) value 0.8.
salary(systems_analyst) value 0.9 .
salary(developer) value 0.6 .
salary(programmer) value 0.5.
salary(teacher) value 0.3.

future_development(consultant) value 0.5.
future_development(systems_analyst) value 0.3 .
future_development(developer) value 0.8 .
future_development(programmer) value 0.7.
future_development(teacher) value 0.5.