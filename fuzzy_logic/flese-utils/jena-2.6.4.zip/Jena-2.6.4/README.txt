Jena2 README
============

Welcome to Jena,  a Java framework for writing Semantic Web
applications.

The full readme is in doc/readme.html. 

Documentation is in the doc/ and can be found on the web at
http://jena.sourceforge.net/

There is a mailing lists for questions and feedback:
jena-dev@groups.yahoo.com
