package com.threepillar.labs.socialauthsample.util;

public interface Constants {
	String REQUEST_TYPE = "requestType";
	String REGISTRATION = "registration";
	String IMPORT_CONTACTS = "importContacts";
	String SHARE = "share";
}
