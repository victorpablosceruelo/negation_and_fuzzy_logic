#include "bits.h"
#include <string.h>

void dec2bin(long decimal, char *binary)
{
// accepts a decimal positive integer and returns a binary coded string

  int k = 0, n = 0;
  int neg_flag = 0;
  int remain;
  int old_decimal; // for test
  char temp[WORD_LENGTH];
  
  do
    {
      old_decimal = decimal; // for test
      remain = decimal % 2;
      // whittle down the decimal number
      decimal = decimal / 2;
      // this is a test to show the action
      //printf("%d/2 = %d remainder = %d\n", old_decimal, decimal, remain);
      // converts digit 0 or 1 to character '0' or '1'
      temp[k++] = remain + '0';
    } while (decimal > 0);
    
  // reverse the spelling
  while (k >= 0)
    binary[n++] = temp[--k];
  
  binary[n-1] = '\0'; // end with NULL
}


char * paddle_string(char * record,int N){
  // Paddle the string record with N-length(record) 0's to the left

  int length = strlen(record);
  int diff = N - length;
  char paddle[WORD_LENGTH];
  int i;

  // debugging
  //printf("String to be paddled ...%s\n",record);
  //printf("Its length ...%d\n",length);
  //printf("Number of 0's to insert .... %d\n",diff);

  if (diff == 0)
    strcpy(paddle,record);
  else{

    for(i=0;i < diff;i++)
      paddle[i] = '0';
    // end with NULL
    paddle[i] = '\0'; 

    (void) strncat(paddle,record,strlen(record));

  }
  // Remove warnings
  //  char * s_paddle;
  //  (void) strcpy(s_paddle,paddle);
  //  return s_paddle;

  return paddle;
}

void elem_print(elem r,int N){

  char elem_string[WORD_LENGTH];
  char * res_string;
  
  dec2bin((long) r, elem_string);        
  res_string = paddle_string(elem_string,N); 
  printf("%s",res_string); 
  return;
}

void elem_fprint(FILE * fp,elem x,int N){

  char elem_string[WORD_LENGTH];
  char * res_string;

  //  printf("Writing elem %d\n",x); ///  
  dec2bin((long) x, elem_string);        
  //printf("Converting into binary %s\n",elem_string); ///  
  res_string = paddle_string(elem_string,N); 
  //printf("Paddling 0's %s\n",res_string); ///  
  fprintf(fp,"%s\n",res_string); 

  return;
}

int elem_equal(elem x, elem y){
  if (x == y) return TRUE;
  else return FALSE;
}

int elem_less(elem x, elem y){
  if (x < y) return TRUE;
  else return FALSE;
}
