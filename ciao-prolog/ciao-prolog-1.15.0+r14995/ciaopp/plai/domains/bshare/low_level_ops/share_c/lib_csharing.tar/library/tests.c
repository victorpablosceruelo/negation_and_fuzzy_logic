#include <stdio.h>
#include "csharing_c.h"
#include "common.h"
#include "string.h"

void test_add_copy_remove(){
  SET * sh = set_init();
  int i;
  int N = 31;

  /* add */
  printf("Testing add\n");
  i = 0;
  while (i <= N){
    sh = set_add(sh,(elem) i,5);
    i = i + 2;
    set_print(sh);
  }
  printf("Second part ...\n");
  i = 1;
  while (i <= N){
    sh = set_add(sh,(elem) i,5);
    i = i +2;
    set_print(sh);
  }

  /* copy */ 
  printf("Testing copy \n");
  SET * copy = set_copy(sh);
  set_print(copy);

  /* remove */
  if ((set_remove_all(sh) == NULL) &&  (set_remove_all(copy) == NULL))
    printf("Deleted data structures correctly\n");
  else
    printf("Something failed while deleting ...\n");
  return;

 
}


void test_split_lists(){

  SET * sh = NULL;
  int N = 3;
  elem x = B8(101);  // XZ
  sh = set_init();
  sh = set_add(sh, B8(100),N); // 100 (X)
  sh = set_add(sh, B8(010),N);  // 010 (Y)
  sh = set_add(sh, B8(101),N); // 101 (XZ)
  sh = set_add(sh, B8(111),N); // 111 (XYZ)
  printf("%s\n","Initial sharing");
  set_print(sh);

  SET * rel = NULL;
  SET * irrel =NULL;
  set_split_lists(sh,x,&rel,&irrel);

  printf("and obtaining relevant/irrelevant component wrt");
  elem_print(x,N), printf("\n");
  set_print(rel);
  set_print(irrel);

  return;
}

void test_set_union(){

  SET *sh1 = NULL;
  SET *sh2 = NULL;
  int N = 3;
  sh1 = set_init();
  sh2 = set_init();

  sh1 = set_add(sh1, B8(100),3);  // X
  sh1 = set_add(sh1, B8(010),3);  // Y
  sh1 = set_add(sh1, B8(101),3);  // XZ
  sh1 = set_add(sh1, B8(111),3);  // XYZ

  sh2 = set_add(sh2, B8(100),3);  // X
  sh2 = set_add(sh2, B8(001),3);  // Z
  sh2 = set_add(sh2, B8(010),3);  // Y
  sh2 = set_add(sh2, B8(011),3);  // YZ

  SET * s_union = set_union(sh1,sh2);

  printf("Testing union of sets:\n");
  printf("First set:\n");
  set_print(sh1);
  printf("Second set:\n");
  set_print(sh2);
  printf("Union set:\n");
  set_print(s_union);
  return;
}

void test_binary_union(){

  SET *sh1 = set_init();
  SET *sh2 = set_init();
  int N = 3;
  sh1 = set_add(sh1, B8(100),N);  // X
  sh1 = set_add(sh1, B8(010),N);  // Y
  sh1 = set_add(sh1, B8(110),N);  // XY
  //  sh1 = set_add(sh1, B8(101),N);  // XZ
  //  sh1 = set_add(sh1, B8(111),N);  // XYZ

  //  sh2 = set_add(sh2, B8(100),N);  // X
  sh2 = set_add(sh2, B8(001),N);  // Z
  //  sh2 = set_add(sh2, B8(010),N);  // Y
  //  sh2 = set_add(sh2, B8(011),N);  // YZ

  SET * s_bin_union = set_binary_union(sh1,sh2);

  printf("Testing binary union of sets:\n");
  printf("First set:\n");
  set_print(sh1);
  printf("Second set:\n");
  set_print(sh2);
  printf("Binary Union set:\n");
  set_print(s_bin_union);
  return;
}

void test_star_union(){

  SET *sh = set_init();
  int N = 3;
  printf("Star union experiment 1:\n");
  sh = set_add(sh, B8(100),N);  // X
  sh = set_add(sh, B8(010),N);  // Y
  sh = set_add(sh, B8(001),N);  // Z
  printf("Original set-sharing:\n");
  set_print(sh);
  printf("Star union:\n");
  SET * star = set_star_union(sh);
  set_print(star);
  printf("Star union experiment 2\n:");
  set_remove_all(star);
  set_remove_all(sh);
  sh = set_init();
  int N1 = 5;
  sh = set_add(sh, B8(10000),N1);  // A
  sh = set_add(sh, B8(01000),N1);  // B
  sh = set_add(sh, B8(00100),N1);  // C
  sh = set_add(sh, B8(00010),N1);  // D
  sh = set_add(sh, B8(00001),N1);  // E
  printf("Original set-sharing:\n");
  set_print(sh);
  sh = set_star_union(sh);
  printf("Star union:\n");
  set_print(sh);
  printf("Star union: experiment 3\n");
  set_remove_all(sh);
  sh = set_init();
  printf("Original set-sharing:\n");
  set_print(sh);
  sh = set_star_union(sh);
  printf("Star union:\n");
  set_print(sh);
  return;
}
 
void test_compare(){

  SET *sh1 = set_init();
  SET *sh2 = set_init();
  int N =3 ;
  
  sh1 = set_add(sh1, B8(100),N);  // X
  sh1 = set_add(sh1, B8(010),N);  // Y
  sh1 = set_add(sh1, B8(101),N);  // XZ
  sh1 = set_add(sh1, B8(011),N);  // YZ
  sh1 = set_add(sh1, B8(111),N);  // XYZ

  sh2 = set_add(sh2, B8(100),N);  // X
  sh2 = set_add(sh2, B8(010),N);  // Y
  sh2 = set_add(sh2, B8(101),N);  // XZ
  sh2 = set_add(sh2, B8(011),N);  // YZ
   sh2 = set_add(sh2, B8(111),N);  // XYZ

  if (set_compare(sh1,sh2))
    printf("%s\n", "EQUAL");
  else
    printf("%s\n", "NOT EQUAL");

  set_remove_all(sh1);
  set_remove_all(sh2);

  return;
}




void test_project(){

  SET * sh = set_init();
  int N =3;

  elem x = B8(101);  // XZ
  sh = set_add(sh, B8(100),N); // 100 (X)
  sh = set_add(sh, B8(010),N);  // 010 (Y)
  sh = set_add(sh, B8(101),N); // 101 (XZ)
  sh = set_add(sh, B8(111),N); // 111 (XYZ)
  printf("%s\n","Creating set");
  set_print(sh);
  SET * sh_result = set_project(sh,x);
  printf("%s","Applying rel(sh,");
  elem_print(x,N),
  printf("%s\n",")");
  set_print(sh_result);
  return;
}

void test_amgu(){

  SET *sh = set_init() ;
  int N = 3;
  sh = set_add(sh, B8(100),N); // (X)
  sh = set_add(sh, B8(010),N);  //(Y)
  sh = set_add(sh, B8(001),N); // (Z)
  SET * amgu =  set_amgu(sh,B8(100),B8(000)); // amgu(Sh,X=[])
  set_print(amgu);
  set_remove_all(amgu);
  amgu =  set_amgu(sh,B8(100),B8(010)); // amgu(Sh,X=Y)
  set_print(amgu);
  set_remove_all(sh);
  set_remove_all(amgu);
  return;
}

void test_files(){
  SET * sh = read_file("DB");
  sharing_amgu_prolog("DB","100","000");
  return;

}

void test_ciao_interface(){

  SET * sh = set_init();
  int N =5;

  sh = set_add(sh, B8(01111),N); 
  sh = set_add(sh, B8(10010),N);  
  sh = set_add(sh, B8(10101),N); 
  sh = set_add(sh, B8(10111),N); 
  sh = set_add(sh, B8(10110),N);  
  sh = set_add(sh, B8(10111),N); 

  printf("%s","Creating set:"); set_print(sh);
  ///
  char * sh_coded = set_to_string(sh);
  printf("Coded set: %s\n",sh_coded);
  
   printf("Uncoded set:");
   SET * new_sh = string_to_set(sh_coded);
   set_print(new_sh);
  return;

}

main()
{
  //  test_add_copy_remove();
  //  test_split_lists();
  //  test_set_union();
  //  test_binary_union();
  //  test_star_union();
  //  test_amgu();
  //  test_project();
  //  test_compare();
    test_files();
  //  test_ciao_interface();


  return;
}
      
