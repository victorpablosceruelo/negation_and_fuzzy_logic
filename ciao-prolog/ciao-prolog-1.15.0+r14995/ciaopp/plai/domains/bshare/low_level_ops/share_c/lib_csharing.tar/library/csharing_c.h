#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "bits.h"


typedef struct{ 
  elem first;
  struct LINKED_LIST *next;
} LINKED_LIST;

typedef struct{ 
  int length_vars;    // length of a string
  int card;           // cardinality of the set
  LINKED_LIST *list;  // elements of the set (sorted)
} SET;

// Auxiliary functions
SET * set_init();
SET * set_add(SET * s, elem x, int N);
SET * set_copy(SET*  s);
SET * set_remove_all(SET *s);
void  set_print(SET * set);

// Domain-based operations
SET * set_union(SET * s1, SET * s2); 
void  set_split_lists(SET * s, elem x, SET ** inter, SET ** disj); 
SET * set_binary_union(SET * s1, SET * s2); 
SET * set_star_union(SET * s); 
SET * set_amgu(SET * s, elem x, elem t);
SET * set_project(SET * s, elem x);
int   set_compare(SET * s1, SET *s2); 
/* SET * set_augment(SET *s, int n); */

// Interface operations 
void sharing_amgu_prolog(char* fname, char * x, char * t);


