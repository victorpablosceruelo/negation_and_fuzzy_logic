#include <stdio.h>
#include <stdlib.h>
#include "common.h"

typedef unsigned int elem; 

void elem_fprint(FILE * fp,elem x,int N);
void elem_print(elem r,int N);
int elem_equal(elem x, elem y);
int elem_less(elem x, elem y);
