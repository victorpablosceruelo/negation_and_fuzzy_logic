#if !defined(__CIAO_HEADER__basiccontrol)
#define __CIAO_HEADER__basiccontrol 1
#include <engine/absmach_predef.h>
typedef int32_t intmach_t;
typedef uint32_t uintmach_t;
typedef int32_t intval_t;
typedef uint32_t uintval_t;
typedef uint32_t tagged_t;
typedef uint32_t uinttag_t;
typedef uint32_t functor_t;
typedef int32_t bool_t;
typedef int32_t stagged_t;
typedef uint16_t instance_clock_t;
typedef int64_t intclick_t;
typedef int64_t intfreq_t;
typedef char *bcp_t;
typedef int32_t blob_unit_t;
typedef int32_t signed_bignum_t;
typedef uint32_t bignum_t;
typedef uint16_t bignum_half_t;
typedef uint8_t ftype_typeid_t;
typedef struct fmt fmt_t;
typedef struct ftype_base ftype_base_t;
typedef struct ftype_str ftype_str_t;
typedef struct ftype_array ftype_array_t;
typedef struct ftype_basic ftype_basic_t;
typedef struct ftype_blob ftype_blob_t;
typedef struct absmachdef absmachdef_t;
typedef struct stream_node stream_node_t;
typedef struct io_streams io_streams_t;
typedef struct statistics statistics_t;
typedef struct nestedstack_entry nestedstack_entry_t;
typedef struct misc_info misc_info_t;
typedef struct goal_descriptor goal_descriptor_t;
typedef struct instance instance_t;
typedef union hashtab_val hashtab_val_t;
typedef struct hashtab_node hashtab_node_t;
typedef struct hashtab hashtab_t;
typedef struct instance_handle instance_handle_t;
typedef struct int_info int_info_t;
typedef struct atom atom_t;
typedef struct module module_t;
typedef struct choice choice_t;
typedef union definfo definfo_t;
typedef struct defprops defprops_t;
typedef struct definition definition_t;
typedef struct incore_info incore_info_t;
typedef struct frame frame_t;
typedef struct try_node try_node_t;
typedef struct emul_info emul_info_t;
typedef struct worker worker_t;
typedef bcp_t (*cinsnp0_t)(worker_t *);
typedef void (*cvoid0_t)(worker_t *);
typedef bool_t (*cbool0_t)(worker_t *);
typedef bool_t (*cbool1_t)(worker_t *, uint32_t);
typedef bool_t (*cbool2_t)(worker_t *, uint32_t, uint32_t);
typedef bool_t (*cbool3_t)(worker_t *, uint32_t, uint32_t, uint32_t);
typedef uint32_t (*ctagged1_t)(worker_t *, uint32_t);
typedef uint32_t (*ctagged2_t)(worker_t *, uint32_t, uint32_t);
typedef void (*cvoid_t)(worker_t *);
typedef bool_t (*cbool_t)(worker_t *);
typedef bcp_t (*cinsnp_t)(worker_t *);
struct fmt {
  int32_t type;
  int32_t i;
  int32_t n;
  int32_t value;
};
struct ftype_base {
  int32_t type;
};
struct ftype_str {
  int32_t type;
  int32_t arity;
  uint8_t *args;
};
struct ftype_array {
  int32_t type;
  int32_t itype;
  int32_t argtype;
};
struct ftype_basic {
  int32_t type;
  int32_t size;
  int32_t smethod;
  int32_t lmethod;
};
struct ftype_blob {
  int32_t type;
};
struct absmachdef {
  uint8_t ftype_id_i;
  uint8_t ftype_id_o;
  ftype_base_t **ins_info;
  int32_t ins_n;
  ftype_base_t **ftype_info;
  int32_t ftype_n;
  int32_t q_pad1;
  int32_t q_pad2;
  int32_t tagged_size;
  int32_t size_align;
};
struct stream_node {
  uint32_t label;
  stream_node_t *backward;
  stream_node_t *forward;
  uint32_t streamname;
  char streammode;
  int32_t pending_char;
  unsigned int isatty:1;
  unsigned int socket_eof:1;
  int32_t last_nl_pos;
  int32_t nl_count;
  int32_t char_count;
  FILE *streamfile;
};
struct io_streams {
  stream_node_t *input_stream_ptr;
  stream_node_t *output_stream_ptr;
  stream_node_t *error_stream_ptr;
};
struct statistics {
  int64_t ss_click;
  int32_t ss_global;
  int32_t ss_local;
  int32_t ss_control;
  int64_t gc_click;
  int32_t gc_count;
  int32_t gc_acc;
  int64_t gc_longest_click;
  int64_t startclick;
  int64_t lastclick;
  int64_t startwallclick;
  int64_t lastwallclick;
  int64_t startuserclick;
  int64_t lastuserclick;
  int64_t startsystemclick;
  int64_t lastsystemclick;
  int64_t wallclockfreq;
  int64_t userclockfreq;
  int64_t systemclockfreq;
};
struct nestedstack_entry {
  int32_t p_off;
  uint32_t *s;
};
struct misc_info {
  int32_t gc_total_grey;
  int32_t gcgrey;
  int32_t total_found;
  uint32_t cvas_found;
  choice_t *gc_aux_choice;
  choice_t *gc_choice_start;
  uint32_t *gc_heap_start;
  frame_t *gc_stack_start;
  JMP_BUF *errhandler;
  int32_t errcode;
  char *errfuncname;
  int32_t errfuncarity;
  int32_t errargno;
  uint32_t culprit;
  char *pbuff;
  int32_t pbuff_length;
  nestedstack_entry_t *nestedstack;
  int32_t nestedstack_length;
  int32_t nestedstack_count;
  goal_descriptor_t *goal_desc_ptr;
  worker_t *next_worker;
  int32_t exit_code;
  int32_t stop_this_goal;
};
struct goal_descriptor {
  int32_t goal_number;
  worker_t *worker_registers;
  thread_state_t state;
  THREAD_ID thread_id;
  THREAD_T thread_handle;
  int32_t action;
  uint32_t goal;
  SLOCK goal_lock_l;
  goal_descriptor_t *forward;
  goal_descriptor_t *backward;
};
struct instance {
  instance_t *forward;
  instance_t *backward;
  int_info_t *root;
  instance_t *next_forward;
  instance_t *next_backward;
  uint32_t key;
  uint32_t rank;
  uint16_t birth;
  uint16_t death;
  uint32_t mark;
  instance_handle_t *pending_x2;
  instance_handle_t *pending_x5;
  int32_t objsize;
  char emulcode[0];
};
union hashtab_val {
  try_node_t *try_chain;
  instance_t *instp;
  definition_t *def;
  atom_t *atomp;
  int32_t raw;
  uint32_t tagged;
  hashtab_t *tab;
  void *proc;
  module_t *module;
  int32_t idx;
};
struct hashtab_node {
  uint32_t key;
  hashtab_val_t value;
};
struct hashtab {
  uint32_t mask;
  int32_t count;
  int32_t next_index;
  hashtab_node_t node[0];
};
struct instance_handle {
  instance_t *inst_ptr;
  uint32_t head;
  instance_handle_t *next_handle;
  instance_handle_t *previous_handle;
};
struct int_info {
  volatile Behavior behavior_on_failure;
  CONDITION clause_insertion_cond;
  instance_handle_t *x2_pending_on_instance;
  instance_handle_t *x5_pending_on_instance;
  instance_t *first;
  instance_t *varcase;
  instance_t *lstcase;
  hashtab_t *indexer;
};
struct atom {
  unsigned int has_squote:1;
  unsigned int has_dquote:1;
  unsigned int has_special:1;
  unsigned int index:29;
  LOCK atom_lock_l;
  volatile int atom_lock_counter;
  SLOCK counter_lock;
  uint32_t atom_len;
  char name[0];
};
struct module {
  uint32_t name;
  int32_t defs_count;
  int32_t defs_size;
  definition_t **defs;
  void *so_handle;
  cvoid0_t end_func;
  unsigned int is_static:1;
  unsigned int is_initialized:1;
  unsigned int enable_goaltrans:1;
  time_t timestamp;
  int32_t uses_size;
  uint32_t *uses;
  int32_t instvars_size;
  uint32_t *instvars;
  int32_t instdatas_size;
  uint32_t *instdatas;
  hashtab_t *instvars_table;
  hashtab_t *instdatas_table;
  uint32_t objfunctor;
  hashtab_t *exports;
  hashtab_t *defines;
  hashtab_t *imports;
  hashtab_t *local_cache;
  uint32_t init_name;
  uint32_t end_name;
};
struct choice {
  try_node_t *next_alt;
  int32_t flags;
  uint32_t *trail_top;
  uint32_t *heap_top;
  frame_t *frame;
  char *next_insn;
  frame_t *local_top;
  uint32_t x[0];
};
union definfo {
  char *raw;
  int_info_t *intinfo;
  incore_info_t *incoreinfo;
  void *proc;
};
struct defprops {
  unsigned int hardrtexp:1;
  unsigned int spy:1;
  unsigned int concurrent:1;
  unsigned int dynamic:1;
  unsigned int multifile:1;
  unsigned int nonvar:1;
  unsigned int var:1;
};
struct definition {
  uint16_t enterop;
  uint16_t dummy0;
  uint32_t functor;
  defprops_t properties;
  int32_t predtyp;
  definfo_t code;
};
struct incore_info {
  emul_info_t *clauses;
  emul_info_t **clauses_tail;
  try_node_t *varcase;
  try_node_t *lstcase;
  hashtab_t *othercase;
};
struct frame {
  frame_t *frame;
  char *next_insn;
  uint32_t x[0];
};
struct try_node {
  uint16_t altop;
  uint16_t padding;
  try_node_t *next;
  char *code;
  int32_t arity;
  emul_info_t *clause;
  try_node_t *previous;
};
struct emul_info {
  emul_info_t *next;
  uint32_t mark;
  int32_t objsize;
  char emulcode[0];
};
struct worker {
  misc_info_t *misc;
  io_streams_t *streams;
  uint32_t debugger_mode;
  char *liveinfo;
  char *atom_buffer;
  int32_t atom_buffer_length;
  uint32_t global_vars_root;
  int32_t reg_bank_size;
  void *dummy03;
  choice_t *top_conc_chpt;
  uint32_t *heap_start;
  uint32_t *heap_warn_soft;
  uint32_t *heap_end;
  uint32_t *int_heap_warn;
  uint32_t *stack_start;
  uint32_t *stack_end;
  uint32_t *stack_warn;
  uint32_t *choice_end;
  uint32_t *choice_start;
  uint32_t *trail_start;
  uint32_t *trail_end;
  choice_t *choice;
  choice_t *previous_choice;
  choice_t *segment_choice;
  char *insn;
  uint32_t *structure;
  uint32_t global_uncond;
  uint32_t local_uncond;
  int32_t value_trail;
  instance_t *ins;
  choice_t g;
};
#define Sw_NUMorATM_LST_STR(A0, A1, A2, A3) ({ \
  __label__ Sw_NUMorATM_LST_STR_lab0; \
  if (TagH3_Pre4567_Is67((A0))) { \
    if (TagH3_Pre4567_Is57((A0))) { \
      A3; \
    } else { \
      A2; \
    } \
  } else { \
    A1; \
  } \
  goto Sw_NUMorATM_LST_STR_lab0; \
Sw_NUMorATM_LST_STR_lab0: \
  { } \
})
#define Sw_LSTorSTR_Other(A0, A1, A2) ({ \
  __label__ Sw_LSTorSTR_Other_lab0; \
  if (TagH3_Is67((A0))) { \
    A1; \
  } else { \
    A2; \
  } \
  goto Sw_LSTorSTR_Other_lab0; \
Sw_LSTorSTR_Other_lab0: \
  { } \
})
#define Sw_HVAorCVAorSVA_NVA(A0, A1, A2) ({ \
  __label__ Sw_HVAorCVAorSVA_NVA_lab0; \
  if (TagH3_Is0123((A0))) { \
    A1; \
  } else { \
    A2; \
  } \
  goto Sw_HVAorCVAorSVA_NVA_lab0; \
Sw_HVAorCVAorSVA_NVA_lab0: \
  { } \
})
#define Sw_HVA_CVA_SVA_Other(A0, A1, A2, A3, A4) ({ \
  __label__ Sw_HVA_CVA_SVA_Other_lab0; \
  if (TagH3_Is4567((A0))) { \
    A4; \
  } else { \
    if (TagH3_Pre012_Is2((A0))) { \
      A3; \
    } else { \
      if (TagH3_Pre012_Is02((A0))) { \
        A1; \
      } else { \
        A2; \
      } \
    } \
  } \
  goto Sw_HVA_CVA_SVA_Other_lab0; \
Sw_HVA_CVA_SVA_Other_lab0: \
  { } \
})
#define SwHVAorCVAorSVA_HVA_CVA_SVA(A0, A1, A2, A3) ({ \
  __label__ SwHVAorCVAorSVA_HVA_CVA_SVA_lab0; \
  if (TagH3_Pre012_Is2((A0))) { \
    A3; \
  } else { \
    if (TagH3_Pre012_Is02((A0))) { \
      A1; \
    } else { \
      A2; \
    } \
  } \
  goto SwHVAorCVAorSVA_HVA_CVA_SVA_lab0; \
SwHVAorCVAorSVA_HVA_CVA_SVA_lab0: \
  { } \
})
#define Sw_HVA_CVA_Other(A0, A1, A2, A3) ({ \
  __label__ Sw_HVA_CVA_Other_lab0; \
  if (TagH3_Is4567((A0))) { \
    A3; \
  } else { \
    if (TagH3_Pre012_Is02((A0))) { \
      A1; \
    } else { \
      A2; \
    } \
  } \
  goto Sw_HVA_CVA_Other_lab0; \
Sw_HVA_CVA_Other_lab0: \
  { } \
})
#define Sw_HVA_CVA(A0, A1, A2) ({ \
  __label__ Sw_HVA_CVA_lab0; \
  if (TagH3_Pre012_Is1((A0))) { \
    A2; \
  } else { \
    A1; \
  } \
  goto Sw_HVA_CVA_lab0; \
Sw_HVA_CVA_lab0: \
  { } \
})
#define Sw_NUM_ATM_LST_STR(A0, A1, A2, A3, A4) ({ \
  __label__ Sw_NUM_ATM_LST_STR_lab0; \
  if (TagH3_Pre4567_Is45((A0))) { \
    if (TagH3_Pre4567_Is57((A0))) { \
      A2; \
    } else { \
      A1; \
    } \
  } else { \
    if (TagH3_Pre4567_Is46((A0))) { \
      A3; \
    } else { \
      A4; \
    } \
  } \
  goto Sw_NUM_ATM_LST_STR_lab0; \
Sw_NUM_ATM_LST_STR_lab0: \
  { } \
})
#define Sw_CVA_HVAorSVA(A0, A1, A2) ({ \
  __label__ Sw_CVA_HVAorSVA_lab0; \
  if (TagH3_Pre012_Is1((A0))) { \
    A1; \
  } else { \
    A2; \
  } \
  goto Sw_CVA_HVAorSVA_lab0; \
Sw_CVA_HVAorSVA_lab0: \
  { } \
})
#define Sw_HVAorCVA_SVA_STR(A0, A1, A2, A3) ({ \
  __label__ Sw_HVAorCVA_SVA_STR_lab0; \
  if (TagH3_Is01((A0))) { \
    A1; \
  } else { \
    if (TagH3_Pre0124567_Is2((A0))) { \
      A2; \
    } else { \
      A3; \
    } \
  } \
  goto Sw_HVAorCVA_SVA_STR_lab0; \
Sw_HVAorCVA_SVA_STR_lab0: \
  { } \
})
#define Sw_HVAorCVAorSVA_STR(A0, A1, A2) ({ \
  __label__ Sw_HVAorCVAorSVA_STR_lab0; \
  if (TagH3_Is0123((A0))) { \
    A1; \
  } else { \
    A2; \
  } \
  goto Sw_HVAorCVAorSVA_STR_lab0; \
Sw_HVAorCVAorSVA_STR_lab0: \
  { } \
})
#define Sw_CVA_HVAorSVA_Other(A0, A1, A2, A3) ({ \
  __label__ Sw_CVA_HVAorSVA_Other_lab0; \
  if (TagH3_Is0123((A0))) { \
    if (TagH3_Pre012_Is1((A0))) { \
      A1; \
    } else { \
      A2; \
    } \
  } else { \
    A3; \
  } \
  goto Sw_CVA_HVAorSVA_Other_lab0; \
Sw_CVA_HVAorSVA_Other_lab0: \
  { } \
})
#define Sw_LST_STR_Other(A0, A1, A2, A3) ({ \
  __label__ Sw_LST_STR_Other_lab0; \
  if (TagH3_Is7((A0))) { \
    A2; \
  } else { \
    if (TagH3_Is67((A0))) { \
      A1; \
    } else { \
      A3; \
    } \
  } \
  goto Sw_LST_STR_Other_lab0; \
Sw_LST_STR_Other_lab0: \
  { } \
})
#define Sw_LST_STR(A0, A1, A2) ({ \
  __label__ Sw_LST_STR_lab0; \
  if (TagH3_Pre4567_Is57((A0))) { \
    A2; \
  } else { \
    A1; \
  } \
  goto Sw_LST_STR_lab0; \
Sw_LST_STR_lab0: \
  { } \
})
#define Sw_STR_LST_ATM_Other(A0, A1, A2, A3, A4) ({ \
  __label__ Sw_STR_LST_ATM_Other_lab0; \
  if (TagH3_Is7((A0))) { \
    A1; \
  } else { \
    if (TagH3_Is67((A0))) { \
      A2; \
    } else { \
      if (TagH3_Is5((A0))) { \
        A3; \
      } else { \
        A4; \
      } \
    } \
  } \
  goto Sw_STR_LST_ATM_Other_lab0; \
Sw_STR_LST_ATM_Other_lab0: \
  { } \
})
#define Sw_STR_LST_ATM(A0, A1, A2, A3) ({ \
  __label__ Sw_STR_LST_ATM_lab0; \
  if (TagH3_Is7((A0))) { \
    A1; \
  } else { \
    if (TagH3_Pre4567_Is46((A0))) { \
      A2; \
    } else { \
      A3; \
    } \
  } \
  goto Sw_STR_LST_ATM_lab0; \
Sw_STR_LST_ATM_lab0: \
  { } \
})
#define Sw_HVA_SVA_CVA_NUM_ATM_LST_STR(A0, A1, A2, A3, A4, A5, A6, A7) ({ \
  __label__ Sw_HVA_SVA_CVA_NUM_ATM_LST_STR_lab0; \
  switch(TagOf((A0))) { \
  case TAG(hva): \
    { \
      A1; \
      break; \
    } \
  case TAG(sva): \
    { \
      A2; \
      break; \
    } \
  case TAG(cva): \
    { \
      A3; \
      break; \
    } \
  case TAG(num): \
    { \
      A4; \
      break; \
    } \
  case TAG(atm): \
    { \
      A5; \
      break; \
    } \
  case TAG(lst): \
    { \
      A6; \
      break; \
    } \
  default: \
    A7; \
  } \
  goto Sw_HVA_SVA_CVA_NUM_ATM_LST_STR_lab0; \
Sw_HVA_SVA_CVA_NUM_ATM_LST_STR_lab0: \
  { } \
})
#define Sw_NUMorATM_STR_Other(A0, A1, A2, A3) ({ \
  __label__ Sw_NUMorATM_STR_Other_lab0; \
  if (TagH3_Is45((A0))) { \
    A1; \
  } else { \
    if (TagH3_Is7((A0))) { \
      A2; \
    } else { \
      A3; \
    } \
  } \
  goto Sw_NUMorATM_STR_Other_lab0; \
Sw_NUMorATM_STR_Other_lab0: \
  { } \
})
#define Sw_NUM_STR_Other(A0, A1, A2, A3) ({ \
  __label__ Sw_NUM_STR_Other_lab0; \
  if (TagH3_Is7((A0))) { \
    A2; \
  } else { \
    if (TagH3_Is4((A0))) { \
      A1; \
    } else { \
      A3; \
    } \
  } \
  goto Sw_NUM_STR_Other_lab0; \
Sw_NUM_STR_Other_lab0: \
  { } \
})
#define GetFrameTop(A0, A1, A2) ({ \
  __label__ GetFrameTop_lab0; \
  __label__ GetFrameTop_lab1; \
  __label__ GetFrameTop_lab2; \
  __label__ GetFrameTop_lab3; \
  if (ValidLocalTop()) goto GetFrameTop_lab0; else goto GetFrameTop_lab1; \
GetFrameTop_lab0: \
  (A0) = G->local_top; \
  goto GetFrameTop_lab3; \
GetFrameTop_lab1: \
  (A0) = (A1)->local_top; \
  if (StackYounger((A0), (A2))) goto GetFrameTop_lab3; else goto GetFrameTop_lab2; \
GetFrameTop_lab2: \
  (A0) = StackCharOffset((A2), FrameSize(G->next_insn)); \
  goto GetFrameTop_lab3; \
GetFrameTop_lab3: \
  { } \
})
#define SetLocalTop(A0) ({ \
  __label__ SetLocalTop_lab0; \
  G->local_top = (A0); \
  goto SetLocalTop_lab0; \
SetLocalTop_lab0: \
  { } \
})
#define UpdateLocalTop(A0, A1) ({ \
  __label__ UpdateLocalTop_lab0; \
  __label__ UpdateLocalTop_lab1; \
  __label__ UpdateLocalTop_lab2; \
  __label__ UpdateLocalTop_lab3; \
  if (ValidLocalTop()) goto UpdateLocalTop_lab0; else goto UpdateLocalTop_lab1; \
UpdateLocalTop_lab0: \
  G->local_top = G->local_top; \
  goto UpdateLocalTop_lab3; \
UpdateLocalTop_lab1: \
  G->local_top = (A0)->local_top; \
  if (StackYounger(G->local_top, (A1))) goto UpdateLocalTop_lab3; else goto UpdateLocalTop_lab2; \
UpdateLocalTop_lab2: \
  G->local_top = StackCharOffset((A1), FrameSize(G->next_insn)); \
  goto UpdateLocalTop_lab3; \
UpdateLocalTop_lab3: \
  { } \
})
#define CODE_ALLOC(A0) ({ \
  __label__ CODE_ALLOC_lab0; \
  __label__ CODE_ALLOC_lab1; \
  __label__ CODE_ALLOC_lab2; \
  __label__ CODE_ALLOC_lab3; \
  if (ValidLocalTop()) goto CODE_ALLOC_lab0; else goto CODE_ALLOC_lab1; \
CODE_ALLOC_lab0: \
  (A0) = G->local_top; \
  goto CODE_ALLOC_lab3; \
CODE_ALLOC_lab1: \
  (A0) = w->choice->local_top; \
  if (StackYounger((A0), G->frame)) goto CODE_ALLOC_lab3; else goto CODE_ALLOC_lab2; \
CODE_ALLOC_lab2: \
  (A0) = StackCharOffset(G->frame, FrameSize(G->next_insn)); \
  goto CODE_ALLOC_lab3; \
CODE_ALLOC_lab3: \
  { } \
})
#define CODE_CHOICE_NEW(A0, A1) ({ \
  __label__ CODE_CHOICE_NEW_lab0; \
  __label__ CODE_CHOICE_NEW_lab1; \
  __label__ CODE_CHOICE_NEW_lab2; \
  __label__ CODE_CHOICE_NEW_lab3; \
  __label__ CODE_CHOICE_NEW_lab4; \
  if (ValidLocalTop()) goto CODE_CHOICE_NEW_lab0; else goto CODE_CHOICE_NEW_lab1; \
CODE_CHOICE_NEW_lab0: \
  G->local_top = G->local_top; \
  goto CODE_CHOICE_NEW_lab3; \
CODE_CHOICE_NEW_lab1: \
  G->local_top = w->choice->local_top; \
  if (StackYounger(G->local_top, G->frame)) goto CODE_CHOICE_NEW_lab3; else goto CODE_CHOICE_NEW_lab2; \
CODE_CHOICE_NEW_lab2: \
  G->local_top = StackCharOffset(G->frame, FrameSize(G->next_insn)); \
  goto CODE_CHOICE_NEW_lab3; \
CODE_CHOICE_NEW_lab3: \
  G->next_alt = (A1); \
  (A0) = ChoiceNext0(w->choice, (A1)->arity); \
  (A0)->flags = 0; \
  (A0)->trail_top = G->trail_top; \
  (A0)->local_top = G->local_top; \
  (A0)->heap_top = G->heap_top; \
  SetShallowTry(); \
  w->global_uncond = Tagp(0, (A0)->heap_top); \
  w->local_uncond = Tagp(2, (A0)->local_top); \
  w->choice = (A0); \
  TEST_CHOICE_OVERFLOW((A0), CHOICEPAD); \
  goto CODE_CHOICE_NEW_lab4; \
CODE_CHOICE_NEW_lab4: \
  { } \
})
#define CODE_CHOICE_NEW0(A0, A1, A2) ({ \
  __label__ CODE_CHOICE_NEW0_lab0; \
  G->next_alt = (A2); \
  (A0) = ChoiceNext0((A1), (A2)->arity); \
  (A0)->flags = 0; \
  (A0)->trail_top = G->trail_top; \
  (A0)->local_top = G->local_top; \
  (A0)->heap_top = G->heap_top; \
  SetShallowTry(); \
  w->global_uncond = Tagp(0, (A0)->heap_top); \
  w->local_uncond = Tagp(2, (A0)->local_top); \
  w->choice = (A0); \
  goto CODE_CHOICE_NEW0_lab0; \
CODE_CHOICE_NEW0_lab0: \
  { } \
})
#define CODE_CHOICE_PATCH(A0, A1) ({ \
  __label__ CODE_CHOICE_PATCH_lab0; \
  (A0)->next_alt = (A1); \
  G->next_alt = (A1); \
  goto CODE_CHOICE_PATCH_lab0; \
CODE_CHOICE_PATCH_lab0: \
  { } \
})
#define SetChoice(A0) ({ \
  __label__ SetChoice_lab0; \
  G->next_alt = (A0)->next_alt; \
  w->global_uncond = Tagp(0, (A0)->heap_top); \
  w->local_uncond = Tagp(2, (A0)->local_top); \
  w->choice = (A0); \
  goto SetChoice_lab0; \
SetChoice_lab0: \
  { } \
})
#define HeapPush(A0, A1) ({ \
  __label__ HeapPush_lab0; \
  *(A0) = (A1); \
  (A0) = (A0) + 1; \
  goto HeapPush_lab0; \
HeapPush_lab0: \
  { } \
})
#define ConstrHVA(A0) ({ \
  __label__ ConstrHVA_lab0; \
  *(A0) = Tagp(0, (A0)); \
  (A0) = (A0) + 1; \
  goto ConstrHVA_lab0; \
ConstrHVA_lab0: \
  { } \
})
#define LoadHVA(A0, A1) ({ \
  __label__ LoadHVA_lab0; \
  uint32_t LoadHVA_var0; \
  LoadHVA_var0 = Tagp(0, (A1)); \
  (A0) = LoadHVA_var0; \
  *(A1) = LoadHVA_var0; \
  (A1) = (A1) + 1; \
  goto LoadHVA_lab0; \
LoadHVA_lab0: \
  { } \
})
#define LoadCVA(A0, A1) ({ \
  __label__ LoadCVA_lab0; \
  uint32_t LoadCVA_var0; \
  LoadCVA_var0 = Tagp(1, (A1)); \
  (A0) = LoadCVA_var0; \
  *(A1) = LoadCVA_var0; \
  (A1) = (A1) + 1; \
  goto LoadCVA_lab0; \
LoadCVA_lab0: \
  { } \
})
#define Unify_local_value(A0, A1) ({ \
  __label__ Unify_local_value_lab0; \
  __label__ Unify_local_value_lab1; \
  __label__ Unify_local_value_lab2; \
  __label__ Unify_local_value_lab3; \
  __label__ Unify_local_value_lab4; \
  uint32_t Unify_local_value_var0; \
  DerefUpToSVA_Sw_SVA_Other((A0), goto Unify_local_value_lab0;, goto Unify_local_value_lab3;); \
Unify_local_value_lab0: \
  Unify_local_value_var0 = (A0); \
  if (CondSVA(Unify_local_value_var0)) goto Unify_local_value_lab1; else goto Unify_local_value_lab2; \
Unify_local_value_lab1: \
  trail_push_check(w, Unify_local_value_var0); \
  goto Unify_local_value_lab2; \
Unify_local_value_lab2: \
  *TagpPtr(2, Unify_local_value_var0) = Tagp(0, (A1)); \
  (A0) = Tagp(0, (A1)); \
  goto Unify_local_value_lab3; \
Unify_local_value_lab3: \
  *(A1) = (A0); \
  (A1) = (A1) + 1; \
  goto Unify_local_value_lab4; \
Unify_local_value_lab4: \
  { } \
})
#define CBOOL__UnifyCons(A0, A1) ({ \
  __label__ CBOOL__UnifyCons_lab0; \
  __label__ CBOOL__UnifyCons_lab1; \
  __label__ CBOOL__UnifyCons_lab2; \
  __label__ CBOOL__UnifyCons_lab3; \
  __label__ CBOOL__UnifyCons_lab4; \
  __label__ CBOOL__UnifyCons_lab5; \
  __label__ CBOOL__UnifyCons_lab6; \
  __label__ CBOOL__UnifyCons_lab7; \
  __label__ CBOOL__UnifyCons_lab8; \
  __label__ CBOOL__UnifyCons_lab9; \
  uint32_t CBOOL__UnifyCons_var0; \
  uint32_t CBOOL__UnifyCons_var1; \
  CBOOL__UnifyCons_var0 = (A0); \
  CBOOL__UnifyCons_var1 = (A1); \
  DerefSw_HVA_CVA_SVA_Other(CBOOL__UnifyCons_var1, goto CBOOL__UnifyCons_lab0;, goto CBOOL__UnifyCons_lab3;, goto CBOOL__UnifyCons_lab4;, goto CBOOL__UnifyCons_lab7;); \
CBOOL__UnifyCons_lab0: \
  if (CondHVA(CBOOL__UnifyCons_var1)) goto CBOOL__UnifyCons_lab1; else goto CBOOL__UnifyCons_lab2; \
CBOOL__UnifyCons_lab1: \
  trail_push_check(w, CBOOL__UnifyCons_var1); \
  goto CBOOL__UnifyCons_lab2; \
CBOOL__UnifyCons_lab2: \
  *TagpPtr(0, CBOOL__UnifyCons_var1) = CBOOL__UnifyCons_var0; \
  goto CBOOL__UnifyCons_lab9; \
CBOOL__UnifyCons_lab3: \
  trail_push_check(w, CBOOL__UnifyCons_var1); \
  *TagpPtr(1, CBOOL__UnifyCons_var1) = CBOOL__UnifyCons_var0; \
  IncWakeCount(); \
  goto CBOOL__UnifyCons_lab9; \
CBOOL__UnifyCons_lab4: \
  if (CondSVA(CBOOL__UnifyCons_var1)) goto CBOOL__UnifyCons_lab5; else goto CBOOL__UnifyCons_lab6; \
CBOOL__UnifyCons_lab5: \
  trail_push_check(w, CBOOL__UnifyCons_var1); \
  goto CBOOL__UnifyCons_lab6; \
CBOOL__UnifyCons_lab6: \
  *TagpPtr(2, CBOOL__UnifyCons_var1) = CBOOL__UnifyCons_var0; \
  goto CBOOL__UnifyCons_lab9; \
CBOOL__UnifyCons_lab7: \
  if (CBOOL__UnifyCons_var1 == CBOOL__UnifyCons_var0) goto CBOOL__UnifyCons_lab9; else goto CBOOL__UnifyCons_lab8; \
CBOOL__UnifyCons_lab8: \
  return FALSE; \
CBOOL__UnifyCons_lab9: \
  { } \
})
#define DEALLOCATE(A0) ({ \
  __label__ DEALLOCATE_lab0; \
  G->next_insn = (A0)->next_insn; \
  G->frame = (A0)->frame; \
  goto DEALLOCATE_lab0; \
DEALLOCATE_lab0: \
  { } \
})
#define MakeLST(A0, A1, A2) ({ \
  __label__ MakeLST_lab0; \
  uint32_t MakeLST_var0; \
  MakeLST_var0 = (A1); \
  *G->heap_top = MakeLST_var0; \
  G->heap_top = G->heap_top + 1; \
  *G->heap_top = (A2); \
  G->heap_top = G->heap_top + 1; \
  (A0) = Tagp(6, HeapCharOffset(G->heap_top, -2 * 4)); \
  goto MakeLST_lab0; \
MakeLST_lab0: \
  { } \
})
#define MakeSTR(A0, A1) ({ \
  __label__ MakeSTR_lab0; \
  *G->heap_top = (A1); \
  G->heap_top = G->heap_top + 1; \
  (A0) = Tagp(7, HeapCharOffset(G->heap_top, -1 * 4)); \
  G->heap_top = HeapCharOffset(G->heap_top, Arity((A1)) * 4); \
  goto MakeSTR_lab0; \
MakeSTR_lab0: \
  { } \
})
#define CODE_MAYBE_NECK_TRY() ({ \
  __label__ CODE_MAYBE_NECK_TRY_lab0; \
  __label__ CODE_MAYBE_NECK_TRY_lab1; \
  __label__ CODE_MAYBE_NECK_TRY_lab2; \
  __label__ CODE_MAYBE_NECK_TRY_lab3; \
  choice_t *CODE_MAYBE_NECK_TRY_var0; \
  int32_t CODE_MAYBE_NECK_TRY_var1; \
  int32_t CODE_MAYBE_NECK_TRY_var2; \
  if (IsShallowTry()) goto CODE_MAYBE_NECK_TRY_lab0; else goto CODE_MAYBE_NECK_TRY_lab3; \
CODE_MAYBE_NECK_TRY_lab0: \
  CODE_MAYBE_NECK_TRY_var0 = w->choice; \
  CODE_MAYBE_NECK_TRY_var0->frame = G->frame; \
  CODE_MAYBE_NECK_TRY_var0->next_insn = G->next_insn; \
  CODE_MAYBE_NECK_TRY_var0->next_alt = G->next_alt; \
  CODE_MAYBE_NECK_TRY_var1 = ChoiceArity(CODE_MAYBE_NECK_TRY_var0); \
  CODE_MAYBE_NECK_TRY_var2 = 0; \
  goto CODE_MAYBE_NECK_TRY_lab1; \
CODE_MAYBE_NECK_TRY_lab1: \
  if (CODE_MAYBE_NECK_TRY_var2 < CODE_MAYBE_NECK_TRY_var1) goto CODE_MAYBE_NECK_TRY_lab2; else goto CODE_MAYBE_NECK_TRY_lab3; \
CODE_MAYBE_NECK_TRY_lab2: \
  CODE_MAYBE_NECK_TRY_var0->x[CODE_MAYBE_NECK_TRY_var2] = G->x[CODE_MAYBE_NECK_TRY_var2]; \
  CODE_MAYBE_NECK_TRY_var2 = CODE_MAYBE_NECK_TRY_var2 + 1; \
  goto CODE_MAYBE_NECK_TRY_lab1; \
CODE_MAYBE_NECK_TRY_lab3: \
  { } \
})
#define CODE_NECK_TRY(A0) ({ \
  __label__ CODE_NECK_TRY_lab0; \
  __label__ CODE_NECK_TRY_lab1; \
  __label__ CODE_NECK_TRY_lab2; \
  int32_t CODE_NECK_TRY_var0; \
  int32_t CODE_NECK_TRY_var1; \
  (A0)->frame = G->frame; \
  (A0)->next_insn = G->next_insn; \
  (A0)->next_alt = G->next_alt; \
  CODE_NECK_TRY_var0 = ChoiceArity((A0)); \
  CODE_NECK_TRY_var1 = 0; \
  goto CODE_NECK_TRY_lab0; \
CODE_NECK_TRY_lab0: \
  if (CODE_NECK_TRY_var1 < CODE_NECK_TRY_var0) goto CODE_NECK_TRY_lab1; else goto CODE_NECK_TRY_lab2; \
CODE_NECK_TRY_lab1: \
  (A0)->x[CODE_NECK_TRY_var1] = G->x[CODE_NECK_TRY_var1]; \
  CODE_NECK_TRY_var1 = CODE_NECK_TRY_var1 + 1; \
  goto CODE_NECK_TRY_lab0; \
CODE_NECK_TRY_lab2: \
  { } \
})
#define CODE_CFRAME(A0, A1) ({ \
  __label__ CODE_CFRAME_lab0; \
  __label__ CODE_CFRAME_lab1; \
  (A0)->next_insn = G->next_insn; \
  (A0)->frame = G->frame; \
  G->frame = (A0); \
  G->next_insn = (A1); \
  G->local_top = StackCharOffset((A0), FrameSize(G->next_insn)); \
  if (OffStacktop((A0), Stack_Warn)) goto CODE_CFRAME_lab0; else goto CODE_CFRAME_lab1; \
CODE_CFRAME_lab0: \
  SetEvent(); \
  goto CODE_CFRAME_lab1; \
CODE_CFRAME_lab1: \
  { } \
})
#define CODE_CUT(A0) ({ \
  __label__ CODE_CUT_lab0; \
  choice_t *CODE_CUT_var0; \
  CODE_CUT_var0 = (A0); \
  G->next_alt = CODE_CUT_var0->next_alt; \
  w->global_uncond = Tagp(0, CODE_CUT_var0->heap_top); \
  w->local_uncond = Tagp(2, CODE_CUT_var0->local_top); \
  w->choice = CODE_CUT_var0; \
  DEBUG_CUT(CODE_CUT_var0); \
  ConcChptCleanUp(TopConcChptFun(), CODE_CUT_var0); \
  SetDeep(); \
  goto CODE_CUT_lab0; \
CODE_CUT_lab0: \
  { } \
})
#define CODE_NEXT_INSTANCE() ({ \
  __label__ CODE_NEXT_INSTANCE_lab0; \
  __label__ CODE_NEXT_INSTANCE_lab1; \
  __label__ CODE_NEXT_INSTANCE_lab2; \
  __label__ CODE_NEXT_INSTANCE_lab3; \
  __label__ CODE_NEXT_INSTANCE_lab4; \
  __label__ CODE_NEXT_INSTANCE_lab5; \
  __label__ CODE_NEXT_INSTANCE_lab6; \
  __label__ CODE_NEXT_INSTANCE_lab7; \
  __label__ CODE_NEXT_INSTANCE_lab8; \
  __label__ CODE_NEXT_INSTANCE_lab9; \
  __label__ CODE_NEXT_INSTANCE_lab10; \
  __label__ CODE_NEXT_INSTANCE_lab11; \
  __label__ CODE_NEXT_INSTANCE_lab12; \
  __label__ CODE_NEXT_INSTANCE_lab13; \
  __label__ CODE_NEXT_INSTANCE_lab14; \
  __label__ CODE_NEXT_INSTANCE_lab15; \
  __label__ CODE_NEXT_INSTANCE_lab16; \
  uint32_t *CODE_NEXT_INSTANCE_var0; \
  uint32_t *CODE_NEXT_INSTANCE_var1; \
  uint32_t CODE_NEXT_INSTANCE_var2; \
  frame_t *CODE_NEXT_INSTANCE_var3; \
  int32_t CODE_NEXT_INSTANCE_var4; \
  int32_t CODE_NEXT_INSTANCE_var5; \
  try_node_t *CODE_NEXT_INSTANCE_var6; \
  ResetWakeCount(); \
  CODE_NEXT_INSTANCE_var0 = G->trail_top; \
  CODE_NEXT_INSTANCE_var1 = w->choice->trail_top; \
  if (TrailYounger(CODE_NEXT_INSTANCE_var0, CODE_NEXT_INSTANCE_var1)) goto CODE_NEXT_INSTANCE_lab0; else goto CODE_NEXT_INSTANCE_lab10; \
CODE_NEXT_INSTANCE_lab0: \
  TrailDec(CODE_NEXT_INSTANCE_var0); \
  CODE_NEXT_INSTANCE_var2 = *CODE_NEXT_INSTANCE_var0; \
  if (IsVar(CODE_NEXT_INSTANCE_var2)) goto CODE_NEXT_INSTANCE_lab8; else goto CODE_NEXT_INSTANCE_lab1; \
CODE_NEXT_INSTANCE_lab1: \
  G->trail_top = CODE_NEXT_INSTANCE_var0; \
  X(0) = CODE_NEXT_INSTANCE_var2; \
  G->frame = w->choice->frame; \
  G->next_insn = w->choice->next_insn; \
  G->next_alt = w->choice->next_alt; \
  w->choice = w->choice; \
  if (ValidLocalTop()) goto CODE_NEXT_INSTANCE_lab2; else goto CODE_NEXT_INSTANCE_lab3; \
CODE_NEXT_INSTANCE_lab2: \
  CODE_NEXT_INSTANCE_var3 = G->local_top; \
  goto CODE_NEXT_INSTANCE_lab5; \
CODE_NEXT_INSTANCE_lab3: \
  CODE_NEXT_INSTANCE_var3 = w->choice->local_top; \
  if (StackYounger(CODE_NEXT_INSTANCE_var3, G->frame)) goto CODE_NEXT_INSTANCE_lab5; else goto CODE_NEXT_INSTANCE_lab4; \
CODE_NEXT_INSTANCE_lab4: \
  CODE_NEXT_INSTANCE_var3 = StackCharOffset(G->frame, FrameSize(G->next_insn)); \
  goto CODE_NEXT_INSTANCE_lab5; \
CODE_NEXT_INSTANCE_lab5: \
  CODE_NEXT_INSTANCE_var3->next_insn = G->next_insn; \
  CODE_NEXT_INSTANCE_var3->frame = G->frame; \
  G->frame = CODE_NEXT_INSTANCE_var3; \
  G->next_insn = failcode; \
  G->local_top = StackCharOffset(CODE_NEXT_INSTANCE_var3, FrameSize(G->next_insn)); \
  if (OffStacktop(CODE_NEXT_INSTANCE_var3, Stack_Warn)) goto CODE_NEXT_INSTANCE_lab6; else goto CODE_NEXT_INSTANCE_lab7; \
CODE_NEXT_INSTANCE_lab6: \
  SetEvent(); \
  goto CODE_NEXT_INSTANCE_lab7; \
CODE_NEXT_INSTANCE_lab7: \
  return (*(cinsnp0_t)code_call1)(w); \
CODE_NEXT_INSTANCE_lab8: \
  *TaggedToPointer(CODE_NEXT_INSTANCE_var2) = CODE_NEXT_INSTANCE_var2; \
  if (TrailYounger(CODE_NEXT_INSTANCE_var0, CODE_NEXT_INSTANCE_var1)) goto CODE_NEXT_INSTANCE_lab0; else goto CODE_NEXT_INSTANCE_lab9; \
CODE_NEXT_INSTANCE_lab9: \
  G->trail_top = CODE_NEXT_INSTANCE_var0; \
  goto CODE_NEXT_INSTANCE_lab10; \
CODE_NEXT_INSTANCE_lab10: \
  G->heap_top = w->choice->heap_top; \
  if (IsDeep()) goto CODE_NEXT_INSTANCE_lab11; else goto CODE_NEXT_INSTANCE_lab14; \
CODE_NEXT_INSTANCE_lab11: \
  DEBUG_DEEP_BACKTRACKING(); \
  CODE_NEXT_INSTANCE_var4 = ChoiceArity(w->choice); \
  w->previous_choice = ChoiceCont0(w->choice, CODE_NEXT_INSTANCE_var4); \
  SetShallowRetry(); \
  G->frame = w->choice->frame; \
  G->next_insn = w->choice->next_insn; \
  G->next_alt = w->choice->next_alt; \
  G->local_top = w->choice->local_top; \
  CODE_NEXT_INSTANCE_var5 = 0; \
  goto CODE_NEXT_INSTANCE_lab12; \
CODE_NEXT_INSTANCE_lab12: \
  if (CODE_NEXT_INSTANCE_var5 < CODE_NEXT_INSTANCE_var4) goto CODE_NEXT_INSTANCE_lab13; else goto CODE_NEXT_INSTANCE_lab14; \
CODE_NEXT_INSTANCE_lab13: \
  G->x[CODE_NEXT_INSTANCE_var5] = w->choice->x[CODE_NEXT_INSTANCE_var5]; \
  CODE_NEXT_INSTANCE_var5 = CODE_NEXT_INSTANCE_var5 + 1; \
  goto CODE_NEXT_INSTANCE_lab12; \
CODE_NEXT_INSTANCE_lab14: \
  CODE_NEXT_INSTANCE_var6 = G->next_alt; \
  w->choice->next_alt = CODE_NEXT_INSTANCE_var6->next; \
  G->next_alt = CODE_NEXT_INSTANCE_var6->next; \
  if (TaggedToRoot(X(RootArg))->behavior_on_failure == DYNAMIC) goto CODE_NEXT_INSTANCE_lab15; else goto CODE_NEXT_INSTANCE_lab16; \
CODE_NEXT_INSTANCE_lab15: \
  return next_instance_noconc(w); \
CODE_NEXT_INSTANCE_lab16: \
  return next_instance_conc(w); \
})
#define BindHVA(A0, A1) ({ \
  __label__ BindHVA_lab0; \
  __label__ BindHVA_lab1; \
  __label__ BindHVA_lab2; \
  if (CondHVA((A0))) goto BindHVA_lab0; else goto BindHVA_lab1; \
BindHVA_lab0: \
  trail_push_check(w, (A0)); \
  goto BindHVA_lab1; \
BindHVA_lab1: \
  *TagpPtr(0, (A0)) = (A1); \
  goto BindHVA_lab2; \
BindHVA_lab2: \
  { } \
})
#define BindCVANoWake(A0, A1) ({ \
  __label__ BindCVANoWake_lab0; \
  trail_push_check(w, (A0)); \
  *TagpPtr(1, (A0)) = (A1); \
  goto BindCVANoWake_lab0; \
BindCVANoWake_lab0: \
  { } \
})
#define BindCVA(A0, A1) ({ \
  __label__ BindCVA_lab0; \
  trail_push_check(w, (A0)); \
  *TagpPtr(1, (A0)) = (A1); \
  IncWakeCount(); \
  goto BindCVA_lab0; \
BindCVA_lab0: \
  { } \
})
#define BindSVA(A0, A1) ({ \
  __label__ BindSVA_lab0; \
  __label__ BindSVA_lab1; \
  __label__ BindSVA_lab2; \
  if (CondSVA((A0))) goto BindSVA_lab0; else goto BindSVA_lab1; \
BindSVA_lab0: \
  trail_push_check(w, (A0)); \
  goto BindSVA_lab1; \
BindSVA_lab1: \
  *TagpPtr(2, (A0)) = (A1); \
  goto BindSVA_lab2; \
BindSVA_lab2: \
  { } \
})
#define TrailPushCheck(A0) ({ \
  __label__ TrailPushCheck_lab0; \
  trail_push_check(w, (A0)); \
  goto TrailPushCheck_lab0; \
TrailPushCheck_lab0: \
  { } \
})
#define worker_t__SET_TAILED_SIZE(A0, A1) ({ \
  __label__ worker_t__SET_TAILED_SIZE_lab0; \
  (A0)->reg_bank_size = (A1); \
  goto worker_t__SET_TAILED_SIZE_lab0; \
worker_t__SET_TAILED_SIZE_lab0: \
  { } \
})
#define instance_t__SET_TAILED_SIZE(A0, A1) ({ \
  __label__ instance_t__SET_TAILED_SIZE_lab0; \
  (A0)->objsize = TAILED_SIZE_TO_BYTES(instance_t, (A1)); \
  goto instance_t__SET_TAILED_SIZE_lab0; \
instance_t__SET_TAILED_SIZE_lab0: \
  { } \
})
#define hashtab_t__SET_TAILED_SIZE(A0, A1) ({ \
  __label__ hashtab_t__SET_TAILED_SIZE_lab0; \
  (A0)->mask = HASHTAB_SIZE2MASK((A1)); \
  goto hashtab_t__SET_TAILED_SIZE_lab0; \
hashtab_t__SET_TAILED_SIZE_lab0: \
  { } \
})
#define emul_info_t__SET_TAILED_SIZE(A0, A1) ({ \
  __label__ emul_info_t__SET_TAILED_SIZE_lab0; \
  (A0)->objsize = TAILED_SIZE_TO_BYTES(emul_info_t, (A1)); \
  goto emul_info_t__SET_TAILED_SIZE_lab0; \
emul_info_t__SET_TAILED_SIZE_lab0: \
  { } \
})
#define GENERAL_OPTS ("varops|omerg|joinconts|urules|specmode")
#define TAGSCHEME_OPTS ("highbittags|lowbitgc|qtag|tagswbit|tagtestbit")
#define TAG(KEY) TAG__##KEY
#define TAG__hva 0
#define TAG__cva 1
#define TAG__sva 2
#define TAG__num 4
#define TAG__atm 5
#define TAG__lst 6
#define TAG__str 7
#define TagH3_HasTag(X,T) (TagOf((X)) == (T))
#define TAGH3_OFFSET (tagged__size-3)
#define TagH3_t tagged_t
#define sTagH3_t stagged_t
#define TagH3_Is0(X) ((X) < (TagH3_t)1<<TAGH3_OFFSET)
#define TagH3_Pre012_Is1(X) ((X)&((TagH3_t)1<<TAGH3_OFFSET))
#define TagH3_Pre0123_Is1(X) ((sTagH3_t)(X<<1) >= (sTagH3_t)((TagH3_t)1<<1<<TAGH3_OFFSET))
#define TagH3_Is1(X) TagH3_HasTag(X,1)
#define TagH3_Pre012_Is2(X) ((X)&((TagH3_t)2<<TAGH3_OFFSET))
#define TagH3_Pre0124567_Is2(X) ((sTagH3_t)(X) >= (sTagH3_t)((TagH3_t)2<<TAGH3_OFFSET))
#define TagH3_Is4(X) ((sTagH3_t)(X) < (sTagH3_t)((TagH3_t)5<<TAGH3_OFFSET)) 
#define TagH3_Pre4567_Is5(X) ((sTagH3_t)(X<<1) >= (sTagH3_t)((TagH3_t)5<<1<<TAGH3_OFFSET))
#define TagH3_Is5(X) TagH3_HasTag(X,5)
#define TagH3_Is6(X) TagH3_HasTag(X,6)
#define TagH3_Is7(X) ((X) >= ((TagH3_t)7<<TAGH3_OFFSET))
#define TagH3_Is01(X) ((X) < ((TagH3_t)2<<TAGH3_OFFSET))
#define TagH3_Pre012_Is02(X) (!TagH3_Pre012_Is1((X)))
#define TagH3_Pre4567_Is45(X) (!TagH3_Pre4567_Is67((X)))
#define TagH3_Is45(X) ((sTagH3_t)(X) < (sTagH3_t)((TagH3_t)6<<TAGH3_OFFSET))
#define TagH3_Pre4567_Is46(X) (!TagH3_Pre4567_Is57((X)))
#define TagH3_Pre4567_Is57(X) ((X)&((TagH3_t)1<<TAGH3_OFFSET))
#define TagH3_Pre4567_Is67(X) ((X)&((TagH3_t)2<<TAGH3_OFFSET))
#define TagH3_Is67(X) ((X) >= ((TagH3_t)6<<TAGH3_OFFSET))
#define TagH3_Is0123(A) ((sTagH3_t)(A)>=0)
#define TagH3_Is0167(A) ((sTagH3_t)((A)+((TagH3_t)2<<TAGH3_OFFSET))>=0)
#define TagH3_Is4567(X) (!TagH3_Is0123((X)))
#define TagL3_t tagged_t
#define sTagL3_t stagged_t
#define TagL3_Is0(X) TagOf_Is0((X))
#define TagL3_Pre012_Is1(X) TagL3_Is1((X))
#define TagL3_Pre0123_Is1(X) TagL3_Is1((X))
#define TagL3_Is1(X) (((X)&7)==1)
#define TagL3_Pre012_Is2(X) TagL3_Is2((X))
#define TagL3_Pre0124567_Is2(X) (((X)&7)==2)
#define TagL3_Is4(X) TagOf_Is4((X))
#define TagL3_Pre4567_Is5(X) TagOf_Is5((X))
#define TagL3_Is5(X) TagOf_Is5((X))
#define TagL3_Is6(X) TagOf_Is6((X))
#define TagL3_Is7(X) TagOf_Is7((X))
#define TagL3_Is01(X) (((X)&7)<2)
#define TagL3_Pre012_Is02(X) (!TagL3_Pre012_Is1((X)))
#define TagL3_Pre4567_Is45(X) (!TagL3_Pre4567_Is67((X)))
#define TagL3_Is45(X) ((((X)-4)&7)<2)
#define TagL3_Pre4567_Is46(X) (!TagL3_Pre4567_Is57((X)))
#define TagL3_Pre4567_Is57(X) ((X)&1)
#define TagL3_Pre4567_Is67(X) ((X)&2)
#define TagL3_Is67(X) (((X)&7)>=6)
#define TagL3_Is0123(A) (!((A)&4))
#define TagL3_Is0167(A) ((((A)+2)&7)<4)
#define TagL3_Is4567(X) (!TagL3_Is0123((X)))
#define TAGS3_MASK1 ((tagged_t)1<<(tagged__size-1))
#define TAGS3_MASK (TAGS3_MASK1|3)
#define TagS3_t tagged_t
#define sTagS3_t stagged_t
#define TagS3_Is0(X) TagOf_Is0((X))
#define TagS3_Pre012_Is1(X) (((X)&3)==1)
#define TagS3_Pre0123_Is1(X) TagS3_Is1((X))
#define TagS3_Is1(X) (((X)&TAGS3_MASK)==1)
#define TagS3_Pre012_Is2(X) (((X)&3)==2)
#define TagS3_Pre0124567_Is2(X) (((X)&TAGS3_MASK)==2)
#define TagS3_Is4(X) TagOf_Is4((X))
#define TagS3_Pre4567_Is5(X) TagOf_Is5((X))
#define TagS3_Is5(X) TagOf_Is5((X))
#define TagS3_Is6(X) TagOf_Is6((X))
#define TagS3_Is7(X) TagOf_Is7((X))
#define TagS3_Is01(X) (((X)&TAGS3_MASK)<2)
#define TagS3_Pre012_Is02(X) (!TagS3_Pre012_Is1((X)))
#define TagS3_Pre4567_Is45(X) (!TagS3_Pre4567_Is67((X)))
#define TagS3_Is45(A) ({ TagS3_t temp_a = (A); (TagS3_Is4567(temp_a) && (!TagS3_Is67(temp_a))); })
#define TagS3_Pre4567_Is46(X) (!TagS3_Pre4567_Is57((X)))
#define TagS3_Pre4567_Is57(X) ((X)&1)
#define TagS3_Pre4567_Is67(X) ((X)&2)
#define TagS3_Is67(X) (((X)&TAGS3_MASK)>=Tagt(6))
#define TagS3_Is0123(A) (!((A)&TAGS3_MASK1))
#define TagS3_Is0167(A) ({ TagS3_t temp_a = (A); (TagS3_Is01(temp_a) || TagS3_Is67(temp_a)); })
#define TagS3_Is4567(X) (!TagS3_Is0123((X)))
#define TagD3_t tagged_t
#define sTagD3_t stagged_t
#define TagD3_Is0(X) TagOf_Is0((X))
#define TagD3_Pre012_Is1(A) TagB3_Pre012_Is1(TagOf((A)))
#define TagD3_Pre0123_Is1(A) TagB3_Pre0123_Is1(TagOf((A)))
#define TagD3_Is1(A) TagB3_Is1(TagOf((A)))
#define TagD3_Pre012_Is2(A) TagB3_Pre012_Is2(TagOf((A)))
#define TagD3_Pre0124567_Is2(X) TagB3_Is2(TagOf((A)))
#define TagD3_Is4(X) TagOf_Is4((X))
#define TagD3_Pre4567_Is5(X) TagOf_Is5((X))
#define TagD3_Is5(X) TagOf_Is5((X))
#define TagD3_Is6(X) TagOf_Is6((X))
#define TagD3_Is7(X) TagOf_Is7((X))
#define TagD3_Is01(A) TagB3_Is01(TagOf((A)))
#define TagD3_Pre012_Is02(X) (!TagD3_Pre012_Is1((X)))
#define TagD3_Pre4567_Is45(X) (!TagD3_Pre4567_Is67((X)))
#define TagD3_Is45(A) TagB3_Is45(TagOf((A)))
#define TagD3_Pre4567_Is46(X) (!TagD3_Pre4567_Is57((X)))
#define TagD3_Pre4567_Is57(A) TagB3_Pre4567_Is57(TagOf((A)))
#define TagD3_Pre4567_Is67(A) TagB3_Pre4567_Is67(TagOf((A)))
#define TagD3_Is67(A) TagB3_Is67(TagOf((A)))
#define TagD3_Is0123(A) TagB3_Is0123(TagOf((A)))
#define TagD3_Is0167(A) TagB3_Is0167(TagOf((A)))
#define TagD3_Is4567(X) (!TagD3_Is0123((X)))
#define TagOf_t tagged_t
#define sTagOf_t stagged_t
#define TagOf_Is0(X) HasTag((X),0)
#define TagOf_Pre012_Is1(X) TagOf_Is1((X))
#define TagOf_Is1(X) HasTag((X),1)
#define TagOf_Pre012_Is2(X) TagOf_Is2((X))
#define TagOf_Pre0123_Is2(X) TagOf_Is2((X))
#define TagOf_Pre0124567_Is2(X) TagOf_Is2((X))
#define TagOf_Is2(X) HasTag((X),2)
#define TagOf_Is4(X) HasTag((X),4)
#define TagOf_Pre4567_Is5(X) TagOf_Is5((X))
#define TagOf_Is5(X) HasTag((X),5)
#define TagOf_Is6(X) HasTag((X),6)
#define TagOf_Is7(X) HasTag((X),7)
#define TagOf_Is01(A) ({ bool_t temp_res; switch (TagOf((A))) { case 0: case 1: temp_res = TRUE; break; default: temp_res = FALSE; } temp_res; })
#define TagOf_Pre012_Is02(X) (!TagOf_Pre012_Is1((X)))
#define TagOf_Pre4567_Is45(X) (!TagOf_Pre4567_Is67((X)))
#define TagOf_Is45(A) ({ bool_t temp_res; switch (TagOf((A))) { case 4: case 5: temp_res = TRUE; break; default: temp_res = FALSE; } temp_res; })
#define TagOf_Pre4567_Is46(X) (!TagOf_Pre4567_Is57((X)))
#define TagOf_Pre4567_Is57(X) TagOf_Is57((X))
#define TagOf_Is57(X) (HasTag((X),5)||HasTag((X),7))
#define TagOf_Pre4567_Is67(X) TagOf_Is67((X))
#define TagOf_Is67(X) (HasTag((X),6)||HasTag((X),7))
#define TagOf_Is0123(A) ({ bool_t temp_res; switch (TagOf((A))) { case 0: case 1: case 2: case 3: temp_res = TRUE; break; default: temp_res = FALSE; } temp_res; })
#define TagOf_Is0167(A) ({ bool_t temp_res; switch (TagOf((A))) { case 0: case 1: case 6: case 7: temp_res = TRUE; break; default: temp_res = FALSE; } temp_res; })
#define TagOf_Is4567(X) (!TagOf_Is0123((X)))
#define TAGH4_OFFSET (tagged__size-4)
#define TAGH4_MASK MakeMask(TagH4_t, 4, TAGH4_OFFSET)
#define TagH4_HasTag(X,T) (((X) & TAGH4_MASK) == ((TagH4_t)(T)<<TAGH4_OFFSET))
#define TagH4_t tagged_t
#define sTagH4_t stagged_t
#define TagH4_Is8(X) ((sTagH4_t)(X) < (sTagH4_t)(9<<TAGH4_OFFSET))
#define TagH4_Isb(X) TagH4_HasTag((X), 11)
#define TagB3_t tagged_t
#define sTagB3_t stagged_t
#define TagB3_Is0123(A) (!((A)&4))
#define TagB3_Is0167(A) ((((A)+2)&7)<4)
#define TagB3_Is01(X) ((X)<2)
#define TagB3_Is45(X) ((((X)-4)&7)<2)
#define TagB3_Is1(X) ((X)==1)
#define TagB3_Is2(X) ((X)==2)
#define TagB3_Pre0123_Is1(X) TagB3_Is1((X))
#define TagB3_Is67(X) ((X)>=6)
#define TagB3_Pre4567_Is57(X) ((X)&1)
#define TagB3_Pre4567_Is67(X) ((X)&2)
#define TagB3_Pre012_Is1(X) TagB3_Is1((X))
#define TagB3_Pre012_Is2(X) TagB3_Is2((X))
#define TaggedATMIsATMQ(F) ((F) & QTAGMASK)
#define TaggedIsATMQ(F) TagH4_Isb((F))
#define TaggedIsSmall(X) TagH4_Is8((X))
#define FTYPEDEF(KEY) FTYPEDEF__##KEY
#define FTYPEDEF__basic 0
#define FTYPEDEF__str 1
#define FTYPEDEF__array 2
#define FTYPEDEF__blob 3
#define QS(KEY) QS__##KEY
#define QS__integer 2
#define QS__poffset 3
#define QS__functor 5
#define QS__tagged 6
#define QS__emul_entry 7
#define QS__builtin_entry 9
#define QS__small 8
#define QL(KEY) QL__##KEY
#define QL__uint16 8
#define QL__uint32 6
#define QL__uint64 9
#define QL__baseptr 3
#define FTYPE_id(KEY) FTYPE_id__##KEY
#define FTYPE_id__f_o 15
#define FTYPE_id__f_e 8
#define FTYPE_id__f_f 9
#define FTYPE_id__f_i 10
#define FTYPE_id__f_l 11
#define FTYPE_id__f_g 12
#define FTYPE_id__f_p 13
#define FTYPE_id__f_t 14
#define FTYPE_id__f_x 16
#define FTYPE_id__f_y 17
#define FTYPE_id__f_z 18
#define FTYPE_id__f_C 5
#define FTYPE_id__f_E 6
#define FTYPE_id__f_Q 19
#define FTYPE_id__f_Y 3
#define FTYPE_id__f_Z 4
#define FTYPE_id__f_b 7
#define FTYPE_size(KEY) FTYPE_size__##KEY
#define FTYPE_size__f_o 2
#define FTYPE_size__f_e 2
#define FTYPE_size__f_f 4
#define FTYPE_size__f_i 2
#define FTYPE_size__f_l 4
#define FTYPE_size__f_g 6
#define FTYPE_size__f_p 4
#define FTYPE_size__f_t 4
#define FTYPE_size__f_x 2
#define FTYPE_size__f_y 2
#define FTYPE_size__f_z 2
#define FTYPE_size__f_C 4
#define FTYPE_size__f_Cc 4
#define FTYPE_size__f_Ci 4
#define FTYPE_size__f_E 4
#define FTYPE_size__f_Q 2
#define FTYPE_ctype(KEY) FTYPE_ctype__##KEY
#define FTYPE_ctype__f_o uint16_t
#define FTYPE_ctype__f_e uint16_t
#define FTYPE_ctype__f_f uint32_t
#define FTYPE_ctype__f_i uint16_t
#define FTYPE_ctype__f_l uint32_t
#define FTYPE_ctype__f_g liveinfo_t
#define FTYPE_ctype__f_p char *
#define FTYPE_ctype__f_t uint32_t
#define FTYPE_ctype__f_x uint16_t
#define FTYPE_ctype__f_y uint16_t
#define FTYPE_ctype__f_z uint16_t
#define FTYPE_ctype__f_C char *
#define FTYPE_ctype__f_Cc cbool_t
#define FTYPE_ctype__f_Ci cinsnp_t
#define FTYPE_ctype__f_E definition_t *
#define FTYPE_ctype__f_Q uint16_t
#define X_OFFSET_FROM_WORKER 148
#define Y_OFFSET_FROM_FRAME 8
#define PREDTYPE(KEY) PREDTYPE__##KEY
#define PREDTYPE__compactcode 0
#define PREDTYPE__compactcode_indexed 1
#define PREDTYPE__profiledcode 2
#define PREDTYPE__profiledcode_indexed 3
#define PREDTYPE__undefined 6
#define PREDTYPE__cbool 7
#define PREDTYPE__cinsnp 23
#define PREDTYPE__cvoid 24
#define PREDTYPE__interpreted 8
#define DEFBITS(KEY) DEFBITS__##KEY
#define DEFBITS__dynamic 1
#define DEFBITS__concurrent 2
#define DEFBITS__multifile 4
#define DEFBITS__hardrtexp 8
#define INSTANTIATION_ERROR 1
#define RESOURCE_ERROR (RANGE_PER_ERROR * error_start(res))
#define SYNTAX_ERROR (RANGE_PER_ERROR * error_start(syntax))
#define SYSTEM_ERROR (RANGE_PER_ERROR * error_start(system))
#define USER_EXCEPTION (RANGE_PER_ERROR * error_start(user))
#define RANGE_PER_ERROR 100
#define error_start(KEY) error_start__##KEY
#define error_start__inst 0
#define error_start__type 1
#define error_start__dom 2
#define error_start__exist 3
#define error_start__perm 4
#define error_start__repres 5
#define error_start__eval 6
#define error_start__res 7
#define error_start__syntax 8
#define error_start__system 9
#define error_start__user 10
#define TYPE_ERRORS(KEY) TYPE_ERRORS__##KEY
#define TYPE_ERRORS__atom 0
#define TYPE_ERRORS__atomic 1
#define TYPE_ERRORS__byte 2
#define TYPE_ERRORS__character 3
#define TYPE_ERRORS__compound 4
#define TYPE_ERRORS__evaluable 5
#define TYPE_ERRORS__in_byte 6
#define TYPE_ERRORS__integer 7
#define TYPE_ERRORS__list 8
#define TYPE_ERRORS__number 9
#define TYPE_ERRORS__predicate_indicator 10
#define TYPE_ERRORS__variable 11
#define TYPE_ERRORS__callable 12
#define DOMAIN_ERRORS(KEY) DOMAIN_ERRORS__##KEY
#define DOMAIN_ERRORS__character_code_list 0
#define DOMAIN_ERRORS__source_sink 1
#define DOMAIN_ERRORS__stream 2
#define DOMAIN_ERRORS__io_mode 3
#define DOMAIN_ERRORS__not_empty_list 4
#define DOMAIN_ERRORS__not_less_than_zero 5
#define DOMAIN_ERRORS__operator_priority 6
#define DOMAIN_ERRORS__prolog_flag 7
#define DOMAIN_ERRORS__read_option 8
#define DOMAIN_ERRORS__flag_value 9
#define DOMAIN_ERRORS__close_option 10
#define DOMAIN_ERRORS__stream_option 11
#define DOMAIN_ERRORS__stream_or_alias 12
#define DOMAIN_ERRORS__stream_position 13
#define DOMAIN_ERRORS__stream_property 14
#define DOMAIN_ERRORS__write_option 15
#define DOMAIN_ERRORS__operator_specifier 16
#define EXISTENCE_ERRORS(KEY) EXISTENCE_ERRORS__##KEY
#define EXISTENCE_ERRORS__procedure 0
#define EXISTENCE_ERRORS__source_sink 1
#define EXISTENCE_ERRORS__stream 2
#define PERMISSION_TYPES(KEY) PERMISSION_TYPES__##KEY
#define PERMISSION_TYPES__access 0
#define PERMISSION_TYPES__create 1
#define PERMISSION_TYPES__input 2
#define PERMISSION_TYPES__modify 3
#define PERMISSION_TYPES__open 4
#define PERMISSION_TYPES__output 5
#define PERMISSION_TYPES__reposition 6
#define PERMISSION_OBJECTS(KEY) PERMISSION_OBJECTS__##KEY
#define PERMISSION_OBJECTS__binary_stream 0
#define PERMISSION_OBJECTS__source_sink 1
#define PERMISSION_OBJECTS__stream 2
#define PERMISSION_OBJECTS__text_stream 3
#define PERMISSION_OBJECTS__flag 4
#define PERMISSION_OBJECTS__operator 5
#define PERMISSION_OBJECTS__past_end_of_stream 6
#define PERMISSION_OBJECTS__private_procedure 7
#define PERMISSION_OBJECTS__static_procedure 8
#define REPRESENTATION_ERRORS(KEY) REPRESENTATION_ERRORS__##KEY
#define REPRESENTATION_ERRORS__character_code_list 0
#define REPRESENTATION_ERRORS__in_character_code 1
#define REPRESENTATION_ERRORS__max_arity 2
#define REPRESENTATION_ERRORS__character 3
#define REPRESENTATION_ERRORS__max_integer 4
#define REPRESENTATION_ERRORS__min_integer 5
#define REPRESENTATION_ERRORS__character_code 6
#define EVALUATION_ERRORS(KEY) EVALUATION_ERRORS__##KEY
#define EVALUATION_ERRORS__float_overflow 0
#define EVALUATION_ERRORS__int_overflow 1
#define EVALUATION_ERRORS__e_undefined 2
#define EVALUATION_ERRORS__e_underflow 3
#define EVALUATION_ERRORS__zero_divisor 4
#define DYNX(KEY) DYNX__##KEY
#define DYNX__X2_CHN 2
#define DYNX__ClockSlot 4
#define DYNX__X5_CHN 5
#define DYNX__RootArg 6
#define DYNX__InvocationAttr 7
#define DYNX__PrevDynChpt 8
#define DYNX__DynamicPreserved 9
#define OPCODE(KEY) OPCODE__##KEY
#define OPCODE__pad2__fcall 22
#define OPCODE__fcall 23
#define OPCODE__pad2__call 42
#define OPCODE__call 43
#define OPCODE__pad2__lastcall 64
#define OPCODE__lastcall 65
#define OPCODE__ux_xval 87
#define OPCODE__pad2__ux_cons 90
#define OPCODE__ux_cons 91
#define OPCODE__pad2__ux_blob 92
#define OPCODE__ux_blob 93
#define OPCODE__pad2__ux_str 94
#define OPCODE__ux_str 95
#define OPCODE__ux_nil 96
#define OPCODE__ux_lst 97
#define OPCODE__kontinue 112
#define OPCODE__exit_toplevel 113
#define OPCODE__pad2__retry_cbool__proceed 114
#define OPCODE__pad2__exec_cinsnp 115
#define OPCODE__movexx 117
#define OPCODE__ux_constraint 138
#define OPCODE__un_voidr1 143
#define OPCODE__un_xvar 144
#define OPCODE__un_xval 145
#define OPCODE__pad2__un_cons 152
#define OPCODE__un_cons 153
#define OPCODE__pad2__un_blob 154
#define OPCODE__un_blob 155
#define OPCODE__pad2__un_str 156
#define OPCODE__un_str 157
#define OPCODE__un_nil 158
#define OPCODE__un_lst 159
#define OPCODE__failins 235
#define OPCODE__pad2__heapmargin_call 236
#define OPCODE__heapmargin_call 237
#define OPCODE__proceed 241
#define OPCODE__restore_all_next_alt 242
#define OPCODE__restore_all_no_alt 243
#define OPCODE__exec_cinsnp_alt 244
#define OPCODE__func__enter_undefined 245
#define OPCODE__func__enter_interpreted 246
#define OPCODE__func__enter_cbool 247
#define OPCODE__func__enter_cinsnp 248
#define OPCODE__func__enter_cvoid 249
#define OPCODE__func__enter_indexed 250
#define OPCODE__func__enter_nonindexed 251
#define OPCODE__dynamic_neck__proceed 252
#define INS_OPCOUNT 253
#define EMIT_op(KEY) EMIT_op__##KEY
#define EMIT_op__dynamic_neck__proceed (EMIT_opcode(dynamic_neck__proceed))
#define EMIT_op__restore_all_next_alt (EMIT_opcode(restore_all_next_alt))
#define EMIT_op__restore_all_no_alt (EMIT_opcode(restore_all_no_alt))
#define EMIT_op__exec_cinsnp_alt (EMIT_opcode(exec_cinsnp_alt))
#define EMIT_op__func__enter_undefined (EMIT_opcode(func__enter_undefined))
#define EMIT_op__func__enter_interpreted (EMIT_opcode(func__enter_interpreted))
#define EMIT_op__func__enter_cbool (EMIT_opcode(func__enter_cbool))
#define EMIT_op__func__enter_cinsnp (EMIT_opcode(func__enter_cinsnp))
#define EMIT_op__func__enter_cvoid (EMIT_opcode(func__enter_cvoid))
#define EMIT_op__func__enter_indexed (EMIT_opcode(func__enter_indexed))
#define EMIT_op__func__enter_nonindexed (EMIT_opcode(func__enter_nonindexed))
#define EMIT_op__kontinue (EMIT_opcode(kontinue))
#define EMIT_op__exit_toplevel (EMIT_opcode(exit_toplevel))
#define EMIT_op__retry_cbool__proceed (EMIT_opcode_pad24_A0(retry_cbool__proceed))
#define EMIT_op__proceed (EMIT_opcode(proceed))
#define EMIT_op__exec_cinsnp (EMIT_opcode_pad24_A0(exec_cinsnp))
#define EMIT_op__ux_blob (EMIT_opcode_pad04(ux_blob))
#define EMIT_op__ux_xval (EMIT_opcode(ux_xval))
#define EMIT_op__ux_cons (EMIT_opcode_pad04(ux_cons))
#define EMIT_op__ux_str (EMIT_opcode_pad04(ux_str))
#define EMIT_op__ux_nil (EMIT_opcode(ux_nil))
#define EMIT_op__ux_lst (EMIT_opcode(ux_lst))
#define EMIT_op__movexx (EMIT_opcode(movexx))
#define EMIT_op__un_voidr1 (EMIT_opcode(un_voidr1))
#define EMIT_op__un_xvar (EMIT_opcode(un_xvar))
#define EMIT_op__un_xval (EMIT_opcode(un_xval))
#define EMIT_op__un_cons (EMIT_opcode_pad24(un_cons))
#define EMIT_op__un_blob (EMIT_opcode_pad24(un_blob))
#define EMIT_op__un_str (EMIT_opcode_pad24(un_str))
#define EMIT_op__un_nil (EMIT_opcode(un_nil))
#define EMIT_op__un_lst (EMIT_opcode(un_lst))
#define EMIT_op__heapmargin_call (EMIT_opcode_pad24(heapmargin_call))
#define EMIT_op__ux_constraint (EMIT_opcode(ux_constraint))
#define EMIT_op__fcall (EMIT_opcode_pad24(fcall))
#define EMIT_op__call (EMIT_opcode_pad24_A0(call))
#define EMIT_op__failins (EMIT_opcode(failins))
#define EMIT_op__lastcall (EMIT_opcode_pad24(lastcall))
#define GDACTION(KEY) GDACTION__##KEY
#define GDACTION__no_action 0
#define GDACTION__shares_structure 1
#define GDACTION__has_continuation 2
#define GDACTION__keep_stacks 4
#define GDACTION__backtracking 8
#define GDACTION__create_thread 16
#define GDACTION__create_wam 32
#define GDACTION__needs_freeing 64
#define worker_t__TAIL uint32_t
#define choice_t__TAIL uint32_t
#define frame_t__TAIL uint32_t
#define tagged__tag_offset 29
#define tagged__tag_size 3
#define tagged__gc_offset 0
#define tagged__gc_size 2
#define tagged__gc_marked_offset 1
#define tagged__gc_marked_size 1
#define tagged__gc_reversed_offset 0
#define tagged__gc_reversed_size 1
#define tagged__qtag_offset 28
#define tagged__qtag_size 1
#define tagged__ptr_offset 2
#define tagged__ptr_size 26
#define tagged__num_offset 2
#define tagged__num_size 26
#define tagged__qval_offset 2
#define tagged__qval_size 26
#define tagged__nestedmark_offset 0
#define tagged__nestedmark_size 2
#define tagged__nestedval_offset 2
#define tagged__nestedval_size 26
#define SMALLPTR_BASE MallocBase4
#define OWNMALLOC_BLOCKSIZE MIN_MEM_ALLOC_4
#define OWNMALLOC_MmapAllowed MmapAllowed4
#define OWNMALLOC_MmapSize MmapSize4
#define SMALLPTR_UPPERBITS 4
#define SMALLPTR_LOWERBITS 2
#define tagged__size 32
#define ABSMACH_OPT__varops 1
#define ABSMACH_OPT__omerg 1
#define ABSMACH_OPT__joinconts 1
#define ABSMACH_OPT__urules 1
#define ABSMACH_OPT__specmode 1
#define ABSMACH_OPT__tagscheme1 1
#define ABSMACH_OPT__atomgc 1
#define ABSMACH_OPT__lazy_localtop 1
#define ABSMACH_OPT__incoreopt 1
#define ABSMACH_OPT__regmod 1
#define ABSMACH_OPT__oo_extensions 1
#define ABSMACH_OPT__atom_locks 1
#define ABSMACH_OPT__general_locks 1
#define ABSMACH_OPT__cache_local_resolve 1
#define ABSMACH_OPT__dynlink_mod 1
#define ABSMACH_OPT__computed_goto 1
#define ABSMACH_OPT__varops2 1
#define ABSMACH_OPT__cached_h 1
#define ABSMACH_OPT__atom_len 1
#define ABSMACH_OPT__optlst 1
#define ABSMACH_OPT__highbittags 1
#define ABSMACH_OPT__lowbitgc 1
#define ABSMACH_OPT__qtag 1
#define ABSMACH_OPT__tagswbit 1
#define ABSMACH_OPT__tagtestbit 1
#define ABSMACH_OPT__nestedmarksgc 1
#define ABSMACH_OPT__halfword_o 1
#define instance_t__TAIL char
#define hashtab_t__TAIL hashtab_node_t
#define atom_t__TAIL char
#define emul_info_t__TAIL char
#define IsVar(A0) (TagH3_Is0123((A0)))
#define IsHeapPtr(A0) (TagH3_Is0167((A0)))
#define TaggedIsNUMorATM(A0) (TagH3_Is45((A0)))
#define TaggedIsCVA(A0) (TagH3_Is1((A0)))
#define TaggedIsSVA(A0) (TagH3_Pre0124567_Is2((A0)))
#define IsNonvarAtom(A0) (TagH3_Pre4567_Is5((A0)))
#define TaggedIsATM(A0) (TagH3_Is5((A0)))
#define TaggedIsHVA(A0) (TagH3_Is0((A0)))
#define TaggedIsNUM(A0) (TagH3_Is4((A0)))
#define TaggedIsLST(A0) (TagH3_Is6((A0)))
#define TaggedIsSTR(A0) (TagH3_Is7((A0)))
#define TYPE_ERROR(A0) (RANGE_PER_ERROR * error_start(type) + (A0))
#define DOMAIN_ERROR(A0) (RANGE_PER_ERROR * error_start(dom) + (A0))
#define EXISTENCE_ERROR(A0) (RANGE_PER_ERROR * error_start(exist) + (A0))
#define PERMISSION_ERROR(A0, A1) (RANGE_PER_ERROR * error_start(perm) + (A0) * 10 + (A1))
#define REPRESENTATION_ERROR(A0) (RANGE_PER_ERROR * error_start(repres) + (A0))
#define EVALUATION_ERROR(A0) (RANGE_PER_ERROR * error_start(eval) + (A0))
#define instance_t__SIZE_TAILED(A0) (TAILED_BYTES_TO_SIZE(instance_t, (A0)->objsize))
#define hashtab_t__SIZE_TAILED(A0) (HASHTAB_SIZE((A0)))
#define emul_info_t__SIZE_TAILED(A0) (TAILED_BYTES_TO_SIZE(emul_info_t, (A0)->objsize))
extern tagged_t atm_var;
extern tagged_t atm_attv;
extern tagged_t atm_float;
extern tagged_t atm_int;
extern tagged_t atm_str;
extern tagged_t atm_atm;
extern tagged_t atm_lst;
extern tagged_t atom_success;
extern tagged_t atom_failure;
extern tagged_t atom_share;
extern tagged_t atom_noshare;
extern tagged_t atom_user_input;
extern tagged_t atom_user_output;
extern tagged_t atom_user_error;
extern tagged_t atom_read;
extern tagged_t atom_write;
extern tagged_t atom_append;
extern tagged_t atom_socket;
extern tagged_t atom_symlink;
extern tagged_t atom_regular;
extern tagged_t atom_directory;
extern tagged_t atom_fifo;
extern tagged_t atom_unknown;
extern tagged_t atom_user;
extern tagged_t atom_prolog;
extern tagged_t atom_lessthan;
extern tagged_t atom_greaterthan;
extern tagged_t atom_equal;
extern tagged_t atom_lst;
extern tagged_t atom_nil;
extern tagged_t atom_on;
extern tagged_t atom_off;
extern tagged_t atom_error;
extern tagged_t atom_trace;
extern tagged_t atom_debug;
extern tagged_t atom_fail;
extern tagged_t atom_all;
extern tagged_t atom_terse;
extern tagged_t atom_verbose;
extern tagged_t atom_compiled;
extern tagged_t atom_interpreted;
extern tagged_t atom_builtin;
extern tagged_t atom_true;
extern tagged_t atom_basiccontroltrue;
extern tagged_t atom_retry_hook;
extern tagged_t atom_unprofiled;
extern tagged_t atom_profiled;
extern tagged_t atom_concurrent;
extern tagged_t atom_wait;
extern tagged_t atom_dynamic;
extern tagged_t atom_multifile;
extern tagged_t atom_block;
extern tagged_t atom_no_block;
extern tagged_t atom_self;
extern tagged_t atom_create;
extern tagged_t atom_dash;
extern absmachdef_t abscurr;
extern char *ins_name[253];
#include <engine/absmach_postdef.h>
#endif
