#include <engine/basiccontrol.native.h>
definition_t *prolog__sys__0;
definition_t *prolog__sys__1;
definition_t *prolog__sys__2;
definition_t *prolog__sys__3;
bool_t gc_start(worker_t *);
bool_t current_atom(worker_t *);
bool_t prolog_new_atom(worker_t *);
bool_t statistics(worker_t *);
void prolog__sys__init(worker_t *w) {
  prolog__sys__0 = register_cbool("prolog_sys:garbage_collect", 0, gc_start);
  register_builtin("prolog_sys:garbage_collect", 0, gc_start);
  prolog__sys__1 = register_cbool("prolog_sys:current_atom", 1, current_atom);
  register_builtin("prolog_sys:current_atom", 1, current_atom);
  prolog__sys__2 = register_cbool("prolog_sys:new_atom", 1, prolog_new_atom);
  register_builtin("prolog_sys:new_atom", 1, prolog_new_atom);
  prolog__sys__3 = register_cbool("prolog_sys:statistics", 0, statistics);
  register_builtin("prolog_sys:statistics", 0, statistics);
}
void prolog__sys__end(worker_t *w) {
  unregister_cbool("prolog_sys:garbage_collect", 0);
  unregister_cbool("prolog_sys:current_atom", 1);
  unregister_cbool("prolog_sys:new_atom", 1);
  unregister_cbool("prolog_sys:statistics", 0);
}
