#include <engine/basiccontrol.native.h>
definition_t *atomic__basic__0;
definition_t *atomic__basic__1;
definition_t *atomic__basic__2;
definition_t *atomic__basic__3;
definition_t *atomic__basic__4;
definition_t *atomic__basic__5;
definition_t *atomic__basic__6;
bool_t prolog_name(worker_t *);
bool_t prolog_atom_codes(worker_t *);
bool_t prolog_number_codes_2(worker_t *);
bool_t prolog_number_codes_3(worker_t *);
bool_t prolog_atom_length(worker_t *);
bool_t prolog_atom_concat(worker_t *);
bool_t prolog_sub_atom(worker_t *);
void atomic__basic__init(worker_t *w) {
  atomic__basic__0 = register_cbool("atomic_basic:name", 2, prolog_name);
  register_builtin("atomic_basic:name", 2, prolog_name);
  atomic__basic__1 = register_cbool("atomic_basic:atom_codes", 2, prolog_atom_codes);
  register_builtin("atomic_basic:atom_codes", 2, prolog_atom_codes);
  atomic__basic__2 = register_cbool("atomic_basic:number_codes", 2, prolog_number_codes_2);
  register_builtin("atomic_basic:number_codes", 2, prolog_number_codes_2);
  atomic__basic__3 = register_cbool("atomic_basic:number_codes", 3, prolog_number_codes_3);
  register_builtin("atomic_basic:number_codes", 3, prolog_number_codes_3);
  atomic__basic__4 = register_cbool("atomic_basic:atom_length", 2, prolog_atom_length);
  register_builtin("atomic_basic:atom_length", 2, prolog_atom_length);
  atomic__basic__5 = register_cbool("atomic_basic:atom_concat", 3, prolog_atom_concat);
  register_builtin("atomic_basic:atom_concat", 3, prolog_atom_concat);
  atomic__basic__6 = register_cbool("atomic_basic:sub_atom", 4, prolog_sub_atom);
  register_builtin("atomic_basic:sub_atom", 4, prolog_sub_atom);
}
void atomic__basic__end(worker_t *w) {
  unregister_cbool("atomic_basic:name", 2);
  unregister_cbool("atomic_basic:atom_codes", 2);
  unregister_cbool("atomic_basic:number_codes", 2);
  unregister_cbool("atomic_basic:number_codes", 3);
  unregister_cbool("atomic_basic:atom_length", 2);
  unregister_cbool("atomic_basic:atom_concat", 3);
  unregister_cbool("atomic_basic:sub_atom", 4);
}
