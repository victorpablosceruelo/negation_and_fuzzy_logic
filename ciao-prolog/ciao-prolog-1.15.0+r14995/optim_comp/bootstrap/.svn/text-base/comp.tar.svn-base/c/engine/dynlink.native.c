#include <engine/basiccontrol.native.h>
definition_t *dynlink__0;
definition_t *dynlink__1;
definition_t *dynlink__2;
definition_t *dynlink__3;
definition_t *dynlink__4;
bool_t prolog_module_timestamp(worker_t *);
bool_t prolog_static_module(worker_t *);
bool_t prolog_load_module(worker_t *);
bool_t prolog_abolish_module(worker_t *);
bool_t prolog_load_module_pack(worker_t *);
void dynlink__init(worker_t *w) {
  dynlink__0 = register_cbool("dynlink:module_timestamp", 2, prolog_module_timestamp);
  register_builtin("dynlink:module_timestamp", 2, prolog_module_timestamp);
  dynlink__1 = register_cbool("dynlink:static_module", 1, prolog_static_module);
  register_builtin("dynlink:static_module", 1, prolog_static_module);
  dynlink__2 = register_cbool("dynlink:load_module__nocheck", 2, prolog_load_module);
  register_builtin("dynlink:load_module__nocheck", 2, prolog_load_module);
  dynlink__3 = register_cbool("dynlink:unload_module__nocheck", 1, prolog_abolish_module);
  register_builtin("dynlink:unload_module__nocheck", 1, prolog_abolish_module);
  dynlink__4 = register_cbool("dynlink:link_pack", 1, prolog_load_module_pack);
  register_builtin("dynlink:link_pack", 1, prolog_load_module_pack);
}
void dynlink__end(worker_t *w) {
  unregister_cbool("dynlink:module_timestamp", 2);
  unregister_cbool("dynlink:static_module", 1);
  unregister_cbool("dynlink:load_module__nocheck", 2);
  unregister_cbool("dynlink:unload_module__nocheck", 1);
  unregister_cbool("dynlink:link_pack", 1);
}
