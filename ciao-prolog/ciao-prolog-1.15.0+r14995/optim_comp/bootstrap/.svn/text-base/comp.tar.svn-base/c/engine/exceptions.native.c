#include <engine/basiccontrol.native.h>
definition_t *exceptions__0;
bcp_t prolog_abort(worker_t *);
void exceptions__init(worker_t *w) {
  exceptions__0 = register_cinsnp("exceptions:$exit", 1, prolog_abort);
  register_builtin("exceptions:$exit", 1, prolog_abort);
}
void exceptions__end(worker_t *w) {
  unregister_cinsnp("exceptions:$exit", 1);
}
