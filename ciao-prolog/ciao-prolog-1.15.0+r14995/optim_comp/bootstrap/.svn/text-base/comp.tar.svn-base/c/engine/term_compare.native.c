#include <engine/basiccontrol.native.h>
bool_t bu2_lexeq(worker_t *, uint32_t, uint32_t);
bool_t bu2_lexne(worker_t *, uint32_t, uint32_t);
bool_t bu2_lexlt(worker_t *, uint32_t, uint32_t);
bool_t bu2_lexle(worker_t *, uint32_t, uint32_t);
bool_t bu2_lexgt(worker_t *, uint32_t, uint32_t);
bool_t bu2_lexge(worker_t *, uint32_t, uint32_t);
uint32_t fu2_compare(worker_t *, uint32_t, uint32_t);
void term__compare__init(worker_t *w) {
  register_builtin("term_compare:==", 2, bu2_lexeq);
  register_builtin("term_compare:\\==", 2, bu2_lexne);
  register_builtin("term_compare:@<", 2, bu2_lexlt);
  register_builtin("term_compare:@=<", 2, bu2_lexle);
  register_builtin("term_compare:@>", 2, bu2_lexgt);
  register_builtin("term_compare:@>=", 2, bu2_lexge);
  register_builtin("term_compare:$compare", 3, fu2_compare);
}
void term__compare__end(worker_t *w) { }
