#include <engine/basiccontrol.native.h>
definition_t *compiler__object____base__0;
bool_t prolog_ooget(worker_t *);
void compiler__object____base__init(worker_t *w) {
  compiler__object____base__0 = register_cbool("compiler_object__base:self_attr_unify", 3, prolog_ooget);
  set_defbits("compiler_object__base:self_attr_unify", 3, 8);
  register_builtin("compiler_object__base:self_attr_unify", 3, prolog_ooget);
}
void compiler__object____base__end(worker_t *w) {
  unregister_cbool("compiler_object__base:self_attr_unify", 3);
}
