#include <engine/basiccontrol.native.h>
bool_t bu2_attach_attribute(worker_t *, uint32_t, uint32_t);
bool_t bu2_attach_attribute_weak(worker_t *, uint32_t, uint32_t);
uint32_t fu1_get_attribute(worker_t *, uint32_t);
bool_t bu2_update_attribute(worker_t *, uint32_t, uint32_t);
bool_t bu1_detach_attribute(worker_t *, uint32_t);
void attributes__init(worker_t *w) {
  register_builtin("attributes:attach_attribute", 2, bu2_attach_attribute);
  register_builtin("attributes:attach_attribute_weak", 2, bu2_attach_attribute_weak);
  register_builtin("attributes:get_attribute", 2, fu1_get_attribute);
  register_builtin("attributes:update_attribute", 2, bu2_update_attribute);
  register_builtin("attributes:detach_attribute", 1, bu1_detach_attribute);
}
void attributes__end(worker_t *w) { }
