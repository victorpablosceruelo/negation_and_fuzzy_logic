#include <engine/basiccontrol.native.h>
definition_t *system__info__0;
definition_t *system__info__1;
definition_t *system__info__2;
definition_t *system__info__3;
definition_t *system__info__4;
definition_t *system__info__5;
definition_t *system__info__6;
definition_t *system__info__7;
bool_t prolog_getarch(worker_t *);
bool_t prolog_getos(worker_t *);
bool_t prolog_ciao_lib_dir(worker_t *);
bool_t prolog_get_so_cc(worker_t *);
bool_t prolog_get_so_ld(worker_t *);
bool_t prolog_get_so_cc_opts(worker_t *);
bool_t prolog_get_so_ld_opts(worker_t *);
bool_t prolog_get_so_libs(worker_t *);
void system__info__init(worker_t *w) {
  system__info__0 = register_cbool("system_info:get_arch", 1, prolog_getarch);
  register_builtin("system_info:get_arch", 1, prolog_getarch);
  system__info__1 = register_cbool("system_info:get_os", 1, prolog_getos);
  register_builtin("system_info:get_os", 1, prolog_getos);
  system__info__2 = register_cbool("system_info:ciao_lib_dir", 1, prolog_ciao_lib_dir);
  register_builtin("system_info:ciao_lib_dir", 1, prolog_ciao_lib_dir);
  system__info__3 = register_cbool("system_info:get_so_cc", 1, prolog_get_so_cc);
  register_builtin("system_info:get_so_cc", 1, prolog_get_so_cc);
  system__info__4 = register_cbool("system_info:get_so_ld", 1, prolog_get_so_ld);
  register_builtin("system_info:get_so_ld", 1, prolog_get_so_ld);
  system__info__5 = register_cbool("system_info:get_so_cc_opts", 1, prolog_get_so_cc_opts);
  register_builtin("system_info:get_so_cc_opts", 1, prolog_get_so_cc_opts);
  system__info__6 = register_cbool("system_info:get_so_ld_opts", 1, prolog_get_so_ld_opts);
  register_builtin("system_info:get_so_ld_opts", 1, prolog_get_so_ld_opts);
  system__info__7 = register_cbool("system_info:get_so_libs", 1, prolog_get_so_libs);
  register_builtin("system_info:get_so_libs", 1, prolog_get_so_libs);
}
void system__info__end(worker_t *w) {
  unregister_cbool("system_info:get_arch", 1);
  unregister_cbool("system_info:get_os", 1);
  unregister_cbool("system_info:ciao_lib_dir", 1);
  unregister_cbool("system_info:get_so_cc", 1);
  unregister_cbool("system_info:get_so_ld", 1);
  unregister_cbool("system_info:get_so_cc_opts", 1);
  unregister_cbool("system_info:get_so_ld_opts", 1);
  unregister_cbool("system_info:get_so_libs", 1);
}
