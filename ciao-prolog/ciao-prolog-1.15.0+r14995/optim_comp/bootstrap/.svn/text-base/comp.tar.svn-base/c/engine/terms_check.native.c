#include <engine/basiccontrol.native.h>
definition_t *terms__check__0;
definition_t *terms__check__1;
bool_t cinstance(worker_t *);
bool_t cinstance(worker_t *);
void terms__check__init(worker_t *w) {
  terms__check__0 = register_cbool("terms_check:ask", 2, cinstance);
  register_builtin("terms_check:ask", 2, cinstance);
  terms__check__1 = register_cbool("terms_check:instance", 2, cinstance);
  register_builtin("terms_check:instance", 2, cinstance);
}
void terms__check__end(worker_t *w) {
  unregister_cbool("terms_check:ask", 2);
  unregister_cbool("terms_check:instance", 2);
}
