#include <engine/basiccontrol.native.h>
definition_t *term__typing__0;
bool_t cground(worker_t *);
bool_t bu1_atom(worker_t *, uint32_t);
bool_t bu1_atomic(worker_t *, uint32_t);
bool_t bu1_float(worker_t *, uint32_t);
bool_t bu1_integer(worker_t *, uint32_t);
bool_t bu1_nonvar(worker_t *, uint32_t);
bool_t bu1_number(worker_t *, uint32_t);
bool_t bu1_var(worker_t *, uint32_t);
uint32_t fu1_type(worker_t *, uint32_t);
void term__typing__init(worker_t *w) {
  term__typing__0 = register_cbool("term_typing:ground", 1, cground);
  register_builtin("term_typing:ground", 1, cground);
  register_builtin("term_typing:atom", 1, bu1_atom);
  register_builtin("term_typing:atomic", 1, bu1_atomic);
  register_builtin("term_typing:float", 1, bu1_float);
  register_builtin("term_typing:integer", 1, bu1_integer);
  register_builtin("term_typing:nonvar", 1, bu1_nonvar);
  register_builtin("term_typing:number", 1, bu1_number);
  register_builtin("term_typing:var", 1, bu1_var);
  register_builtin("term_typing:type", 2, fu1_type);
}
void term__typing__end(worker_t *w) {
  unregister_cbool("term_typing:ground", 1);
}
