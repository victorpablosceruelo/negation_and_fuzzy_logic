#include <engine/basiccontrol.native.h>
definition_t *ql__inout__0;
definition_t *ql__inout__1;
definition_t *ql__inout__2;
definition_t *ql__inout__3;
definition_t *ql__inout__4;
definition_t *ql__inout__5;
definition_t *ql__inout__6;
definition_t *ql__inout__7;
bool_t prolog_qread_begin(worker_t *);
bool_t qread_end(worker_t *);
bool_t prolog_qread(worker_t *);
bool_t qwrite_begin(worker_t *);
bool_t qwrite_end(worker_t *);
bool_t qwrite(worker_t *);
bool_t qwrite_b(worker_t *);
bool_t absnext__set(worker_t *);
void ql__inout__init(worker_t *w) {
  ql__inout__0 = register_cbool("ql_inout:$qread_begin", 1, prolog_qread_begin);
  register_builtin("ql_inout:$qread_begin", 1, prolog_qread_begin);
  ql__inout__1 = register_cbool("ql_inout:$qread_end", 0, qread_end);
  register_builtin("ql_inout:$qread_end", 0, qread_end);
  ql__inout__2 = register_cbool("ql_inout:$qread", 1, prolog_qread);
  register_builtin("ql_inout:$qread", 1, prolog_qread);
  ql__inout__3 = register_cbool("ql_inout:$qwrite_begin", 2, qwrite_begin);
  register_builtin("ql_inout:$qwrite_begin", 2, qwrite_begin);
  ql__inout__4 = register_cbool("ql_inout:$qwrite_end", 0, qwrite_end);
  register_builtin("ql_inout:$qwrite_end", 0, qwrite_end);
  ql__inout__5 = register_cbool("ql_inout:$qwrite", 1, qwrite);
  register_builtin("ql_inout:$qwrite", 1, qwrite);
  ql__inout__6 = register_cbool("ql_inout:$qwrite_b", 1, qwrite_b);
  register_builtin("ql_inout:$qwrite_b", 1, qwrite_b);
  ql__inout__7 = register_cbool("ql_inout:$absnext__set", 8, absnext__set);
  register_builtin("ql_inout:$absnext__set", 8, absnext__set);
}
void ql__inout__end(worker_t *w) {
  unregister_cbool("ql_inout:$qread_begin", 1);
  unregister_cbool("ql_inout:$qread_end", 0);
  unregister_cbool("ql_inout:$qread", 1);
  unregister_cbool("ql_inout:$qwrite_begin", 2);
  unregister_cbool("ql_inout:$qwrite_end", 0);
  unregister_cbool("ql_inout:$qwrite", 1);
  unregister_cbool("ql_inout:$qwrite_b", 1);
  unregister_cbool("ql_inout:$absnext__set", 8);
}
