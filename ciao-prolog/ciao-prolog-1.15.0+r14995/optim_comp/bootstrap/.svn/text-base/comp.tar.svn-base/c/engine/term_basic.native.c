#include <engine/basiccontrol.native.h>
definition_t *term__basic__0;
definition_t *term__basic__1;
bool_t prolog_copy_term(worker_t *);
bool_t prolog_copy_term_shattr(worker_t *);
uint32_t fu2_arg(worker_t *, uint32_t, uint32_t);
bool_t bu3_functor(worker_t *, uint32_t, uint32_t, uint32_t);
bool_t bu2_univ(worker_t *, uint32_t, uint32_t);
bool_t cunify(worker_t *, uint32_t, uint32_t);
void term__basic__init(worker_t *w) {
  term__basic__0 = register_cbool("term_basic:copy_term", 2, prolog_copy_term);
  register_builtin("term_basic:copy_term", 2, prolog_copy_term);
  term__basic__1 = register_cbool("term_basic:copy_term_shattr", 2, prolog_copy_term_shattr);
  register_builtin("term_basic:copy_term_shattr", 2, prolog_copy_term_shattr);
  register_builtin("term_basic:arg", 3, fu2_arg);
  register_builtin("term_basic:functor", 3, bu3_functor);
  register_builtin("term_basic:=..", 2, bu2_univ);
  register_builtin("term_basic:$unify", 2, cunify);
}
void term__basic__end(worker_t *w) {
  unregister_cbool("term_basic:copy_term", 2);
  unregister_cbool("term_basic:copy_term_shattr", 2);
}
