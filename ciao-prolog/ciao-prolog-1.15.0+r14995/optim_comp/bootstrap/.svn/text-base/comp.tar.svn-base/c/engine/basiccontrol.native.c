#include <engine/basiccontrol.native.h>
#include <engine/basiccontrol.h>
tagged_t atm_var;
tagged_t atm_attv;
tagged_t atm_float;
tagged_t atm_int;
tagged_t atm_str;
tagged_t atm_atm;
tagged_t atm_lst;
tagged_t atom_success;
tagged_t atom_failure;
tagged_t atom_share;
tagged_t atom_noshare;
tagged_t atom_user_input;
tagged_t atom_user_output;
tagged_t atom_user_error;
tagged_t atom_read;
tagged_t atom_write;
tagged_t atom_append;
tagged_t atom_socket;
tagged_t atom_symlink;
tagged_t atom_regular;
tagged_t atom_directory;
tagged_t atom_fifo;
tagged_t atom_unknown;
tagged_t atom_user;
tagged_t atom_prolog;
tagged_t atom_lessthan;
tagged_t atom_greaterthan;
tagged_t atom_equal;
tagged_t atom_lst;
tagged_t atom_nil;
tagged_t atom_on;
tagged_t atom_off;
tagged_t atom_error;
tagged_t atom_trace;
tagged_t atom_debug;
tagged_t atom_fail;
tagged_t atom_all;
tagged_t atom_terse;
tagged_t atom_verbose;
tagged_t atom_compiled;
tagged_t atom_interpreted;
tagged_t atom_builtin;
tagged_t atom_true;
tagged_t atom_basiccontroltrue;
tagged_t atom_retry_hook;
tagged_t atom_unprofiled;
tagged_t atom_profiled;
tagged_t atom_concurrent;
tagged_t atom_wait;
tagged_t atom_dynamic;
tagged_t atom_multifile;
tagged_t atom_block;
tagged_t atom_no_block;
tagged_t atom_self;
tagged_t atom_create;
tagged_t atom_dash;
definition_t *basiccontrol__0;
definition_t *basiccontrol__1;
definition_t *basiccontrol__2;
definition_t *basiccontrol__3;
definition_t *basiccontrol__4;
bool_t cunify(worker_t *, uint32_t, uint32_t);
bool_t cunify_aux(worker_t *, uint32_t, uint32_t);
bool_t cunify_args(worker_t *, int32_t, uint32_t *, uint32_t *);
bool_t cunify_args_aux(worker_t *, int32_t, uint32_t *, uint32_t *, uint32_t *, uint32_t *);
void wam__2(worker_t *, char *);
absmachdef_t abscurr = (absmachdef_t){.ftype_id_i = 10, .ftype_id_o = 15, .ins_info = (ftype_base_t *[]){FTYPE_STR(1, BRACES(8)), FTYPE_STR(2, BRACES(3, 8)), FTYPE_STR(3, BRACES(19, 6, 8)), FTYPE_STR(2, BRACES(6, 8)), FTYPE_STR(4, BRACES(19, 3, 6, 8)), FTYPE_STR(3, BRACES(3, 6, 8)), FTYPE_STR(11, BRACES(19, 17, 17, 17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(10, BRACES(17, 17, 17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(10, BRACES(19, 17, 17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(9, BRACES(17, 17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(9, BRACES(19, 17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(8, BRACES(17, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(8, BRACES(19, 17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(7, BRACES(17, 17, 17, 17, 17, 6, 8)), FTYPE_STR(7, BRACES(19, 17, 17, 17, 17, 6, 8)), FTYPE_STR(6, BRACES(17, 17, 17, 17, 6, 8)), FTYPE_STR(6, BRACES(19, 17, 17, 17, 6, 8)), FTYPE_STR(5, BRACES(17, 17, 17, 6, 8)), FTYPE_STR(5, BRACES(19, 17, 17, 6, 8)), FTYPE_STR(4, BRACES(17, 17, 6, 8)), FTYPE_STR(4, BRACES(19, 17, 6, 8)), FTYPE_STR(3, BRACES(17, 6, 8)), FTYPE_STR(3, BRACES(19, 6, 8)), FTYPE_STR(2, BRACES(6, 8)), FTYPE_STR(4, BRACES(19, 4, 6, 8)), FTYPE_STR(3, BRACES(4, 6, 8)), FTYPE_STR(11, BRACES(19, 18, 18, 18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(10, BRACES(18, 18, 18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(10, BRACES(19, 18, 18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(9, BRACES(18, 18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(9, BRACES(19, 18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(8, BRACES(18, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(8, BRACES(19, 18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(7, BRACES(18, 18, 18, 18, 18, 6, 8)), FTYPE_STR(7, BRACES(19, 18, 18, 18, 18, 6, 8)), FTYPE_STR(6, BRACES(18, 18, 18, 18, 6, 8)), FTYPE_STR(6, BRACES(19, 18, 18, 18, 6, 8)), FTYPE_STR(5, BRACES(18, 18, 18, 6, 8)), FTYPE_STR(5, BRACES(19, 18, 18, 6, 8)), FTYPE_STR(4, BRACES(18, 18, 6, 8)), FTYPE_STR(4, BRACES(19, 18, 6, 8)), FTYPE_STR(3, BRACES(18, 6, 8)), FTYPE_STR(3, BRACES(19, 6, 8)), FTYPE_STR(2, BRACES(6, 8)), FTYPE_STR(3, BRACES(19, 4, 6)), FTYPE_STR(2, BRACES(4, 6)), FTYPE_STR(10, BRACES(19, 18, 18, 18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(9, BRACES(18, 18, 18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(9, BRACES(19, 18, 18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(8, BRACES(18, 18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(8, BRACES(19, 18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(7, BRACES(18, 18, 18, 18, 18, 18, 6)), FTYPE_STR(7, BRACES(19, 18, 18, 18, 18, 18, 6)), FTYPE_STR(6, BRACES(18, 18, 18, 18, 18, 6)), FTYPE_STR(6, BRACES(19, 18, 18, 18, 18, 6)), FTYPE_STR(5, BRACES(18, 18, 18, 18, 6)), FTYPE_STR(5, BRACES(19, 18, 18, 18, 6)), FTYPE_STR(4, BRACES(18, 18, 18, 6)), FTYPE_STR(4, BRACES(19, 18, 18, 6)), FTYPE_STR(3, BRACES(18, 18, 6)), FTYPE_STR(3, BRACES(19, 18, 6)), FTYPE_STR(2, BRACES(18, 6)), FTYPE_STR(2, BRACES(19, 6)), FTYPE_STR(1, BRACES(6)), FTYPE_STR(2, BRACES(19, 6)), FTYPE_STR(1, BRACES(6)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(4, BRACES(16, 17, 16, 17)), FTYPE_STR(4, BRACES(16, 17, 16, 17)), FTYPE_STR(4, BRACES(17, 16, 17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(3, BRACES(19, 16, 14)), FTYPE_STR(2, BRACES(16, 14)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(3, BRACES(19, 16, 7)), FTYPE_STR(2, BRACES(16, 7)), FTYPE_STR(3, BRACES(19, 16, 9)), FTYPE_STR(2, BRACES(16, 9)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(4, BRACES(17, 16, 17, 16)), FTYPE_STR(4, BRACES(17, 16, 17, 16)), FTYPE_STR(4, BRACES(17, 16, 17, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(3, BRACES(19, 16, 14)), FTYPE_STR(2, BRACES(16, 14)), FTYPE_STR(3, BRACES(19, 16, 7)), FTYPE_STR(2, BRACES(16, 7)), FTYPE_STR(3, BRACES(19, 16, 9)), FTYPE_STR(2, BRACES(16, 9)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(3, BRACES(19, 16, 14)), FTYPE_STR(2, BRACES(16, 14)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(1, BRACES(16)), FTYPE_STR(0, BRACES()), FTYPE_STR(1, BRACES(16)), FTYPE_STR(0, BRACES()), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(2, BRACES(19, 5)), FTYPE_STR(2, BRACES(19, 5)), FTYPE_STR(4, BRACES(16, 16, 16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(4, BRACES(16, 17, 16, 17)), FTYPE_STR(4, BRACES(16, 17, 16, 17)), FTYPE_STR(2, BRACES(19, 13)), FTYPE_STR(1, BRACES(13)), FTYPE_STR(5, BRACES(19, 16, 16, 5, 12)), FTYPE_STR(4, BRACES(16, 16, 5, 12)), FTYPE_STR(6, BRACES(19, 16, 16, 16, 5, 12)), FTYPE_STR(5, BRACES(16, 16, 16, 5, 12)), FTYPE_STR(5, BRACES(19, 16, 16, 5, 12)), FTYPE_STR(4, BRACES(16, 16, 5, 12)), FTYPE_STR(6, BRACES(19, 16, 16, 16, 5, 12)), FTYPE_STR(5, BRACES(16, 16, 16, 5, 12)), FTYPE_STR(3, BRACES(19, 16, 5)), FTYPE_STR(2, BRACES(16, 5)), FTYPE_STR(4, BRACES(19, 16, 16, 5)), FTYPE_STR(3, BRACES(16, 16, 5)), FTYPE_STR(5, BRACES(19, 16, 16, 16, 5)), FTYPE_STR(4, BRACES(16, 16, 16, 5)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(10)), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(16)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(1, BRACES(17)), FTYPE_STR(2, BRACES(19, 14)), FTYPE_STR(1, BRACES(14)), FTYPE_STR(2, BRACES(19, 7)), FTYPE_STR(1, BRACES(7)), FTYPE_STR(2, BRACES(19, 9)), FTYPE_STR(1, BRACES(9)), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(2, BRACES(19, 14)), FTYPE_STR(1, BRACES(14)), FTYPE_STR(0, BRACES()), FTYPE_STR(2, BRACES(10, 16)), FTYPE_STR(2, BRACES(10, 17)), FTYPE_STR(2, BRACES(10, 17)), FTYPE_STR(2, BRACES(10, 16)), FTYPE_STR(2, BRACES(10, 16)), FTYPE_STR(2, BRACES(10, 17)), FTYPE_STR(2, BRACES(10, 17)), FTYPE_STR(2, BRACES(10, 17)), FTYPE_STR(2, BRACES(16, 10)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(17, 10)), FTYPE_STR(2, BRACES(17, 10)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 10)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(16, 10)), FTYPE_STR(2, BRACES(16, 10)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 16)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(16, 17)), FTYPE_STR(2, BRACES(17, 10)), FTYPE_STR(2, BRACES(17, 10)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 16)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(2, BRACES(17, 17)), FTYPE_STR(0, BRACES()), FTYPE_STR(3, BRACES(19, 11, 10)), FTYPE_STR(2, BRACES(11, 10)), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES()), FTYPE_STR(0, BRACES())}, .ins_n = 253, .ftype_info = (ftype_base_t *[]){FTYPE_STR0(), FTYPE_STR0(), FTYPE_STR0(), FTYPE_ARRAY(10, 17), FTYPE_ARRAY(10, 18), FTYPE_BASIC(4, 9, 6), FTYPE_BASIC(4, 7, 6), FTYPE_BLOB(), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(4, 5, 6), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(4, 2, 6), FTYPE_STR(2, BRACES(11, 10)), FTYPE_BASIC(4, 3, 3), FTYPE_BASIC(4, 6, 6), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(2, 8, 8), FTYPE_BASIC(2, 8, 8)}, .ftype_n = 20, .q_pad1 = 128 * 4, .q_pad2 = 1152 * 4, .tagged_size = 4, .size_align = 4};
char *ins_name[253] = (char *[]){"alloc_init_cframe(f_e)", "init(f_Y)+cframe(f_e)", "pad2|alloc_init_fcall(f_E,f_e)", "alloc_init_fcall(f_E,f_e)", "pad2|init(f_Y)+fcall(f_E,f_e)", "init(f_Y)+fcall(f_E,f_e)", "pad2|init(s(f_Y,8))+fcall(f_E,f_e)", "init(s(f_Y,8))+fcall(f_E,f_e)", "pad2|init(s(f_Y,7))+fcall(f_E,f_e)", "init(s(f_Y,7))+fcall(f_E,f_e)", "pad2|init(s(f_Y,6))+fcall(f_E,f_e)", "init(s(f_Y,6))+fcall(f_E,f_e)", "pad2|init(s(f_Y,5))+fcall(f_E,f_e)", "init(s(f_Y,5))+fcall(f_E,f_e)", "pad2|init(s(f_Y,4))+fcall(f_E,f_e)", "init(s(f_Y,4))+fcall(f_E,f_e)", "pad2|init(s(f_Y,3))+fcall(f_E,f_e)", "init(s(f_Y,3))+fcall(f_E,f_e)", "pad2|init(s(f_Y,2))+fcall(f_E,f_e)", "init(s(f_Y,2))+fcall(f_E,f_e)", "pad2|init(s(f_Y,1))+fcall(f_E,f_e)", "init(s(f_Y,1))+fcall(f_E,f_e)", "pad2|fcall(f_E,f_e)", "fcall(f_E,f_e)", "pad2|zputn(f_Z)+kall(f_E,f_e)", "zputn(f_Z)+kall(f_E,f_e)", "pad2|zputn(s(f_Z,8))+kall(f_E,f_e)", "zputn(s(f_Z,8))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,7))+kall(f_E,f_e)", "zputn(s(f_Z,7))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,6))+kall(f_E,f_e)", "zputn(s(f_Z,6))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,5))+kall(f_E,f_e)", "zputn(s(f_Z,5))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,4))+kall(f_E,f_e)", "zputn(s(f_Z,4))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,3))+kall(f_E,f_e)", "zputn(s(f_Z,3))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,2))+kall(f_E,f_e)", "zputn(s(f_Z,2))+kall(f_E,f_e)", "pad2|zputn(s(f_Z,1))+kall(f_E,f_e)", "zputn(s(f_Z,1))+kall(f_E,f_e)", "pad2|kall(f_E,f_e)", "kall(f_E,f_e)", "pad2|zputn(f_Z)+dealloc+lastcall(f_E)", "zputn(f_Z)+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,8))+dealloc+lastcall(f_E)", "zputn(s(f_Z,8))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,7))+dealloc+lastcall(f_E)", "zputn(s(f_Z,7))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,6))+dealloc+lastcall(f_E)", "zputn(s(f_Z,6))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,5))+dealloc+lastcall(f_E)", "zputn(s(f_Z,5))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,4))+dealloc+lastcall(f_E)", "zputn(s(f_Z,4))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,3))+dealloc+lastcall(f_E)", "zputn(s(f_Z,3))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,2))+dealloc+lastcall(f_E)", "zputn(s(f_Z,2))+dealloc+lastcall(f_E)", "pad2|zputn(s(f_Z,1))+dealloc+lastcall(f_E)", "zputn(s(f_Z,1))+dealloc+lastcall(f_E)", "pad2|dealloc+lastcall(f_E)", "dealloc+lastcall(f_E)", "pad2|lastcall(f_E)", "lastcall(f_E)", "inith(f_x)", "init2h(f_x,f_x)", "globunsafe2(f_x,f_x)", "alloc+init2s(f_x,f_y)", "init2s(f_x,f_y)", "alloc+init2s(f_x,f_y)+init2s(f_x,f_y)", "init2s(f_x,f_y)+init2s(f_x,f_y)", "move(f_y,f_x)+move(f_y,f_x)", "move(f_y,f_x)", "globunsafe(f_y,f_x)", "pad2|ld_cons(f_x,f_t)", "ld_cons(f_x,f_t)", "ld_cons(f_x,f_t([]))", "pad2|ld_blob(f_x,f_b)", "ld_blob(f_x,f_b)", "pad2|ld_str(f_x,f_f)", "ld_str(f_x,f_f)", "ld_str(f_x,f_f(/(.,2)))", "move(f_y,f_x)+globunsafe(f_y,f_x)", "globunsafe(f_y,f_x)+move(f_y,f_x)", "globunsafe(f_y,f_x)+globunsafe(f_y,f_x)", "u_val(f_x,f_x)", "u_fval(f_x,f_y)", "u_val(f_x,f_y)", "pad2|u_cons(f_x,f_t)", "u_cons(f_x,f_t)", "pad2|u_blob(f_x,f_b)", "u_blob(f_x,f_b)", "pad2|u_str(f_x,f_f)", "u_str(f_x,f_f)", "u_cons(f_x,f_t([]))", "u_str(f_x,f_f(/(.,2)))", "pad2|u_cons(f_x,f_t)+neck+proceed", "u_cons(f_x,f_t)+neck+proceed", "u_cons(f_x,f_t([]))+neck+proceed", "cutb(f_x)", "cutb(f_x(-1))", "cutb(f_x(-1))+proceed", "cute(f_x)", "cute(f_x(-1))", "cutf(f_x)", "cutf(f_x(-1))", "cutf(f_y)", "getchoice(f_x)", "alloc+getchoice(f_y)", "getchoice(f_y)", "kontinue", "exit_toplevel", "pad2|retry_cbool(f_C)+proceed", "pad2|exec_cinsnp(f_C)", "move(f_x,f_x)+move(f_x,f_x)", "move(f_x,f_x)", "alloc+move(f_x,f_y)", "move(f_x,f_y)", "alloc+move(f_x,f_y)+move(f_x,f_y)", "move(f_x,f_y)+move(f_x,f_y)", "pad2|jump", "jump", "pad2|fun1(f_x,f_x,f_C,f_g)", "fun1(f_x,f_x,f_C,f_g)", "pad2|fun2(f_x,f_x,f_x,f_C,f_g)", "fun2(f_x,f_x,f_x,f_C,f_g)", "pad2|funre1(f_x,f_x,f_C,f_g)", "funre1(f_x,f_x,f_C,f_g)", "pad2|funre2(f_x,f_x,f_x,f_C,f_g)", "funre2(f_x,f_x,f_x,f_C,f_g)", "pad2|blt1(f_x,f_C)", "blt1(f_x,f_C)", "pad2|blt2(f_x,f_x,f_C)", "blt2(f_x,f_x,f_C)", "pad2|blt3(f_x,f_x,f_x,f_C)", "blt3(f_x,f_x,f_x,f_C)", "u_constraint(f_x)", "un_voidr(f_i)", "un_voidr(c(4))", "un_voidr(c(3))", "un_voidr(c(2))", "un_voidr(c(1))", "un_var(f_x)", "un_val(f_x)", "un_lval(f_x)", "alloc+un_var(f_y)", "un_var(f_y)", "un_fval(f_y)", "un_val(f_y)", "un_lval(f_y)", "pad2|un_cons(f_t)", "un_cons(f_t)", "pad2|un_blob(f_b)", "un_blob(f_b)", "pad2|un_str(f_f)", "un_str(f_f)", "un_cons(f_t([]))", "un_str(f_f(/(.,2)))", "pad2|un_cons(f_t)+neck+proceed", "un_cons(f_t)+neck+proceed", "un_cons(f_t([]))+neck+proceed", "un_voidr(f_i)+un_var(f_x)", "alloc+un_voidr(f_i)+un_var(f_y)", "un_voidr(f_i)+un_var(f_y)", "un_voidr(f_i)+un_val(f_x)", "un_voidr(f_i)+un_lval(f_x)", "un_voidr(f_i)+un_fval(f_y)", "un_voidr(f_i)+un_val(f_y)", "un_voidr(f_i)+un_lval(f_y)", "un_var(f_x)+un_voidr(f_i)", "un_var(f_x)+un_var(f_x)", "alloc+un_var(f_x)+un_var(f_y)", "un_var(f_x)+un_var(f_y)", "un_var(f_x)+un_val(f_x)", "un_var(f_x)+un_lval(f_x)", "un_var(f_x)+un_fval(f_y)", "un_var(f_x)+un_val(f_y)", "un_var(f_x)+un_lval(f_y)", "alloc+un_var(f_y)+un_voidr(f_i)", "un_var(f_y)+un_voidr(f_i)", "alloc+un_var(f_y)+un_var(f_x)", "un_var(f_y)+un_var(f_x)", "alloc+un_var(f_y)+un_var(f_y)", "un_var(f_y)+un_var(f_y)", "alloc+un_var(f_y)+un_val(f_x)", "alloc+un_var(f_y)+un_lval(f_x)", "un_var(f_y)+un_val(f_x)", "un_var(f_y)+un_lval(f_x)", "alloc+un_var(f_y)+un_val(f_y)", "alloc+un_var(f_y)+un_lval(f_y)", "un_var(f_y)+un_val(f_y)", "un_var(f_y)+un_lval(f_y)", "un_fval(f_y)+un_voidr(f_i)", "un_fval(f_y)+un_var(f_x)", "un_fval(f_y)+un_fval(f_y)", "un_fval(f_y)+un_val(f_x)", "un_fval(f_y)+un_lval(f_x)", "un_fval(f_y)+un_val(f_y)", "un_fval(f_y)+un_lval(f_y)", "un_val(f_x)+un_voidr(f_i)", "un_lval(f_x)+un_voidr(f_i)", "un_val(f_x)+un_var(f_x)", "un_lval(f_x)+un_var(f_x)", "alloc+un_val(f_x)+un_var(f_y)", "alloc+un_lval(f_x)+un_var(f_y)", "un_val(f_x)+un_var(f_y)", "un_lval(f_x)+un_var(f_y)", "un_val(f_x)+un_val(f_x)", "un_val(f_x)+un_lval(f_x)", "un_lval(f_x)+un_val(f_x)", "un_lval(f_x)+un_lval(f_x)", "un_val(f_x)+un_fval(f_y)", "un_lval(f_x)+un_fval(f_y)", "un_val(f_x)+un_val(f_y)", "un_val(f_x)+un_lval(f_y)", "un_lval(f_x)+un_val(f_y)", "un_lval(f_x)+un_lval(f_y)", "un_val(f_y)+un_voidr(f_i)", "un_lval(f_y)+un_voidr(f_i)", "un_val(f_y)+un_var(f_x)", "un_lval(f_y)+un_var(f_x)", "un_val(f_y)+un_var(f_y)", "un_lval(f_y)+un_var(f_y)", "un_val(f_y)+un_fval(f_y)", "un_lval(f_y)+un_fval(f_y)", "un_val(f_y)+un_val(f_x)", "un_val(f_y)+un_lval(f_x)", "un_lval(f_y)+un_val(f_x)", "un_lval(f_y)+un_lval(f_x)", "un_val(f_y)+un_val(f_y)", "un_val(f_y)+un_lval(f_y)", "un_lval(f_y)+un_val(f_y)", "un_lval(f_y)+un_lval(f_y)", "failins", "pad2|heapmargin_call(f_l,f_i)", "heapmargin_call(f_l,f_i)", "neck", "neck+proceed", "dealloc+proceed", "proceed", "restore_all_next_alt", "restore_all_no_alt", "exec_cinsnp_alt", "func__enter_undefined", "func__enter_interpreted", "func__enter_cbool", "func__enter_cinsnp", "func__enter_cvoid", "func__enter_indexed", "func__enter_nonindexed", "dynamic_neck__proceed"};
bool_t cunify(worker_t *w, uint32_t A0, uint32_t A1) {
  uint32_t var0;
  DerefSw_HVA_CVA_SVA_Other(A0, goto lab0;, goto lab19;, goto lab32;, goto lab51;);
lab0:
  DerefSw_HVA_CVA_SVA_Other(A1, goto lab1;, goto lab10;, goto lab13;, goto lab16;);
lab1:
  if (A0 == A1) goto lab2; else goto lab3;
lab2:
  return TRUE;
lab3:
  if (YoungerHeapVar(A1, A0)) goto lab4; else goto lab7;
lab4:
  if (CondHVA(A1)) goto lab5; else goto lab6;
lab5:
  trail_push_check(w, A1);
  goto lab6;
lab6:
  *TagpPtr(0, A1) = A0;
  return TRUE;
lab7:
  if (CondHVA(A0)) goto lab8; else goto lab9;
lab8:
  trail_push_check(w, A0);
  goto lab9;
lab9:
  *TagpPtr(0, A0) = A1;
  return TRUE;
lab10:
  if (CondHVA(A0)) goto lab11; else goto lab12;
lab11:
  trail_push_check(w, A0);
  goto lab12;
lab12:
  *TagpPtr(0, A0) = A1;
  return TRUE;
lab13:
  if (CondSVA(A1)) goto lab14; else goto lab15;
lab14:
  trail_push_check(w, A1);
  goto lab15;
lab15:
  *TagpPtr(2, A1) = A0;
  return TRUE;
lab16:
  if (CondHVA(A0)) goto lab17; else goto lab18;
lab17:
  trail_push_check(w, A0);
  goto lab18;
lab18:
  *TagpPtr(0, A0) = A1;
  return TRUE;
lab19:
  DerefSw_HVA_CVA_SVA_Other(A1, goto lab20;, goto lab23;, goto lab28;, goto lab31;);
lab20:
  if (CondHVA(A1)) goto lab21; else goto lab22;
lab21:
  trail_push_check(w, A1);
  goto lab22;
lab22:
  *TagpPtr(0, A1) = A0;
  return TRUE;
lab23:
  if (A0 == A1) goto lab24; else goto lab25;
lab24:
  return TRUE;
lab25:
  if (YoungerHeapVar(A1, A0)) goto lab26; else goto lab27;
lab26:
  trail_push_check(w, A1);
  *TagpPtr(1, A1) = A0;
  IncWakeCount();
  return TRUE;
lab27:
  trail_push_check(w, A0);
  *TagpPtr(1, A0) = A1;
  IncWakeCount();
  return TRUE;
lab28:
  if (CondSVA(A1)) goto lab29; else goto lab30;
lab29:
  trail_push_check(w, A1);
  goto lab30;
lab30:
  *TagpPtr(2, A1) = A0;
  return TRUE;
lab31:
  trail_push_check(w, A0);
  *TagpPtr(1, A0) = A1;
  IncWakeCount();
  return TRUE;
lab32:
  DerefSw_HVA_CVA_SVA_Other(A1, goto lab33;, goto lab36;, goto lab39;, goto lab48;);
lab33:
  if (CondSVA(A0)) goto lab34; else goto lab35;
lab34:
  trail_push_check(w, A0);
  goto lab35;
lab35:
  *TagpPtr(2, A0) = A1;
  return TRUE;
lab36:
  if (CondSVA(A0)) goto lab37; else goto lab38;
lab37:
  trail_push_check(w, A0);
  goto lab38;
lab38:
  *TagpPtr(2, A0) = A1;
  return TRUE;
lab39:
  if (A0 == A1) goto lab40; else goto lab41;
lab40:
  return TRUE;
lab41:
  if (YoungerStackVar(A1, A0)) goto lab42; else goto lab45;
lab42:
  if (CondSVA(A1)) goto lab43; else goto lab44;
lab43:
  trail_push_check(w, A1);
  goto lab44;
lab44:
  *TagpPtr(2, A1) = A0;
  return TRUE;
lab45:
  if (CondSVA(A0)) goto lab46; else goto lab47;
lab46:
  trail_push_check(w, A0);
  goto lab47;
lab47:
  *TagpPtr(2, A0) = A1;
  return TRUE;
lab48:
  if (CondSVA(A0)) goto lab49; else goto lab50;
lab49:
  trail_push_check(w, A0);
  goto lab50;
lab50:
  *TagpPtr(2, A0) = A1;
  return TRUE;
lab51:
  DerefSw_HVA_CVA_SVA_Other(A1, goto lab52;, goto lab55;, goto lab56;, goto lab59;);
lab52:
  if (CondHVA(A1)) goto lab53; else goto lab54;
lab53:
  trail_push_check(w, A1);
  goto lab54;
lab54:
  *TagpPtr(0, A1) = A0;
  return TRUE;
lab55:
  trail_push_check(w, A1);
  *TagpPtr(1, A1) = A0;
  IncWakeCount();
  return TRUE;
lab56:
  if (CondSVA(A1)) goto lab57; else goto lab58;
lab57:
  trail_push_check(w, A1);
  goto lab58;
lab58:
  *TagpPtr(2, A1) = A0;
  return TRUE;
lab59:
  if (A0 == A1) goto lab60; else goto lab61;
lab60:
  return TRUE;
lab61:
  if (TaggedSameTag(A0, A1)) goto lab62; else goto lab71;
lab62:
  Sw_NUMorATM_LST_STR(A0, goto lab71;, goto lab63;, goto lab65;);
lab63:
  if (cunify_args(w, 2, TaggedToCar(A0), TaggedToCar(A1))) goto lab64; else goto lab71;
lab64:
  return TRUE;
lab65:
  var0 = TaggedToHeadfunctor(A1);
  if (TaggedToHeadfunctor(A0) != var0) goto lab71; else goto lab66;
lab66:
  if (FunctorIsBlob(var0)) goto lab67; else goto lab69;
lab67:
  if (compare_blob(TagpPtr(7, A0), TagpPtr(7, A1))) goto lab68; else goto lab71;
lab68:
  return TRUE;
lab69:
  if (cunify_args(w, Arity(var0), TaggedToArg(A0, 1), TaggedToArg(A1, 1))) goto lab70; else goto lab71;
lab70:
  return TRUE;
lab71:
  return FALSE;
}
bool_t cunify_aux(worker_t *w, uint32_t A0, uint32_t A1) {
  uint32_t var0;
  uint32_t var1;
  uint32_t var2;
  var0 = A0;
  var1 = A1;
  goto lab0;
lab0:
  DerefSw_HVA_CVA_SVA_Other(var0, goto lab1;, goto lab20;, goto lab33;, goto lab52;);
lab1:
  DerefSw_HVA_CVA_SVA_Other(var1, goto lab2;, goto lab11;, goto lab14;, goto lab17;);
lab2:
  if (var0 == var1) goto lab3; else goto lab4;
lab3:
  return TRUE;
lab4:
  if (YoungerHeapVar(var1, var0)) goto lab5; else goto lab8;
lab5:
  if (CondHVA(var1)) goto lab6; else goto lab7;
lab6:
  trail_push_check(w, var1);
  goto lab7;
lab7:
  *TagpPtr(0, var1) = var0;
  return TRUE;
lab8:
  if (CondHVA(var0)) goto lab9; else goto lab10;
lab9:
  trail_push_check(w, var0);
  goto lab10;
lab10:
  *TagpPtr(0, var0) = var1;
  return TRUE;
lab11:
  if (CondHVA(var0)) goto lab12; else goto lab13;
lab12:
  trail_push_check(w, var0);
  goto lab13;
lab13:
  *TagpPtr(0, var0) = var1;
  return TRUE;
lab14:
  if (CondSVA(var1)) goto lab15; else goto lab16;
lab15:
  trail_push_check(w, var1);
  goto lab16;
lab16:
  *TagpPtr(2, var1) = var0;
  return TRUE;
lab17:
  if (CondHVA(var0)) goto lab18; else goto lab19;
lab18:
  trail_push_check(w, var0);
  goto lab19;
lab19:
  *TagpPtr(0, var0) = var1;
  return TRUE;
lab20:
  DerefSw_HVA_CVA_SVA_Other(var1, goto lab21;, goto lab24;, goto lab29;, goto lab32;);
lab21:
  if (CondHVA(var1)) goto lab22; else goto lab23;
lab22:
  trail_push_check(w, var1);
  goto lab23;
lab23:
  *TagpPtr(0, var1) = var0;
  return TRUE;
lab24:
  if (var0 == var1) goto lab25; else goto lab26;
lab25:
  return TRUE;
lab26:
  if (YoungerHeapVar(var1, var0)) goto lab27; else goto lab28;
lab27:
  trail_push_check(w, var1);
  *TagpPtr(1, var1) = var0;
  IncWakeCount();
  return TRUE;
lab28:
  trail_push_check(w, var0);
  *TagpPtr(1, var0) = var1;
  IncWakeCount();
  return TRUE;
lab29:
  if (CondSVA(var1)) goto lab30; else goto lab31;
lab30:
  trail_push_check(w, var1);
  goto lab31;
lab31:
  *TagpPtr(2, var1) = var0;
  return TRUE;
lab32:
  trail_push_check(w, var0);
  *TagpPtr(1, var0) = var1;
  IncWakeCount();
  return TRUE;
lab33:
  DerefSw_HVA_CVA_SVA_Other(var1, goto lab34;, goto lab37;, goto lab40;, goto lab49;);
lab34:
  if (CondSVA(var0)) goto lab35; else goto lab36;
lab35:
  trail_push_check(w, var0);
  goto lab36;
lab36:
  *TagpPtr(2, var0) = var1;
  return TRUE;
lab37:
  if (CondSVA(var0)) goto lab38; else goto lab39;
lab38:
  trail_push_check(w, var0);
  goto lab39;
lab39:
  *TagpPtr(2, var0) = var1;
  return TRUE;
lab40:
  if (var0 == var1) goto lab41; else goto lab42;
lab41:
  return TRUE;
lab42:
  if (YoungerStackVar(var1, var0)) goto lab43; else goto lab46;
lab43:
  if (CondSVA(var1)) goto lab44; else goto lab45;
lab44:
  trail_push_check(w, var1);
  goto lab45;
lab45:
  *TagpPtr(2, var1) = var0;
  return TRUE;
lab46:
  if (CondSVA(var0)) goto lab47; else goto lab48;
lab47:
  trail_push_check(w, var0);
  goto lab48;
lab48:
  *TagpPtr(2, var0) = var1;
  return TRUE;
lab49:
  if (CondSVA(var0)) goto lab50; else goto lab51;
lab50:
  trail_push_check(w, var0);
  goto lab51;
lab51:
  *TagpPtr(2, var0) = var1;
  return TRUE;
lab52:
  DerefSw_HVA_CVA_SVA_Other(var1, goto lab53;, goto lab56;, goto lab57;, goto lab60;);
lab53:
  if (CondHVA(var1)) goto lab54; else goto lab55;
lab54:
  trail_push_check(w, var1);
  goto lab55;
lab55:
  *TagpPtr(0, var1) = var0;
  return TRUE;
lab56:
  trail_push_check(w, var1);
  *TagpPtr(1, var1) = var0;
  IncWakeCount();
  return TRUE;
lab57:
  if (CondSVA(var1)) goto lab58; else goto lab59;
lab58:
  trail_push_check(w, var1);
  goto lab59;
lab59:
  *TagpPtr(2, var1) = var0;
  return TRUE;
lab60:
  if (var0 == var1) goto lab61; else goto lab62;
lab61:
  return TRUE;
lab62:
  if (TaggedSameTag(var0, var1)) goto lab63; else goto lab72;
lab63:
  Sw_NUMorATM_LST_STR(var0, goto lab72;, goto lab64;, goto lab66;);
lab64:
  if (cunify_args_aux(w, 2, TaggedToCar(var0), TaggedToCar(var1), &A0, &A1)) goto lab65; else goto lab72;
lab65:
  var0 = A0;
  var1 = A1;
  goto lab0;
lab66:
  var2 = TaggedToHeadfunctor(var1);
  if (TaggedToHeadfunctor(var0) != var2) goto lab72; else goto lab67;
lab67:
  if (FunctorIsBlob(var2)) goto lab68; else goto lab70;
lab68:
  if (compare_blob(TagpPtr(7, var0), TagpPtr(7, var1))) goto lab69; else goto lab72;
lab69:
  return TRUE;
lab70:
  if (cunify_args_aux(w, Arity(var2), TaggedToArg(var0, 1), TaggedToArg(var1, 1), &A0, &A1)) goto lab71; else goto lab72;
lab71:
  var0 = A0;
  var1 = A1;
  goto lab0;
lab72:
  return FALSE;
}
bool_t cunify_args(worker_t *w, int32_t A0, uint32_t *A1, uint32_t *A2) {
  uint32_t var0;
  uint32_t var1;
  int32_t var2;
  if (cunify_args_aux(w, A0, A1, A2, &var0, &var1)) goto lab0; else goto lab2;
lab0:
  if (cunify_aux(w, var0, var1)) goto lab1; else goto lab2;
lab1:
  var2 = 1;
  goto lab3;
lab2:
  var2 = 0;
  goto lab3;
lab3:
  VALUETRAIL__UNDO();
  if (var2 == 1) goto lab4; else goto lab5;
lab4:
  return TRUE;
lab5:
  return FALSE;
}
bool_t cunify_args_aux(worker_t *w, int32_t A0, uint32_t *A1, uint32_t *A2, uint32_t *A3, uint32_t *A4) {
  uint32_t var0;
  uint32_t var1;
  var0 = 0;
  var1 = 0;
  VALUETRAIL__TEST_OVERFLOW(CHOICEPAD);
  goto lab1;
lab0:
  *A3 = var0;
  *A4 = var1;
  return TRUE;
lab1:
  if (A0 <= 0) goto lab0; else goto lab2;
lab2:
  var0 = *A1;
  var1 = *A2;
  if (var0 == var1) goto lab11; else goto lab3;
lab3:
  HeapDerefSw_HVAorCVA_Other(var0, goto lab12;, goto lab4;);
lab4:
  HeapDerefSw_HVAorCVA_Other(var1, goto lab12;, goto lab5;);
lab5:
  if (var0 == var1) goto lab11; else goto lab6;
lab6:
  Sw_LSTorSTR_Other(var0, goto lab7;, goto lab14;);
lab7:
  Sw_LSTorSTR_Other(var1, goto lab8;, goto lab14;);
lab8:
  if (var0 > var1) goto lab9; else goto lab10;
lab9:
  VALUETRAIL__SET(A1, var1);
  goto lab12;
lab10:
  VALUETRAIL__SET(A2, var0);
  goto lab12;
lab11:
  A1 = A1 + 1;
  A2 = A2 + 1;
  A0 = A0 - 1;
  goto lab1;
lab12:
  if (A0 > 1) goto lab13; else goto lab11;
lab13:
  if (cunify_aux(w, var0, var1)) goto lab11; else goto lab14;
lab14:
  return FALSE;
}
void wam__2(worker_t *w, char *A0) {
  char *p;
  frame_t *frame;
  uint32_t *pt2;
  static const void *const var0[253] = (const void *const[]){&&lab1, &&lab2, &&lab3, &&lab4, &&lab5, &&lab6, &&lab7, &&lab8, &&lab9, &&lab10, &&lab11, &&lab12, &&lab13, &&lab14, &&lab15, &&lab16, &&lab17, &&lab18, &&lab19, &&lab20, &&lab21, &&lab22, &&lab23, &&lab24, &&lab27, &&lab28, &&lab29, &&lab30, &&lab31, &&lab32, &&lab33, &&lab34, &&lab35, &&lab36, &&lab37, &&lab38, &&lab39, &&lab40, &&lab41, &&lab42, &&lab43, &&lab44, &&lab45, &&lab46, &&lab47, &&lab48, &&lab49, &&lab50, &&lab51, &&lab52, &&lab53, &&lab54, &&lab55, &&lab56, &&lab57, &&lab58, &&lab59, &&lab60, &&lab61, &&lab62, &&lab63, &&lab64, &&lab65, &&lab66, &&lab67, &&lab68, &&lab69, &&lab70, &&lab71, &&lab72, &&lab77, &&lab78, &&lab83, &&lab84, &&lab85, &&lab86, &&lab87, &&lab88, &&lab89, &&lab90, &&lab91, &&lab92, &&lab93, &&lab94, &&lab95, &&lab96, &&lab97, &&lab98, &&lab101, &&lab104, &&lab107, &&lab108, &&lab118, &&lab119, &&lab130, &&lab131, &&lab143, &&lab153, &&lab164, &&lab165, &&lab174, &&lab183, &&lab184, &&lab185, &&lab186, &&lab187, &&lab188, &&lab189, &&lab190, &&lab191, &&lab192, &&lab197, &&lab198, &&lab199, &&lab200, &&lab203, &&lab204, &&lab205, &&lab206, &&lab211, &&lab212, &&lab217, &&lab218, &&lab219, &&lab220, &&lab221, &&lab222, &&lab223, &&lab224, &&lab226, &&lab228, &&lab230, &&lab232, &&lab234, &&lab236, &&lab238, &&lab240, &&lab242, &&lab244, &&lab245, &&lab246, &&lab247, &&lab248, &&lab249, &&lab250, &&lab251, &&lab252, &&lab255, &&lab260, &&lab261, &&lab264, &&lab265, &&lab268, &&lab269, &&lab276, &&lab277, &&lab285, &&lab286, &&lab295, &&lab302, &&lab310, &&lab311, &&lab317, &&lab323, &&lab324, &&lab329, &&lab330, &&lab331, &&lab334, &&lab337, &&lab338, &&lab341, &&lab342, &&lab343, &&lab348, &&lab349, &&lab350, &&lab353, &&lab356, &&lab357, &&lab360, &&lab365, &&lab366, &&lab371, &&lab372, &&lab377, &&lab378, &&lab379, &&lab384, &&lab385, &&lab388, &&lab389, &&lab394, &&lab395, &&lab398, &&lab401, &&lab404, &&lab409, &&lab410, &&lab415, &&lab416, &&lab421, &&lab422, &&lab425, &&lab426, &&lab429, &&lab430, &&lab435, &&lab436, &&lab439, &&lab440, &&lab441, &&lab442, &&lab447, &&lab448, &&lab453, &&lab454, &&lab455, &&lab456, &&lab461, &&lab462, &&lab465, &&lab466, &&lab469, &&lab470, &&lab473, &&lab474, &&lab479, &&lab480, &&lab481, &&lab482, &&lab487, &&lab488, &&lab489, &&lab490, &&lab496, &&lab497, &&lab498, &&lab499, &&lab506, &&lab513, &&lab514, &&lab515, &&lab531, &&lab547, &&lab548, &&lab553, &&lab558, &&lab563, &&lab568, &&lab573, &&lab584, &&lab595};
  static const void *const var1[253] = (const void *const[]){&&lab615, &&lab625, &&lab631, &&lab632, &&lab642, &&lab643, &&lab646, &&lab647, &&lab648, &&lab649, &&lab650, &&lab651, &&lab652, &&lab653, &&lab654, &&lab655, &&lab656, &&lab657, &&lab658, &&lab659, &&lab660, &&lab661, &&lab662, &&lab663, &&lab666, &&lab667, &&lab678, &&lab679, &&lab688, &&lab689, &&lab698, &&lab699, &&lab708, &&lab709, &&lab718, &&lab719, &&lab728, &&lab729, &&lab738, &&lab739, &&lab748, &&lab749, &&lab758, &&lab759, &&lab760, &&lab761, &&lab772, &&lab773, &&lab782, &&lab783, &&lab792, &&lab793, &&lab802, &&lab803, &&lab812, &&lab813, &&lab822, &&lab823, &&lab832, &&lab833, &&lab842, &&lab843, &&lab852, &&lab853, &&lab854, &&lab855, &&lab856, &&lab857, &&lab858, &&lab864, &&lab869, &&lab870, &&lab875, &&lab876, &&lab877, &&lab878, &&lab884, &&lab885, &&lab886, &&lab887, &&lab888, &&lab889, &&lab890, &&lab891, &&lab892, &&lab898, &&lab904, &&lab915, &&lab916, &&lab917, &&lab918, &&lab919, &&lab920, &&lab921, &&lab922, &&lab923, &&lab924, &&lab925, &&lab926, &&lab927, &&lab928, &&lab929, &&lab930, &&lab931, &&lab932, &&lab933, &&lab934, &&lab935, &&lab936, &&lab937, &&lab938, &&lab943, &&lab944, &&lab945, &&lab946, &&lab947, &&lab948, &&lab949, &&lab950, &&lab955, &&lab956, &&lab961, &&lab962, &&lab963, &&lab964, &&lab965, &&lab966, &&lab967, &&lab968, &&lab969, &&lab970, &&lab971, &&lab972, &&lab973, &&lab974, &&lab975, &&lab976, &&lab977, &&lab978, &&lab988, &&lab991, &&lab992, &&lab993, &&lab994, &&lab995, &&lab996, &&lab997, &&lab1002, &&lab1007, &&lab1008, &&lab1011, &&lab1012, &&lab1017, &&lab1018, &&lab1019, &&lab1020, &&lab1021, &&lab1022, &&lab1023, &&lab1024, &&lab1025, &&lab1026, &&lab1027, &&lab1028, &&lab1031, &&lab1036, &&lab1039, &&lab1042, &&lab1049, &&lab1054, &&lab1057, &&lab1064, &&lab1067, &&lab1068, &&lab1073, &&lab1074, &&lab1075, &&lab1080, &&lab1083, &&lab1084, &&lab1089, &&lab1094, &&lab1097, &&lab1102, &&lab1103, &&lab1108, &&lab1109, &&lab1114, &&lab1119, &&lab1120, &&lab1125, &&lab1130, &&lab1135, &&lab1136, &&lab1141, &&lab1146, &&lab1149, &&lab1154, &&lab1157, &&lab1164, &&lab1167, &&lab1174, &&lab1177, &&lab1184, &&lab1185, &&lab1190, &&lab1195, &&lab1200, &&lab1201, &&lab1206, &&lab1207, &&lab1212, &&lab1217, &&lab1226, &&lab1229, &&lab1236, &&lab1237, &&lab1242, &&lab1247, &&lab1256, &&lab1259, &&lab1266, &&lab1267, &&lab1272, &&lab1273, &&lab1278, &&lab1281, &&lab1288, &&lab1289, &&lab1294, &&lab1299, &&lab1308, &&lab1309, &&lab1314, &&lab1319, &&lab1328, &&lab1329, &&lab1330, &&lab1331, &&lab1338, &&lab1339, &&lab1340, &&lab1341, &&lab1342, &&lab1343, &&lab1344, &&lab1345, &&lab1346, &&lab1347, &&lab1348, &&lab1349, &&lab1350, &&lab1351};
  frame_t *var2;
  frame_t *var3;
  uint32_t var4;
  uint32_t var5;
  uint32_t var6;
  uint32_t var7;
  uint32_t var8;
  uint32_t var9;
  uint32_t var10;
  uint32_t var11;
  uint32_t var12;
  uint32_t var13;
  uint32_t var14;
  choice_t *var15;
  choice_t *var16;
  choice_t *var17;
  choice_t *var18;
  choice_t *var19;
  choice_t *var20;
  choice_t *var21;
  choice_t *var22;
  frame_t *var23;
  definition_t *var24;
  frame_t *var25;
  frame_t *var26;
  uint32_t var27;
  uint32_t var28;
  uint32_t var29;
  frame_t *var30;
  uint32_t var31;
  uint32_t var32;
  uint32_t var33;
  uint32_t var34;
  uint32_t var35;
  uint32_t var36;
  uint32_t var37;
  uint32_t var38;
  uint32_t var39;
  uint32_t var40;
  uint32_t var41;
  frame_t *var42;
  uint32_t var43;
  uint32_t var44;
  uint32_t var45;
  uint32_t var46;
  uint32_t var47;
  uint32_t var48;
  uint32_t var49;
  frame_t *var50;
  uint32_t var51;
  uint32_t var52;
  uint32_t var53;
  uint32_t var54;
  uint32_t var55;
  uint32_t var56;
  uint32_t var57;
  frame_t *var58;
  frame_t *var59;
  frame_t *var60;
  frame_t *var61;
  uint32_t var62;
  uint32_t var63;
  uint32_t var64;
  frame_t *var65;
  uint32_t var66;
  uint32_t var67;
  uint32_t var68;
  uint32_t var69;
  uint32_t var70;
  uint32_t var71;
  uint32_t var72;
  uint32_t var73;
  uint32_t var74;
  uint32_t var75;
  uint32_t var76;
  uint32_t var77;
  uint32_t var78;
  uint32_t var79;
  uint32_t var80;
  uint32_t var81;
  uint32_t var82;
  uint32_t var83;
  uint32_t var84;
  uint32_t var85;
  uint32_t var86;
  uint32_t var87;
  frame_t *var88;
  uint32_t var89;
  uint32_t var90;
  uint32_t var91;
  uint32_t var92;
  uint32_t var93;
  uint32_t var94;
  uint32_t var95;
  uint32_t var96;
  uint32_t var97;
  uint32_t var98;
  uint32_t var99;
  uint32_t var100;
  uint32_t var101;
  uint32_t var102;
  uint32_t var103;
  uint32_t var104;
  uint32_t var105;
  uint32_t var106;
  uint32_t var107;
  uint32_t var108;
  uint32_t var109;
  uint32_t var110;
  uint32_t var111;
  uint32_t var112;
  uint32_t var113;
  uint32_t var114;
  uint32_t var115;
  uint32_t var116;
  uint32_t var117;
  uint32_t var118;
  uint32_t var119;
  uint32_t var120;
  uint32_t var121;
  uint32_t var122;
  uint32_t var123;
  uint32_t var124;
  uint32_t var125;
  uint32_t var126;
  uint32_t var127;
  uint32_t var128;
  uint32_t var129;
  uint32_t var130;
  uint32_t var131;
  uint32_t var132;
  uint32_t var133;
  choice_t *var134;
  int32_t var135;
  int32_t var136;
  choice_t *var137;
  int32_t var138;
  int32_t var139;
  choice_t *var140;
  uint32_t *var141;
  uint32_t *var142;
  uint32_t var143;
  frame_t *var144;
  int32_t var145;
  int32_t var146;
  try_node_t *var147;
  choice_t *var148;
  uint32_t *var149;
  uint32_t *var150;
  uint32_t var151;
  frame_t *var152;
  int32_t var153;
  int32_t var154;
  try_node_t *var155;
  choice_t *var156;
  try_node_t *var157;
  definition_t *var158;
  uint32_t var159;
  definition_t *var160;
  uint32_t var161;
  uint32_t var162;
  definition_t *var163;
  definition_t *var164;
  definition_t *var165;
  definition_t *var166;
  try_node_t *var167;
  choice_t *var168;
  definition_t *var169;
  try_node_t *var170;
  choice_t *var171;
  choice_t *var172;
  int32_t var173;
  int32_t var174;
  int_info_t *var175;
  instance_t *var176;
  int_info_t *var177;
  uint32_t var178;
  int_info_t *var179;
  instance_t *var180;
  int_info_t *var181;
  frame_t *var182;
  int32_t var183;
  int32_t var184;
  frame_t *var185;
  int32_t var186;
  int32_t var187;
  int32_t var188;
  int32_t var189;
  uint32_t var190;
  uint32_t var191;
  uint32_t var192;
  int32_t var193;
  uint32_t var194;
  uint32_t var195;
  uint32_t var196;
  int32_t var197;
  uint32_t var198;
  uint32_t var199;
  uint32_t var200;
  int32_t var201;
  uint32_t var202;
  uint32_t var203;
  uint32_t var204;
  int32_t var205;
  uint32_t var206;
  uint32_t var207;
  uint32_t var208;
  int32_t var209;
  uint32_t var210;
  uint32_t var211;
  uint32_t var212;
  int32_t var213;
  uint32_t var214;
  uint32_t var215;
  uint32_t var216;
  int32_t var217;
  uint32_t var218;
  uint32_t var219;
  uint32_t var220;
  int32_t var221;
  uint32_t var222;
  uint32_t var223;
  uint32_t var224;
  int32_t var225;
  int32_t var226;
  uint32_t var227;
  uint32_t var228;
  uint32_t var229;
  int32_t var230;
  uint32_t var231;
  uint32_t var232;
  uint32_t var233;
  int32_t var234;
  uint32_t var235;
  uint32_t var236;
  uint32_t var237;
  int32_t var238;
  uint32_t var239;
  uint32_t var240;
  uint32_t var241;
  int32_t var242;
  uint32_t var243;
  uint32_t var244;
  uint32_t var245;
  int32_t var246;
  uint32_t var247;
  uint32_t var248;
  uint32_t var249;
  int32_t var250;
  uint32_t var251;
  uint32_t var252;
  uint32_t var253;
  int32_t var254;
  uint32_t var255;
  uint32_t var256;
  uint32_t var257;
  int32_t var258;
  uint32_t var259;
  uint32_t var260;
  uint32_t var261;
  uint32_t var262;
  uint32_t var263;
  uint32_t var264;
  uint32_t var265;
  uint32_t var266;
  frame_t *var267;
  uint32_t var268;
  frame_t *var269;
  uint32_t var270;
  uint32_t var271;
  uint32_t var272;
  uint32_t var273;
  uint32_t var274;
  uint32_t var275;
  uint32_t var276;
  uint32_t var277;
  uint32_t var278;
  uint32_t var279;
  uint32_t var280;
  uint32_t var281;
  uint32_t var282;
  uint32_t var283;
  uint32_t var284;
  uint32_t var285;
  uint32_t var286;
  frame_t *var287;
  definition_t *var288;
  frame_t *var289;
  frame_t *var290;
  uint32_t var291;
  uint32_t var292;
  uint32_t var293;
  int32_t var294;
  uint32_t var295;
  uint32_t var296;
  uint32_t var297;
  frame_t *var298;
  uint32_t var299;
  uint32_t var300;
  uint32_t var301;
  uint32_t var302;
  uint32_t var303;
  uint32_t *var304;
  int32_t var305;
  uint32_t var306;
  frame_t *var307;
  int32_t var308;
  uint32_t var309;
  int32_t var310;
  int32_t var311;
  uint32_t var312;
  uint32_t var313;
  int32_t var314;
  uint32_t var315;
  uint32_t var316;
  int32_t var317;
  int32_t var318;
  uint32_t var319;
  uint32_t var320;
  uint32_t var321;
  int32_t var322;
  uint32_t var323;
  uint32_t var324;
  frame_t *var325;
  uint32_t var326;
  uint32_t var327;
  uint32_t var328;
  uint32_t var329;
  uint32_t var330;
  uint32_t var331;
  uint32_t var332;
  uint32_t var333;
  uint32_t var334;
  uint32_t var335;
  uint32_t var336;
  uint32_t var337;
  uint32_t var338;
  frame_t *var339;
  uint32_t var340;
  int32_t var341;
  frame_t *var342;
  uint32_t var343;
  uint32_t var344;
  frame_t *var345;
  uint32_t var346;
  uint32_t var347;
  frame_t *var348;
  frame_t *var349;
  uint32_t var350;
  uint32_t var351;
  uint32_t var352;
  uint32_t var353;
  frame_t *var354;
  frame_t *var355;
  uint32_t var356;
  uint32_t var357;
  uint32_t var358;
  uint32_t var359;
  uint32_t var360;
  uint32_t var361;
  int32_t var362;
  uint32_t var363;
  uint32_t var364;
  uint32_t var365;
  uint32_t var366;
  uint32_t var367;
  uint32_t var368;
  uint32_t var369;
  uint32_t var370;
  uint32_t var371;
  uint32_t var372;
  uint32_t var373;
  uint32_t var374;
  uint32_t var375;
  uint32_t var376;
  uint32_t var377;
  uint32_t var378;
  uint32_t var379;
  uint32_t var380;
  uint32_t var381;
  int32_t var382;
  uint32_t var383;
  uint32_t var384;
  int32_t var385;
  uint32_t var386;
  uint32_t var387;
  uint32_t var388;
  uint32_t var389;
  frame_t *var390;
  frame_t *var391;
  uint32_t var392;
  uint32_t var393;
  uint32_t var394;
  uint32_t var395;
  uint32_t var396;
  uint32_t var397;
  uint32_t var398;
  uint32_t var399;
  uint32_t var400;
  uint32_t var401;
  uint32_t var402;
  uint32_t var403;
  uint32_t var404;
  uint32_t var405;
  uint32_t var406;
  uint32_t var407;
  uint32_t var408;
  uint32_t var409;
  uint32_t var410;
  uint32_t var411;
  uint32_t var412;
  uint32_t var413;
  uint32_t var414;
  uint32_t var415;
  uint32_t var416;
  uint32_t var417;
  int32_t var418;
  uint32_t var419;
  uint32_t var420;
  int32_t var421;
  uint32_t var422;
  uint32_t var423;
  uint32_t var424;
  uint32_t var425;
  uint32_t var426;
  uint32_t var427;
  uint32_t var428;
  uint32_t var429;
  uint32_t var430;
  uint32_t var431;
  uint32_t var432;
  uint32_t var433;
  uint32_t var434;
  uint32_t var435;
  uint32_t var436;
  uint32_t var437;
  uint32_t var438;
  uint32_t var439;
  uint32_t var440;
  uint32_t var441;
  uint32_t var442;
  uint32_t var443;
  uint32_t var444;
  uint32_t var445;
  uint32_t var446;
  uint32_t var447;
  uint32_t var448;
  uint32_t var449;
  uint32_t var450;
  uint32_t var451;
  choice_t *var452;
  int32_t var453;
  int32_t var454;
  P = NULL;
  frame = NULL;
  pt2 = NULL;
  goto lab0;
  goto lab1352;
lab0:
  P = A0;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab1:
  INS_HOOK_R(0);
  H = G->heap_top;
  goto lab615;
lab2:
  INS_HOOK_R(1);
  H = G->heap_top;
  goto lab625;
lab3:
  INS_HOOK_R(2);
  P = Poff(2);
  goto lab4;
lab4:
  INS_HOOK_R(3);
  H = G->heap_top;
  goto lab632;
lab5:
  INS_HOOK_R(4);
  P = Poff(2);
  goto lab6;
lab6:
  INS_HOOK_R(5);
  H = G->heap_top;
  goto lab643;
lab7:
  INS_HOOK_R(6);
  P = Poff(2);
  goto lab8;
lab8:
  INS_HOOK_R(7);
  H = G->heap_top;
  goto lab647;
lab9:
  INS_HOOK_R(8);
  P = Poff(2);
  goto lab10;
lab10:
  INS_HOOK_R(9);
  H = G->heap_top;
  goto lab649;
lab11:
  INS_HOOK_R(10);
  P = Poff(2);
  goto lab12;
lab12:
  INS_HOOK_R(11);
  H = G->heap_top;
  goto lab651;
lab13:
  INS_HOOK_R(12);
  P = Poff(2);
  goto lab14;
lab14:
  INS_HOOK_R(13);
  H = G->heap_top;
  goto lab653;
lab15:
  INS_HOOK_R(14);
  P = Poff(2);
  goto lab16;
lab16:
  INS_HOOK_R(15);
  H = G->heap_top;
  goto lab655;
lab17:
  INS_HOOK_R(16);
  P = Poff(2);
  goto lab18;
lab18:
  INS_HOOK_R(17);
  H = G->heap_top;
  goto lab657;
lab19:
  INS_HOOK_R(18);
  P = Poff(2);
  goto lab20;
lab20:
  INS_HOOK_R(19);
  H = G->heap_top;
  goto lab659;
lab21:
  INS_HOOK_R(20);
  P = Poff(2);
  goto lab22;
lab22:
  INS_HOOK_R(21);
  H = G->heap_top;
  goto lab661;
lab23:
  INS_HOOK_R(22);
  P = Poff(2);
  goto lab24;
lab24:
  INS_HOOK_R(23);
  E->next_insn = G->next_insn;
  E->frame = G->frame;
  G->frame = E;
  G->next_insn = Poff(8);
  G->local_top = StackCharOffset(E, FrameSize(G->next_insn));
  if (OffStacktop(E, Stack_Warn)) goto lab25; else goto lab26;
lab25:
  SetEvent();
  goto lab26;
lab26:
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab27:
  INS_HOOK_R(24);
  P = Poff(2);
  goto lab28;
lab28:
  INS_HOOK_R(25);
  H = G->heap_top;
  goto lab667;
lab29:
  INS_HOOK_R(26);
  P = Poff(2);
  goto lab30;
lab30:
  INS_HOOK_R(27);
  H = G->heap_top;
  goto lab679;
lab31:
  INS_HOOK_R(28);
  P = Poff(2);
  goto lab32;
lab32:
  INS_HOOK_R(29);
  H = G->heap_top;
  goto lab689;
lab33:
  INS_HOOK_R(30);
  P = Poff(2);
  goto lab34;
lab34:
  INS_HOOK_R(31);
  H = G->heap_top;
  goto lab699;
lab35:
  INS_HOOK_R(32);
  P = Poff(2);
  goto lab36;
lab36:
  INS_HOOK_R(33);
  H = G->heap_top;
  goto lab709;
lab37:
  INS_HOOK_R(34);
  P = Poff(2);
  goto lab38;
lab38:
  INS_HOOK_R(35);
  H = G->heap_top;
  goto lab719;
lab39:
  INS_HOOK_R(36);
  P = Poff(2);
  goto lab40;
lab40:
  INS_HOOK_R(37);
  H = G->heap_top;
  goto lab729;
lab41:
  INS_HOOK_R(38);
  P = Poff(2);
  goto lab42;
lab42:
  INS_HOOK_R(39);
  H = G->heap_top;
  goto lab739;
lab43:
  INS_HOOK_R(40);
  P = Poff(2);
  goto lab44;
lab44:
  INS_HOOK_R(41);
  H = G->heap_top;
  goto lab749;
lab45:
  INS_HOOK_R(42);
  P = Poff(2);
  goto lab46;
lab46:
  INS_HOOK_R(43);
  G->next_insn = Poff(8);
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab47:
  INS_HOOK_R(44);
  P = Poff(2);
  goto lab48;
lab48:
  INS_HOOK_R(45);
  H = G->heap_top;
  goto lab761;
lab49:
  INS_HOOK_R(46);
  P = Poff(2);
  goto lab50;
lab50:
  INS_HOOK_R(47);
  H = G->heap_top;
  goto lab773;
lab51:
  INS_HOOK_R(48);
  P = Poff(2);
  goto lab52;
lab52:
  INS_HOOK_R(49);
  H = G->heap_top;
  goto lab783;
lab53:
  INS_HOOK_R(50);
  P = Poff(2);
  goto lab54;
lab54:
  INS_HOOK_R(51);
  H = G->heap_top;
  goto lab793;
lab55:
  INS_HOOK_R(52);
  P = Poff(2);
  goto lab56;
lab56:
  INS_HOOK_R(53);
  H = G->heap_top;
  goto lab803;
lab57:
  INS_HOOK_R(54);
  P = Poff(2);
  goto lab58;
lab58:
  INS_HOOK_R(55);
  H = G->heap_top;
  goto lab813;
lab59:
  INS_HOOK_R(56);
  P = Poff(2);
  goto lab60;
lab60:
  INS_HOOK_R(57);
  H = G->heap_top;
  goto lab823;
lab61:
  INS_HOOK_R(58);
  P = Poff(2);
  goto lab62;
lab62:
  INS_HOOK_R(59);
  H = G->heap_top;
  goto lab833;
lab63:
  INS_HOOK_R(60);
  P = Poff(2);
  goto lab64;
lab64:
  INS_HOOK_R(61);
  H = G->heap_top;
  goto lab843;
lab65:
  INS_HOOK_R(62);
  P = Poff(2);
  goto lab66;
lab66:
  INS_HOOK_R(63);
  G->next_insn = E->next_insn;
  G->frame = E->frame;
  goto lab68;
lab67:
  INS_HOOK_R(64);
  P = DEF_INSNP(POp(definition_t *, 4));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab68:
  INS_HOOK_R(65);
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab69:
  INS_HOOK_R(66);
  H = G->heap_top;
  goto lab856;
lab70:
  INS_HOOK_R(67);
  H = G->heap_top;
  goto lab857;
lab71:
  INS_HOOK_R(68);
  H = G->heap_top;
  goto lab858;
lab72:
  INS_HOOK_R(69);
  if (ValidLocalTop()) goto lab73; else goto lab74;
lab73:
  var2 = G->local_top;
  goto lab76;
lab74:
  var2 = w->choice->local_top;
  if (StackYounger(var2, G->frame)) goto lab76; else goto lab75;
lab75:
  var2 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab76;
lab76:
  frame = var2;
  goto lab77;
lab77:
  INS_HOOK_R(70);
  H = G->heap_top;
  goto lab869;
lab78:
  INS_HOOK_R(71);
  if (ValidLocalTop()) goto lab79; else goto lab80;
lab79:
  var3 = G->local_top;
  goto lab82;
lab80:
  var3 = w->choice->local_top;
  if (StackYounger(var3, G->frame)) goto lab82; else goto lab81;
lab81:
  var3 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab82;
lab82:
  frame = var3;
  goto lab83;
lab83:
  INS_HOOK_R(72);
  H = G->heap_top;
  goto lab875;
lab84:
  INS_HOOK_R(73);
  Xb(POp(uint16_t, 4)) = Yb(POp(uint16_t, 2));
  Xb(POp(uint16_t, 8)) = Yb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab85:
  INS_HOOK_R(74);
  Xb(POp(uint16_t, 4)) = Yb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab86:
  INS_HOOK_R(75);
  H = G->heap_top;
  goto lab878;
lab87:
  INS_HOOK_R(76);
  Xb(POp(uint16_t, 4)) = POp(uint32_t, 6);
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab88:
  INS_HOOK_R(77);
  Xb(POp(uint16_t, 2)) = POp(uint32_t, 4);
  P = Poff(8);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab89:
  INS_HOOK_R(78);
  Xb(POp(uint16_t, 2)) = atom_nil;
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab90:
  INS_HOOK_R(79);
  H = G->heap_top;
  goto lab887;
lab91:
  INS_HOOK_R(80);
  H = G->heap_top;
  goto lab888;
lab92:
  INS_HOOK_R(81);
  H = G->heap_top;
  goto lab889;
lab93:
  INS_HOOK_R(82);
  H = G->heap_top;
  goto lab890;
lab94:
  INS_HOOK_R(83);
  H = G->heap_top;
  goto lab891;
lab95:
  INS_HOOK_R(84);
  H = G->heap_top;
  goto lab892;
lab96:
  INS_HOOK_R(85);
  H = G->heap_top;
  goto lab898;
lab97:
  INS_HOOK_R(86);
  H = G->heap_top;
  goto lab904;
lab98:
  INS_HOOK_R(87);
  var4 = Xb(POp(uint16_t, 2));
  var5 = Xb(POp(uint16_t, 4));
  if (var4 == var5) goto lab100; else goto lab99;
lab99:
  if (cunify(w, var4, var5)) goto lab100; else goto lab495;
lab100:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab101:
  INS_HOOK_R(88);
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab102; else goto lab103;
lab102:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab103;
lab103:
  Yb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab104:
  INS_HOOK_R(89);
  var6 = Xb(POp(uint16_t, 2));
  var7 = Yb(POp(uint16_t, 4));
  if (var6 == var7) goto lab106; else goto lab105;
lab105:
  if (cunify(w, var6, var7)) goto lab106; else goto lab495;
lab106:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab107:
  INS_HOOK_R(90);
  P = Poff(2);
  goto lab108;
lab108:
  INS_HOOK_R(91);
  var8 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var8, goto lab109;, goto lab112;, goto lab113;, goto lab116;);
lab109:
  if (CondHVA(var8)) goto lab110; else goto lab111;
lab110:
  trail_push_check(w, var8);
  goto lab111;
lab111:
  *TagpPtr(0, var8) = POp(uint32_t, 4);
  goto lab117;
lab112:
  trail_push_check(w, var8);
  *TagpPtr(1, var8) = POp(uint32_t, 4);
  IncWakeCount();
  goto lab117;
lab113:
  if (CondSVA(var8)) goto lab114; else goto lab115;
lab114:
  trail_push_check(w, var8);
  goto lab115;
lab115:
  *TagpPtr(2, var8) = POp(uint32_t, 4);
  goto lab117;
lab116:
  if (var8 == POp(uint32_t, 4)) goto lab117; else goto lab495;
lab117:
  P = Poff(8);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab118:
  INS_HOOK_R(92);
  P = Poff(2);
  goto lab119;
lab119:
  INS_HOOK_R(93);
  var9 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var9, goto lab120;, goto lab123;, goto lab124;, goto lab127;);
lab120:
  if (CondHVA(var9)) goto lab121; else goto lab122;
lab121:
  trail_push_check(w, var9);
  goto lab122;
lab122:
  *TagpPtr(0, var9) = MakeBlob((uint32_t *)&POp(uint32_t, 4));
  goto lab129;
lab123:
  trail_push_check(w, var9);
  *TagpPtr(1, var9) = MakeBlob((uint32_t *)&POp(uint32_t, 4));
  IncWakeCount();
  goto lab129;
lab124:
  if (CondSVA(var9)) goto lab125; else goto lab126;
lab125:
  trail_push_check(w, var9);
  goto lab126;
lab126:
  *TagpPtr(2, var9) = MakeBlob((uint32_t *)&POp(uint32_t, 4));
  goto lab129;
lab127:
  if (TagH3_Is7(var9)) goto lab128; else goto lab495;
lab128:
  if (compare_blob((uint32_t *)&POp(uint32_t, 4), TagpPtr(7, var9))) goto lab129; else goto lab495;
lab129:
  P = Poff(8 + BlobFunctorSizeAligned(POp(uint32_t, 4)));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab130:
  INS_HOOK_R(94);
  P = Poff(2);
  goto lab131;
lab131:
  INS_HOOK_R(95);
  var10 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var10, goto lab132;, goto lab135;, goto lab136;, goto lab139;);
lab132:
  H = G->heap_top;
  if (CondHVA(var10)) goto lab133; else goto lab134;
lab133:
  trail_push_check(w, var10);
  goto lab134;
lab134:
  *TagpPtr(0, var10) = Tagp(7, H);
  *H = POp(uint32_t, 4);
  H = H + 1;
  goto lab142;
lab135:
  H = G->heap_top;
  trail_push_check(w, var10);
  *TagpPtr(1, var10) = Tagp(7, H);
  IncWakeCount();
  *H = POp(uint32_t, 4);
  H = H + 1;
  goto lab142;
lab136:
  H = G->heap_top;
  if (CondSVA(var10)) goto lab137; else goto lab138;
lab137:
  trail_push_check(w, var10);
  goto lab138;
lab138:
  *TagpPtr(2, var10) = Tagp(7, H);
  *H = POp(uint32_t, 4);
  H = H + 1;
  goto lab142;
lab139:
  if (TagH3_Is7(var10)) goto lab140; else goto lab495;
lab140:
  if (TaggedToHeadfunctor(var10) == POp(uint32_t, 4)) goto lab141; else goto lab495;
lab141:
  S = TaggedToArg(var10, 1);
  P = Poff(8);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab142:
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab143:
  INS_HOOK_R(96);
  var11 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var11, goto lab144;, goto lab147;, goto lab148;, goto lab151;);
lab144:
  if (CondHVA(var11)) goto lab145; else goto lab146;
lab145:
  trail_push_check(w, var11);
  goto lab146;
lab146:
  *TagpPtr(0, var11) = atom_nil;
  goto lab152;
lab147:
  trail_push_check(w, var11);
  *TagpPtr(1, var11) = atom_nil;
  IncWakeCount();
  goto lab152;
lab148:
  if (CondSVA(var11)) goto lab149; else goto lab150;
lab149:
  trail_push_check(w, var11);
  goto lab150;
lab150:
  *TagpPtr(2, var11) = atom_nil;
  goto lab152;
lab151:
  if (var11 == atom_nil) goto lab152; else goto lab495;
lab152:
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab153:
  INS_HOOK_R(97);
  var12 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var12, goto lab154;, goto lab157;, goto lab158;, goto lab161;);
lab154:
  H = G->heap_top;
  if (CondHVA(var12)) goto lab155; else goto lab156;
lab155:
  trail_push_check(w, var12);
  goto lab156;
lab156:
  *TagpPtr(0, var12) = Tagp(6, H);
  goto lab163;
lab157:
  H = G->heap_top;
  trail_push_check(w, var12);
  *TagpPtr(1, var12) = Tagp(6, H);
  IncWakeCount();
  goto lab163;
lab158:
  H = G->heap_top;
  if (CondSVA(var12)) goto lab159; else goto lab160;
lab159:
  trail_push_check(w, var12);
  goto lab160;
lab160:
  *TagpPtr(2, var12) = Tagp(6, H);
  goto lab163;
lab161:
  if (TagH3_Is6(var12)) goto lab162; else goto lab495;
lab162:
  S = TagpPtr(6, var12);
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab163:
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab164:
  INS_HOOK_R(98);
  P = Poff(2);
  goto lab165;
lab165:
  INS_HOOK_R(99);
  var13 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var13, goto lab166;, goto lab169;, goto lab170;, goto lab173;);
lab166:
  if (CondHVA(var13)) goto lab167; else goto lab168;
lab167:
  trail_push_check(w, var13);
  goto lab168;
lab168:
  *TagpPtr(0, var13) = POp(uint32_t, 4);
  goto lab506;
lab169:
  trail_push_check(w, var13);
  *TagpPtr(1, var13) = POp(uint32_t, 4);
  IncWakeCount();
  goto lab506;
lab170:
  if (CondSVA(var13)) goto lab171; else goto lab172;
lab171:
  trail_push_check(w, var13);
  goto lab172;
lab172:
  *TagpPtr(2, var13) = POp(uint32_t, 4);
  goto lab506;
lab173:
  if (var13 == POp(uint32_t, 4)) goto lab506; else goto lab495;
lab174:
  INS_HOOK_R(100);
  var14 = Xb(POp(uint16_t, 2));
  DerefSw_HVA_CVA_SVA_Other(var14, goto lab175;, goto lab178;, goto lab179;, goto lab182;);
lab175:
  if (CondHVA(var14)) goto lab176; else goto lab177;
lab176:
  trail_push_check(w, var14);
  goto lab177;
lab177:
  *TagpPtr(0, var14) = atom_nil;
  goto lab506;
lab178:
  trail_push_check(w, var14);
  *TagpPtr(1, var14) = atom_nil;
  IncWakeCount();
  goto lab506;
lab179:
  if (CondSVA(var14)) goto lab180; else goto lab181;
lab180:
  trail_push_check(w, var14);
  goto lab181;
lab181:
  *TagpPtr(2, var14) = atom_nil;
  goto lab506;
lab182:
  if (var14 == atom_nil) goto lab506; else goto lab495;
lab183:
  INS_HOOK_R(101);
  G->local_top = NULL;
  w->previous_choice = ChoiceFromTagged(Xb(POp(uint16_t, 2)));
  var15 = w->previous_choice;
  G->next_alt = var15->next_alt;
  w->global_uncond = Tagp(0, var15->heap_top);
  w->local_uncond = Tagp(2, var15->local_top);
  w->choice = var15;
  DEBUG_CUT(var15);
  ConcChptCleanUp(TopConcChptFun(), var15);
  SetDeep();
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab184:
  INS_HOOK_R(102);
  G->local_top = NULL;
  var16 = w->previous_choice;
  G->next_alt = var16->next_alt;
  w->global_uncond = Tagp(0, var16->heap_top);
  w->local_uncond = Tagp(2, var16->local_top);
  w->choice = var16;
  DEBUG_CUT(var16);
  ConcChptCleanUp(TopConcChptFun(), var16);
  SetDeep();
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab185:
  INS_HOOK_R(103);
  G->local_top = NULL;
  var17 = w->previous_choice;
  G->next_alt = var17->next_alt;
  w->global_uncond = Tagp(0, var17->heap_top);
  w->local_uncond = Tagp(2, var17->local_top);
  w->choice = var17;
  DEBUG_CUT(var17);
  ConcChptCleanUp(TopConcChptFun(), var17);
  SetDeep();
  goto lab514;
lab186:
  INS_HOOK_R(104);
  G->local_top = E;
  w->previous_choice = ChoiceFromTagged(Xb(POp(uint16_t, 2)));
  var18 = w->previous_choice;
  G->next_alt = var18->next_alt;
  w->global_uncond = Tagp(0, var18->heap_top);
  w->local_uncond = Tagp(2, var18->local_top);
  w->choice = var18;
  DEBUG_CUT(var18);
  ConcChptCleanUp(TopConcChptFun(), var18);
  SetDeep();
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab187:
  INS_HOOK_R(105);
  G->local_top = E;
  var19 = w->previous_choice;
  G->next_alt = var19->next_alt;
  w->global_uncond = Tagp(0, var19->heap_top);
  w->local_uncond = Tagp(2, var19->local_top);
  w->choice = var19;
  DEBUG_CUT(var19);
  ConcChptCleanUp(TopConcChptFun(), var19);
  SetDeep();
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab188:
  INS_HOOK_R(106);
  w->previous_choice = ChoiceFromTagged(Xb(POp(uint16_t, 2)));
  var20 = w->previous_choice;
  G->next_alt = var20->next_alt;
  w->global_uncond = Tagp(0, var20->heap_top);
  w->local_uncond = Tagp(2, var20->local_top);
  w->choice = var20;
  DEBUG_CUT(var20);
  ConcChptCleanUp(TopConcChptFun(), var20);
  SetDeep();
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab189:
  INS_HOOK_R(107);
  var21 = w->previous_choice;
  G->next_alt = var21->next_alt;
  w->global_uncond = Tagp(0, var21->heap_top);
  w->local_uncond = Tagp(2, var21->local_top);
  w->choice = var21;
  DEBUG_CUT(var21);
  ConcChptCleanUp(TopConcChptFun(), var21);
  SetDeep();
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab190:
  INS_HOOK_R(108);
  w->previous_choice = ChoiceFromTagged(Yb(POp(uint16_t, 2)));
  var22 = w->previous_choice;
  G->next_alt = var22->next_alt;
  w->global_uncond = Tagp(0, var22->heap_top);
  w->local_uncond = Tagp(2, var22->local_top);
  w->choice = var22;
  DEBUG_CUT(var22);
  ConcChptCleanUp(TopConcChptFun(), var22);
  SetDeep();
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab191:
  INS_HOOK_R(109);
  Xb(POp(uint16_t, 2)) = ChoiceToTagged(w->previous_choice);
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab192:
  INS_HOOK_R(110);
  if (ValidLocalTop()) goto lab193; else goto lab194;
lab193:
  var23 = G->local_top;
  goto lab196;
lab194:
  var23 = w->choice->local_top;
  if (StackYounger(var23, G->frame)) goto lab196; else goto lab195;
lab195:
  var23 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab196;
lab196:
  frame = var23;
  goto lab197;
lab197:
  INS_HOOK_R(111);
  Yb(POp(uint16_t, 2)) = ChoiceToTagged(w->previous_choice);
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab198:
  INS_HOOK_R(112);
  CODE_KONTINUE(var24);
  G->next_insn = E->next_insn;
  G->frame = E->frame;
  P = DEF_INSNP(var24);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab199:
  INS_HOOK_R(113);
  goto lab1352;
lab200:
  INS_HOOK_R(114);
  if (IsDeep()) goto lab202; else goto lab201;
lab201:
  SetDeep();
  goto lab202;
lab202:
  if ((*(cbool0_t)POp(char *, 4))(w)) goto lab514; else goto lab495;
lab203:
  INS_HOOK_R(115);
  P = CINSNP__LOOP((*(cinsnp0_t)POp(char *, 4))(w));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab204:
  INS_HOOK_R(116);
  Xb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  Xb(POp(uint16_t, 8)) = Xb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab205:
  INS_HOOK_R(117);
  Xb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab206:
  INS_HOOK_R(118);
  if (ValidLocalTop()) goto lab207; else goto lab208;
lab207:
  var25 = G->local_top;
  goto lab210;
lab208:
  var25 = w->choice->local_top;
  if (StackYounger(var25, G->frame)) goto lab210; else goto lab209;
lab209:
  var25 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab210;
lab210:
  frame = var25;
  goto lab211;
lab211:
  INS_HOOK_R(119);
  Yb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab212:
  INS_HOOK_R(120);
  if (ValidLocalTop()) goto lab213; else goto lab214;
lab213:
  var26 = G->local_top;
  goto lab216;
lab214:
  var26 = w->choice->local_top;
  if (StackYounger(var26, G->frame)) goto lab216; else goto lab215;
lab215:
  var26 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab216;
lab216:
  frame = var26;
  goto lab217;
lab217:
  INS_HOOK_R(121);
  Yb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  Yb(POp(uint16_t, 8)) = Xb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab218:
  INS_HOOK_R(122);
  P = POp(char *, 4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab219:
  INS_HOOK_R(123);
  P = POp(char *, 2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab220:
  INS_HOOK_R(124);
  w->liveinfo = (char *)&POp(liveinfo_t, 12);
  Xb(POp(uint16_t, 4)) = (*(ctagged1_t)POp(char *, 8))(w, Xb(POp(uint16_t, 6)));
  P = Poff(18);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab221:
  INS_HOOK_R(125);
  w->liveinfo = (char *)&POp(liveinfo_t, 10);
  Xb(POp(uint16_t, 2)) = (*(ctagged1_t)POp(char *, 6))(w, Xb(POp(uint16_t, 4)));
  P = Poff(16);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab222:
  INS_HOOK_R(126);
  w->liveinfo = (char *)&POp(liveinfo_t, 14);
  Xb(POp(uint16_t, 4)) = (*(ctagged2_t)POp(char *, 10))(w, Xb(POp(uint16_t, 6)), Xb(POp(uint16_t, 8)));
  P = Poff(20);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab223:
  INS_HOOK_R(127);
  w->liveinfo = (char *)&POp(liveinfo_t, 12);
  Xb(POp(uint16_t, 2)) = (*(ctagged2_t)POp(char *, 8))(w, Xb(POp(uint16_t, 4)), Xb(POp(uint16_t, 6)));
  P = Poff(18);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab224:
  INS_HOOK_R(128);
  w->liveinfo = (char *)&POp(liveinfo_t, 12);
  Xb(POp(uint16_t, 4)) = (*(ctagged1_t)POp(char *, 8))(w, Xb(POp(uint16_t, 6)));
  if (ERRORTAG == Xb(POp(uint16_t, 4))) goto lab495; else goto lab225;
lab225:
  P = Poff(18);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab226:
  INS_HOOK_R(129);
  w->liveinfo = (char *)&POp(liveinfo_t, 10);
  Xb(POp(uint16_t, 2)) = (*(ctagged1_t)POp(char *, 6))(w, Xb(POp(uint16_t, 4)));
  if (ERRORTAG == Xb(POp(uint16_t, 2))) goto lab495; else goto lab227;
lab227:
  P = Poff(16);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab228:
  INS_HOOK_R(130);
  w->liveinfo = (char *)&POp(liveinfo_t, 14);
  Xb(POp(uint16_t, 4)) = (*(ctagged2_t)POp(char *, 10))(w, Xb(POp(uint16_t, 6)), Xb(POp(uint16_t, 8)));
  if (ERRORTAG == Xb(POp(uint16_t, 4))) goto lab495; else goto lab229;
lab229:
  P = Poff(20);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab230:
  INS_HOOK_R(131);
  w->liveinfo = (char *)&POp(liveinfo_t, 12);
  Xb(POp(uint16_t, 2)) = (*(ctagged2_t)POp(char *, 8))(w, Xb(POp(uint16_t, 4)), Xb(POp(uint16_t, 6)));
  if (ERRORTAG == Xb(POp(uint16_t, 2))) goto lab495; else goto lab231;
lab231:
  P = Poff(18);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab232:
  INS_HOOK_R(132);
  if ((*(cbool1_t)POp(char *, 6))(w, Xb(POp(uint16_t, 4)))) goto lab233; else goto lab495;
lab233:
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab234:
  INS_HOOK_R(133);
  if ((*(cbool1_t)POp(char *, 4))(w, Xb(POp(uint16_t, 2)))) goto lab235; else goto lab495;
lab235:
  P = Poff(8);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab236:
  INS_HOOK_R(134);
  if ((*(cbool2_t)POp(char *, 8))(w, Xb(POp(uint16_t, 4)), Xb(POp(uint16_t, 6)))) goto lab237; else goto lab495;
lab237:
  P = Poff(12);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab238:
  INS_HOOK_R(135);
  if ((*(cbool2_t)POp(char *, 6))(w, Xb(POp(uint16_t, 2)), Xb(POp(uint16_t, 4)))) goto lab239; else goto lab495;
lab239:
  P = Poff(10);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab240:
  INS_HOOK_R(136);
  if ((*(cbool3_t)POp(char *, 10))(w, Xb(POp(uint16_t, 4)), Xb(POp(uint16_t, 6)), Xb(POp(uint16_t, 8)))) goto lab241; else goto lab495;
lab241:
  P = Poff(14);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab242:
  INS_HOOK_R(137);
  if ((*(cbool3_t)POp(char *, 8))(w, Xb(POp(uint16_t, 2)), Xb(POp(uint16_t, 4)), Xb(POp(uint16_t, 6)))) goto lab243; else goto lab495;
lab243:
  P = Poff(12);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab244:
  INS_HOOK_R(138);
  H = G->heap_top;
  goto lab978;
lab245:
  INS_HOOK_R(139);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab246:
  INS_HOOK_R(140);
  S = HeapCharOffset(S, 4 * 4);
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab247:
  INS_HOOK_R(141);
  S = HeapCharOffset(S, 3 * 4);
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab248:
  INS_HOOK_R(142);
  S = HeapCharOffset(S, 2 * 4);
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab249:
  INS_HOOK_R(143);
  S = HeapCharOffset(S, 1 * 4);
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab250:
  INS_HOOK_R(144);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab251:
  INS_HOOK_R(145);
  goto lab252;
lab252:
  INS_HOOK_R(146);
  var27 = *S;
  S = S + 1;
  var28 = Xb(POp(uint16_t, 2));
  var29 = var27;
  if (var28 == var29) goto lab254; else goto lab253;
lab253:
  if (cunify(w, var28, var29)) goto lab254; else goto lab495;
lab254:
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab255:
  INS_HOOK_R(147);
  if (ValidLocalTop()) goto lab256; else goto lab257;
lab256:
  var30 = G->local_top;
  goto lab259;
lab257:
  var30 = w->choice->local_top;
  if (StackYounger(var30, G->frame)) goto lab259; else goto lab258;
lab258:
  var30 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab259;
lab259:
  frame = var30;
  goto lab260;
lab260:
  INS_HOOK_R(148);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab261:
  INS_HOOK_R(149);
  var31 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab262; else goto lab263;
lab262:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab263;
lab263:
  Yb(POp(uint16_t, 2)) = var31;
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab264:
  INS_HOOK_R(150);
  goto lab265;
lab265:
  INS_HOOK_R(151);
  var32 = *S;
  S = S + 1;
  var33 = Yb(POp(uint16_t, 2));
  var34 = var32;
  if (var33 == var34) goto lab267; else goto lab266;
lab266:
  if (cunify(w, var33, var34)) goto lab267; else goto lab495;
lab267:
  P = Poff(4);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab268:
  INS_HOOK_R(152);
  P = Poff(2);
  goto lab269;
lab269:
  INS_HOOK_R(153);
  var35 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var35, goto lab270;, goto lab273;, goto lab274;);
lab270:
  if (CondHVA(var35)) goto lab271; else goto lab272;
lab271:
  trail_push_check(w, var35);
  goto lab272;
lab272:
  *TagpPtr(0, var35) = POp(uint32_t, 2);
  goto lab275;
lab273:
  trail_push_check(w, var35);
  *TagpPtr(1, var35) = POp(uint32_t, 2);
  IncWakeCount();
  goto lab275;
lab274:
  if (var35 == POp(uint32_t, 2)) goto lab275; else goto lab495;
lab275:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab276:
  INS_HOOK_R(154);
  P = Poff(2);
  goto lab277;
lab277:
  INS_HOOK_R(155);
  var36 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var36, goto lab278;, goto lab281;, goto lab282;);
lab278:
  if (CondHVA(var36)) goto lab279; else goto lab280;
lab279:
  trail_push_check(w, var36);
  goto lab280;
lab280:
  *TagpPtr(0, var36) = MakeBlob((uint32_t *)&POp(uint32_t, 2));
  goto lab284;
lab281:
  trail_push_check(w, var36);
  *TagpPtr(1, var36) = MakeBlob((uint32_t *)&POp(uint32_t, 2));
  IncWakeCount();
  goto lab284;
lab282:
  if (TagH3_Is7(var36)) goto lab283; else goto lab495;
lab283:
  if (compare_blob((uint32_t *)&POp(uint32_t, 2), TagpPtr(7, var36))) goto lab284; else goto lab495;
lab284:
  P = Poff(6 + BlobFunctorSizeAligned(POp(uint32_t, 2)));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab285:
  INS_HOOK_R(156);
  P = Poff(2);
  goto lab286;
lab286:
  INS_HOOK_R(157);
  var37 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var37, goto lab287;, goto lab290;, goto lab291;);
lab287:
  H = G->heap_top;
  if (CondHVA(var37)) goto lab288; else goto lab289;
lab288:
  trail_push_check(w, var37);
  goto lab289;
lab289:
  *TagpPtr(0, var37) = Tagp(7, H);
  *H = POp(uint32_t, 2);
  H = H + 1;
  goto lab294;
lab290:
  H = G->heap_top;
  trail_push_check(w, var37);
  *TagpPtr(1, var37) = Tagp(7, H);
  IncWakeCount();
  *H = POp(uint32_t, 2);
  H = H + 1;
  goto lab294;
lab291:
  if (TagH3_Is7(var37)) goto lab292; else goto lab495;
lab292:
  if (TaggedToHeadfunctor(var37) == POp(uint32_t, 2)) goto lab293; else goto lab495;
lab293:
  S = TaggedToArg(var37, 1);
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab294:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab295:
  INS_HOOK_R(158);
  var38 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var38, goto lab296;, goto lab299;, goto lab300;);
lab296:
  if (CondHVA(var38)) goto lab297; else goto lab298;
lab297:
  trail_push_check(w, var38);
  goto lab298;
lab298:
  *TagpPtr(0, var38) = atom_nil;
  goto lab301;
lab299:
  trail_push_check(w, var38);
  *TagpPtr(1, var38) = atom_nil;
  IncWakeCount();
  goto lab301;
lab300:
  if (var38 == atom_nil) goto lab301; else goto lab495;
lab301:
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab302:
  INS_HOOK_R(159);
  var39 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var39, goto lab303;, goto lab306;, goto lab307;);
lab303:
  H = G->heap_top;
  if (CondHVA(var39)) goto lab304; else goto lab305;
lab304:
  trail_push_check(w, var39);
  goto lab305;
lab305:
  *TagpPtr(0, var39) = Tagp(6, H);
  goto lab309;
lab306:
  H = G->heap_top;
  trail_push_check(w, var39);
  *TagpPtr(1, var39) = Tagp(6, H);
  IncWakeCount();
  goto lab309;
lab307:
  if (TagH3_Is6(var39)) goto lab308; else goto lab495;
lab308:
  S = TagpPtr(6, var39);
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab309:
  P = Poff(2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab310:
  INS_HOOK_R(160);
  P = Poff(2);
  goto lab311;
lab311:
  INS_HOOK_R(161);
  var40 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var40, goto lab312;, goto lab315;, goto lab316;);
lab312:
  if (CondHVA(var40)) goto lab313; else goto lab314;
lab313:
  trail_push_check(w, var40);
  goto lab314;
lab314:
  *TagpPtr(0, var40) = POp(uint32_t, 2);
  goto lab506;
lab315:
  trail_push_check(w, var40);
  *TagpPtr(1, var40) = POp(uint32_t, 2);
  IncWakeCount();
  goto lab506;
lab316:
  if (var40 == POp(uint32_t, 2)) goto lab506; else goto lab495;
lab317:
  INS_HOOK_R(162);
  var41 = *S;
  S = S + 1;
  HeapDerefSw_HVA_CVA_Other(var41, goto lab318;, goto lab321;, goto lab322;);
lab318:
  if (CondHVA(var41)) goto lab319; else goto lab320;
lab319:
  trail_push_check(w, var41);
  goto lab320;
lab320:
  *TagpPtr(0, var41) = atom_nil;
  goto lab506;
lab321:
  trail_push_check(w, var41);
  *TagpPtr(1, var41) = atom_nil;
  IncWakeCount();
  goto lab506;
lab322:
  if (var41 == atom_nil) goto lab506; else goto lab495;
lab323:
  INS_HOOK_R(163);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab324:
  INS_HOOK_R(164);
  if (ValidLocalTop()) goto lab325; else goto lab326;
lab325:
  var42 = G->local_top;
  goto lab328;
lab326:
  var42 = w->choice->local_top;
  if (StackYounger(var42, G->frame)) goto lab328; else goto lab327;
lab327:
  var42 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab328;
lab328:
  frame = var42;
  goto lab329;
lab329:
  INS_HOOK_R(165);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  Yb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab330:
  INS_HOOK_R(166);
  goto lab331;
lab331:
  INS_HOOK_R(167);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  var43 = *S;
  S = S + 1;
  var44 = Xb(POp(uint16_t, 4));
  var45 = var43;
  if (var44 == var45) goto lab333; else goto lab332;
lab332:
  if (cunify(w, var44, var45)) goto lab333; else goto lab495;
lab333:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab334:
  INS_HOOK_R(168);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  var46 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab335; else goto lab336;
lab335:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab336;
lab336:
  Yb(POp(uint16_t, 4)) = var46;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab337:
  INS_HOOK_R(169);
  goto lab338;
lab338:
  INS_HOOK_R(170);
  S = HeapCharOffset(S, POp(uint16_t, 2) * 4);
  var47 = *S;
  S = S + 1;
  var48 = Yb(POp(uint16_t, 4));
  var49 = var47;
  if (var48 == var49) goto lab340; else goto lab339;
lab339:
  if (cunify(w, var48, var49)) goto lab340; else goto lab495;
lab340:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab341:
  INS_HOOK_R(171);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  S = HeapCharOffset(S, POp(uint16_t, 4) * 4);
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab342:
  INS_HOOK_R(172);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab343:
  INS_HOOK_R(173);
  if (ValidLocalTop()) goto lab344; else goto lab345;
lab344:
  var50 = G->local_top;
  goto lab347;
lab345:
  var50 = w->choice->local_top;
  if (StackYounger(var50, G->frame)) goto lab347; else goto lab346;
lab346:
  var50 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab347;
lab347:
  frame = var50;
  goto lab348;
lab348:
  INS_HOOK_R(174);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  Yb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab349:
  INS_HOOK_R(175);
  goto lab350;
lab350:
  INS_HOOK_R(176);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  var51 = *S;
  S = S + 1;
  var52 = Xb(POp(uint16_t, 4));
  var53 = var51;
  if (var52 == var53) goto lab352; else goto lab351;
lab351:
  if (cunify(w, var52, var53)) goto lab352; else goto lab495;
lab352:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab353:
  INS_HOOK_R(177);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  var54 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab354; else goto lab355;
lab354:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab355;
lab355:
  Yb(POp(uint16_t, 4)) = var54;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab356:
  INS_HOOK_R(178);
  goto lab357;
lab357:
  INS_HOOK_R(179);
  Xb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  var55 = *S;
  S = S + 1;
  var56 = Yb(POp(uint16_t, 4));
  var57 = var55;
  if (var56 == var57) goto lab359; else goto lab358;
lab358:
  if (cunify(w, var56, var57)) goto lab359; else goto lab495;
lab359:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab360:
  INS_HOOK_R(180);
  if (ValidLocalTop()) goto lab361; else goto lab362;
lab361:
  var58 = G->local_top;
  goto lab364;
lab362:
  var58 = w->choice->local_top;
  if (StackYounger(var58, G->frame)) goto lab364; else goto lab363;
lab363:
  var58 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab364;
lab364:
  frame = var58;
  goto lab365;
lab365:
  INS_HOOK_R(181);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  S = HeapCharOffset(S, POp(uint16_t, 4) * 4);
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab366:
  INS_HOOK_R(182);
  if (ValidLocalTop()) goto lab367; else goto lab368;
lab367:
  var59 = G->local_top;
  goto lab370;
lab368:
  var59 = w->choice->local_top;
  if (StackYounger(var59, G->frame)) goto lab370; else goto lab369;
lab369:
  var59 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab370;
lab370:
  frame = var59;
  goto lab371;
lab371:
  INS_HOOK_R(183);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab372:
  INS_HOOK_R(184);
  if (ValidLocalTop()) goto lab373; else goto lab374;
lab373:
  var60 = G->local_top;
  goto lab376;
lab374:
  var60 = w->choice->local_top;
  if (StackYounger(var60, G->frame)) goto lab376; else goto lab375;
lab375:
  var60 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab376;
lab376:
  frame = var60;
  goto lab377;
lab377:
  INS_HOOK_R(185);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  Yb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab378:
  INS_HOOK_R(186);
  goto lab379;
lab379:
  INS_HOOK_R(187);
  if (ValidLocalTop()) goto lab380; else goto lab381;
lab380:
  var61 = G->local_top;
  goto lab383;
lab381:
  var61 = w->choice->local_top;
  if (StackYounger(var61, G->frame)) goto lab383; else goto lab382;
lab382:
  var61 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab383;
lab383:
  frame = var61;
  goto lab385;
lab384:
  INS_HOOK_R(188);
  goto lab385;
lab385:
  INS_HOOK_R(189);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  var62 = *S;
  S = S + 1;
  var63 = Xb(POp(uint16_t, 4));
  var64 = var62;
  if (var63 == var64) goto lab387; else goto lab386;
lab386:
  if (cunify(w, var63, var64)) goto lab387; else goto lab495;
lab387:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab388:
  INS_HOOK_R(190);
  goto lab389;
lab389:
  INS_HOOK_R(191);
  if (ValidLocalTop()) goto lab390; else goto lab391;
lab390:
  var65 = G->local_top;
  goto lab393;
lab391:
  var65 = w->choice->local_top;
  if (StackYounger(var65, G->frame)) goto lab393; else goto lab392;
lab392:
  var65 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab393;
lab393:
  frame = var65;
  goto lab395;
lab394:
  INS_HOOK_R(192);
  goto lab395;
lab395:
  INS_HOOK_R(193);
  Yb(POp(uint16_t, 2)) = *S;
  S = S + 1;
  var66 = *S;
  S = S + 1;
  var67 = Yb(POp(uint16_t, 4));
  var68 = var66;
  if (var67 == var68) goto lab397; else goto lab396;
lab396:
  if (cunify(w, var67, var68)) goto lab397; else goto lab495;
lab397:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab398:
  INS_HOOK_R(194);
  var69 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab399; else goto lab400;
lab399:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab400;
lab400:
  Yb(POp(uint16_t, 2)) = var69;
  S = HeapCharOffset(S, POp(uint16_t, 4) * 4);
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab401:
  INS_HOOK_R(195);
  var70 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab402; else goto lab403;
lab402:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab403;
lab403:
  Yb(POp(uint16_t, 2)) = var70;
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab404:
  INS_HOOK_R(196);
  var71 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab405; else goto lab406;
lab405:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab406;
lab406:
  Yb(POp(uint16_t, 2)) = var71;
  var72 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab407; else goto lab408;
lab407:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab408;
lab408:
  Yb(POp(uint16_t, 4)) = var72;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab409:
  INS_HOOK_R(197);
  goto lab410;
lab410:
  INS_HOOK_R(198);
  var73 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab411; else goto lab412;
lab411:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab412;
lab412:
  Yb(POp(uint16_t, 2)) = var73;
  var74 = *S;
  S = S + 1;
  var75 = Xb(POp(uint16_t, 4));
  var76 = var74;
  if (var75 == var76) goto lab414; else goto lab413;
lab413:
  if (cunify(w, var75, var76)) goto lab414; else goto lab495;
lab414:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab415:
  INS_HOOK_R(199);
  goto lab416;
lab416:
  INS_HOOK_R(200);
  var77 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab417; else goto lab418;
lab417:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab418;
lab418:
  Yb(POp(uint16_t, 2)) = var77;
  var78 = *S;
  S = S + 1;
  var79 = Yb(POp(uint16_t, 4));
  var80 = var78;
  if (var79 == var80) goto lab420; else goto lab419;
lab419:
  if (cunify(w, var79, var80)) goto lab420; else goto lab495;
lab420:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab421:
  INS_HOOK_R(201);
  goto lab422;
lab422:
  INS_HOOK_R(202);
  var81 = *S;
  S = S + 1;
  S = HeapCharOffset(S, POp(uint16_t, 4) * 4);
  var82 = Xb(POp(uint16_t, 2));
  var83 = var81;
  if (var82 == var83) goto lab424; else goto lab423;
lab423:
  if (cunify(w, var82, var83)) goto lab424; else goto lab495;
lab424:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab425:
  INS_HOOK_R(203);
  goto lab426;
lab426:
  INS_HOOK_R(204);
  var84 = Xb(POp(uint16_t, 2));
  var85 = *S;
  S = S + 1;
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  var86 = var84;
  var87 = var85;
  if (var86 == var87) goto lab428; else goto lab427;
lab427:
  if (cunify(w, var86, var87)) goto lab428; else goto lab495;
lab428:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab429:
  INS_HOOK_R(205);
  goto lab430;
lab430:
  INS_HOOK_R(206);
  if (ValidLocalTop()) goto lab431; else goto lab432;
lab431:
  var88 = G->local_top;
  goto lab434;
lab432:
  var88 = w->choice->local_top;
  if (StackYounger(var88, G->frame)) goto lab434; else goto lab433;
lab433:
  var88 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab434;
lab434:
  frame = var88;
  goto lab436;
lab435:
  INS_HOOK_R(207);
  goto lab436;
lab436:
  INS_HOOK_R(208);
  var89 = *S;
  S = S + 1;
  var90 = Xb(POp(uint16_t, 2));
  var91 = var89;
  if (var90 == var91) goto lab438; else goto lab437;
lab437:
  if (cunify(w, var90, var91)) goto lab438; else goto lab495;
lab438:
  Yb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab439:
  INS_HOOK_R(209);
  goto lab440;
lab440:
  INS_HOOK_R(210);
  goto lab441;
lab441:
  INS_HOOK_R(211);
  goto lab442;
lab442:
  INS_HOOK_R(212);
  var92 = *S;
  S = S + 1;
  var93 = Xb(POp(uint16_t, 2));
  var94 = var92;
  if (var93 == var94) goto lab444; else goto lab443;
lab443:
  if (cunify(w, var93, var94)) goto lab444; else goto lab495;
lab444:
  var95 = *S;
  S = S + 1;
  var96 = Xb(POp(uint16_t, 4));
  var97 = var95;
  if (var96 == var97) goto lab446; else goto lab445;
lab445:
  if (cunify(w, var96, var97)) goto lab446; else goto lab495;
lab446:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab447:
  INS_HOOK_R(213);
  goto lab448;
lab448:
  INS_HOOK_R(214);
  var98 = *S;
  S = S + 1;
  var99 = Xb(POp(uint16_t, 2));
  var100 = var98;
  if (var99 == var100) goto lab450; else goto lab449;
lab449:
  if (cunify(w, var99, var100)) goto lab450; else goto lab495;
lab450:
  var101 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab451; else goto lab452;
lab451:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab452;
lab452:
  Yb(POp(uint16_t, 4)) = var101;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab453:
  INS_HOOK_R(215);
  goto lab454;
lab454:
  INS_HOOK_R(216);
  goto lab455;
lab455:
  INS_HOOK_R(217);
  goto lab456;
lab456:
  INS_HOOK_R(218);
  var102 = *S;
  S = S + 1;
  var103 = Xb(POp(uint16_t, 2));
  var104 = var102;
  if (var103 == var104) goto lab458; else goto lab457;
lab457:
  if (cunify(w, var103, var104)) goto lab458; else goto lab495;
lab458:
  var105 = *S;
  S = S + 1;
  var106 = Yb(POp(uint16_t, 4));
  var107 = var105;
  if (var106 == var107) goto lab460; else goto lab459;
lab459:
  if (cunify(w, var106, var107)) goto lab460; else goto lab495;
lab460:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab461:
  INS_HOOK_R(219);
  goto lab462;
lab462:
  INS_HOOK_R(220);
  var108 = *S;
  S = S + 1;
  S = HeapCharOffset(S, POp(uint16_t, 4) * 4);
  var109 = Yb(POp(uint16_t, 2));
  var110 = var108;
  if (var109 == var110) goto lab464; else goto lab463;
lab463:
  if (cunify(w, var109, var110)) goto lab464; else goto lab495;
lab464:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab465:
  INS_HOOK_R(221);
  goto lab466;
lab466:
  INS_HOOK_R(222);
  var111 = Yb(POp(uint16_t, 2));
  var112 = *S;
  S = S + 1;
  Xb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  var113 = var111;
  var114 = var112;
  if (var113 == var114) goto lab468; else goto lab467;
lab467:
  if (cunify(w, var113, var114)) goto lab468; else goto lab495;
lab468:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab469:
  INS_HOOK_R(223);
  goto lab470;
lab470:
  INS_HOOK_R(224);
  var115 = *S;
  S = S + 1;
  var116 = Yb(POp(uint16_t, 2));
  var117 = var115;
  if (var116 == var117) goto lab472; else goto lab471;
lab471:
  if (cunify(w, var116, var117)) goto lab472; else goto lab495;
lab472:
  Yb(POp(uint16_t, 4)) = *S;
  S = S + 1;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab473:
  INS_HOOK_R(225);
  goto lab474;
lab474:
  INS_HOOK_R(226);
  var118 = *S;
  S = S + 1;
  var119 = Yb(POp(uint16_t, 2));
  var120 = var118;
  if (var119 == var120) goto lab476; else goto lab475;
lab475:
  if (cunify(w, var119, var120)) goto lab476; else goto lab495;
lab476:
  var121 = *S;
  S = S + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab477; else goto lab478;
lab477:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab478;
lab478:
  Yb(POp(uint16_t, 4)) = var121;
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab479:
  INS_HOOK_R(227);
  goto lab480;
lab480:
  INS_HOOK_R(228);
  goto lab481;
lab481:
  INS_HOOK_R(229);
  goto lab482;
lab482:
  INS_HOOK_R(230);
  var122 = *S;
  S = S + 1;
  var123 = Yb(POp(uint16_t, 2));
  var124 = var122;
  if (var123 == var124) goto lab484; else goto lab483;
lab483:
  if (cunify(w, var123, var124)) goto lab484; else goto lab495;
lab484:
  var125 = *S;
  S = S + 1;
  var126 = Xb(POp(uint16_t, 4));
  var127 = var125;
  if (var126 == var127) goto lab486; else goto lab485;
lab485:
  if (cunify(w, var126, var127)) goto lab486; else goto lab495;
lab486:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab487:
  INS_HOOK_R(231);
  goto lab488;
lab488:
  INS_HOOK_R(232);
  goto lab489;
lab489:
  INS_HOOK_R(233);
  goto lab490;
lab490:
  INS_HOOK_R(234);
  var128 = *S;
  S = S + 1;
  var129 = Yb(POp(uint16_t, 2));
  var130 = var128;
  if (var129 == var130) goto lab492; else goto lab491;
lab491:
  if (cunify(w, var129, var130)) goto lab492; else goto lab495;
lab492:
  var131 = *S;
  S = S + 1;
  var132 = Yb(POp(uint16_t, 4));
  var133 = var131;
  if (var132 == var133) goto lab494; else goto lab493;
lab493:
  if (cunify(w, var132, var133)) goto lab494; else goto lab495;
lab494:
  P = Poff(6);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab495:
  INS_HOOK_R(235);
  COMPUTED_GOTO(var0[BCOp(FAIL_INSNP, uint16_t, 0)]);
lab496:
  INS_HOOK_R(235);
  COMPUTED_GOTO(var0[BCOp(FAIL_INSNP, uint16_t, 0)]);
lab497:
  INS_HOOK_R(236);
  P = Poff(2);
  goto lab498;
lab498:
  INS_HOOK_R(237);
  TEST_HEAP_OVERFLOW(G->heap_top, POp(uint32_t, 2), POp(uint16_t, 6));
  P = Poff(8);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab499:
  INS_HOOK_R(238);
  if (IsDeep()) goto lab505; else goto lab500;
lab500:
  if (IsShallowTry()) goto lab501; else goto lab504;
lab501:
  var134 = w->choice;
  var134->frame = G->frame;
  var134->next_insn = G->next_insn;
  var134->next_alt = G->next_alt;
  var135 = ChoiceArity(var134);
  var136 = 0;
  goto lab502;
lab502:
  if (var136 < var135) goto lab503; else goto lab504;
lab503:
  var134->x[var136] = G->x[var136];
  var136 = var136 + 1;
  goto lab502;
lab504:
  frame = G->local_top;
  SetDeep();
  goto lab505;
lab505:
  P = Poff(2);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab506:
  INS_HOOK_R(239);
  if (IsDeep()) goto lab512; else goto lab507;
lab507:
  if (IsShallowTry()) goto lab508; else goto lab511;
lab508:
  var137 = w->choice;
  var137->frame = G->frame;
  var137->next_insn = G->next_insn;
  var137->next_alt = G->next_alt;
  var138 = ChoiceArity(var137);
  var139 = 0;
  goto lab509;
lab509:
  if (var139 < var138) goto lab510; else goto lab511;
lab510:
  var137->x[var139] = G->x[var139];
  var139 = var139 + 1;
  goto lab509;
lab511:
  SetDeep();
  goto lab512;
lab512:
  G->local_top = NULL;
  frame = G->frame;
  P = G->next_insn;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab513:
  INS_HOOK_R(240);
  G->next_insn = E->next_insn;
  G->frame = E->frame;
  G->local_top = NULL;
  frame = G->frame;
  P = G->next_insn;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab514:
  INS_HOOK_R(241);
  G->local_top = NULL;
  frame = G->frame;
  P = G->next_insn;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab515:
  INS_HOOK_R(242);
  FAIL_HOOK();
  var140 = w->choice;
  ResetWakeCount();
  var141 = G->trail_top;
  var142 = var140->trail_top;
  if (TrailYounger(var141, var142)) goto lab516; else goto lab526;
lab516:
  TrailDec(var141);
  var143 = *var141;
  if (IsVar(var143)) goto lab524; else goto lab517;
lab517:
  G->trail_top = var141;
  X(0) = var143;
  G->frame = var140->frame;
  G->next_insn = var140->next_insn;
  G->next_alt = var140->next_alt;
  w->choice = var140;
  if (ValidLocalTop()) goto lab518; else goto lab519;
lab518:
  var144 = G->local_top;
  goto lab521;
lab519:
  var144 = w->choice->local_top;
  if (StackYounger(var144, G->frame)) goto lab521; else goto lab520;
lab520:
  var144 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab521;
lab521:
  var144->next_insn = G->next_insn;
  var144->frame = G->frame;
  G->frame = var144;
  G->next_insn = failcode;
  G->local_top = StackCharOffset(var144, FrameSize(G->next_insn));
  if (OffStacktop(var144, Stack_Warn)) goto lab522; else goto lab523;
lab522:
  SetEvent();
  goto lab523;
lab523:
  frame = var144;
  P = CINSNP__LOOP((*(cinsnp0_t)code_call1)(w));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab524:
  *TaggedToPointer(var143) = var143;
  if (TrailYounger(var141, var142)) goto lab516; else goto lab525;
lab525:
  G->trail_top = var141;
  goto lab526;
lab526:
  G->heap_top = var140->heap_top;
  if (IsDeep()) goto lab527; else goto lab530;
lab527:
  DEBUG_DEEP_BACKTRACKING();
  var145 = ChoiceArity(var140);
  w->previous_choice = ChoiceCont0(var140, var145);
  SetShallowRetry();
  G->frame = var140->frame;
  G->next_insn = var140->next_insn;
  G->next_alt = var140->next_alt;
  G->local_top = var140->local_top;
  var146 = 0;
  goto lab528;
lab528:
  if (var146 < var145) goto lab529; else goto lab530;
lab529:
  G->x[var146] = var140->x[var146];
  var146 = var146 + 1;
  goto lab528;
lab530:
  var147 = G->next_alt;
  w->choice->next_alt = var147->next;
  G->next_alt = var147->next;
  P = var147->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab531:
  INS_HOOK_R(243);
  FAIL_HOOK();
  var148 = w->choice;
  ResetWakeCount();
  var149 = G->trail_top;
  var150 = var148->trail_top;
  if (TrailYounger(var149, var150)) goto lab532; else goto lab542;
lab532:
  TrailDec(var149);
  var151 = *var149;
  if (IsVar(var151)) goto lab540; else goto lab533;
lab533:
  G->trail_top = var149;
  X(0) = var151;
  G->frame = var148->frame;
  G->next_insn = var148->next_insn;
  G->next_alt = var148->next_alt;
  w->choice = var148;
  if (ValidLocalTop()) goto lab534; else goto lab535;
lab534:
  var152 = G->local_top;
  goto lab537;
lab535:
  var152 = w->choice->local_top;
  if (StackYounger(var152, G->frame)) goto lab537; else goto lab536;
lab536:
  var152 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab537;
lab537:
  var152->next_insn = G->next_insn;
  var152->frame = G->frame;
  G->frame = var152;
  G->next_insn = failcode;
  G->local_top = StackCharOffset(var152, FrameSize(G->next_insn));
  if (OffStacktop(var152, Stack_Warn)) goto lab538; else goto lab539;
lab538:
  SetEvent();
  goto lab539;
lab539:
  frame = var152;
  P = CINSNP__LOOP((*(cinsnp0_t)code_call1)(w));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab540:
  *TaggedToPointer(var151) = var151;
  if (TrailYounger(var149, var150)) goto lab532; else goto lab541;
lab541:
  G->trail_top = var149;
  goto lab542;
lab542:
  G->heap_top = var148->heap_top;
  if (IsDeep()) goto lab543; else goto lab546;
lab543:
  DEBUG_DEEP_BACKTRACKING();
  var153 = ChoiceArity(var148);
  w->previous_choice = ChoiceCont0(var148, var153);
  SetShallowRetry();
  G->frame = var148->frame;
  G->next_insn = var148->next_insn;
  G->next_alt = var148->next_alt;
  G->local_top = var148->local_top;
  var154 = 0;
  goto lab544;
lab544:
  if (var154 < var153) goto lab545; else goto lab546;
lab545:
  G->x[var154] = var148->x[var154];
  var154 = var154 + 1;
  goto lab544;
lab546:
  var155 = G->next_alt;
  SetDeep();
  var156 = w->previous_choice;
  G->next_alt = var156->next_alt;
  w->global_uncond = Tagp(0, var156->heap_top);
  w->local_uncond = Tagp(2, var156->local_top);
  w->choice = var156;
  P = var155->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab547:
  INS_HOOK_R(244);
  var157 = G->next_alt;
  P = CINSNP__LOOP((*(cinsnp0_t)var157->code)(w));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab548:
  INS_HOOK_R(245);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab549; else goto lab552;
lab549:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab550;
lab550:
  var158 = handle_event(w, PDEF);
  if (var158 == PDEF) goto lab552; else goto lab551;
lab551:
  P = DEF_INSNP(var158);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab552:
  PRED_HOOK("U", PDEF);
  EMUL_TO_TERM(PDEF, var159);
  X(0) = var159;
  P = DEF_INSNP(address_undefined_goal);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab553:
  INS_HOOK_R(246);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab554; else goto lab557;
lab554:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab555;
lab555:
  var160 = handle_event(w, PDEF);
  if (var160 == PDEF) goto lab557; else goto lab556;
lab556:
  P = DEF_INSNP(var160);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab557:
  PRED_HOOK("I", PDEF);
  EMUL_TO_TERM(PDEF, var161);
  X(0) = var161;
  var162 = Tagp(0, G->heap_top);
  X(1) = var162;
  *G->heap_top = var162;
  G->heap_top = G->heap_top + 1;
  X(3) = MakeSmall(4);
  P = CINSNP__LOOP(current_instance(w, PDEF->code.intinfo, NO_BLOCK));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab558:
  INS_HOOK_R(247);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab559; else goto lab562;
lab559:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab560;
lab560:
  var163 = handle_event(w, PDEF);
  if (var163 == PDEF) goto lab562; else goto lab561;
lab561:
  P = DEF_INSNP(var163);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab562:
  PRED_HOOK("C", PDEF);
  if ((*(cbool0_t)PDEF->code.proc)(w)) goto lab514; else goto lab495;
lab563:
  INS_HOOK_R(248);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab564; else goto lab567;
lab564:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab565;
lab565:
  var164 = handle_event(w, PDEF);
  if (var164 == PDEF) goto lab567; else goto lab566;
lab566:
  P = DEF_INSNP(var164);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab567:
  PRED_HOOK("C", PDEF);
  P = CINSNP__LOOP((*(cinsnp0_t)PDEF->code.proc)(w));
  frame = G->frame;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab568:
  INS_HOOK_R(249);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab569; else goto lab572;
lab569:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab570;
lab570:
  var165 = handle_event(w, PDEF);
  if (var165 == PDEF) goto lab572; else goto lab571;
lab571:
  P = DEF_INSNP(var165);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab572:
  PRED_HOOK("C", PDEF);
  (*(cvoid0_t)PDEF->code.proc)(w);
  goto lab514;
lab573:
  INS_HOOK_R(250);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab574; else goto lab577;
lab574:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab575;
lab575:
  var166 = handle_event(w, PDEF);
  if (var166 == PDEF) goto lab577; else goto lab576;
lab576:
  P = DEF_INSNP(var166);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab577:
  PRED_HOOK("E", PDEF);
  INCORE_INDEX_ALT(X(0), var167);
  w->previous_choice = w->choice;
  if (var167->next == NULL) goto lab583; else goto lab578;
lab578:
  if (ValidLocalTop()) goto lab579; else goto lab580;
lab579:
  G->local_top = G->local_top;
  goto lab582;
lab580:
  G->local_top = w->choice->local_top;
  if (StackYounger(G->local_top, G->frame)) goto lab582; else goto lab581;
lab581:
  G->local_top = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab582;
lab582:
  G->next_alt = var167->next;
  var168 = ChoiceNext0(w->choice, var167->next->arity);
  var168->flags = 0;
  var168->trail_top = G->trail_top;
  var168->local_top = G->local_top;
  var168->heap_top = G->heap_top;
  SetShallowTry();
  w->global_uncond = Tagp(0, var168->heap_top);
  w->local_uncond = Tagp(2, var168->local_top);
  w->choice = var168;
  TEST_CHOICE_OVERFLOW(var168, CHOICEPAD);
  P = var167->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab583:
  SetDeep();
  P = var167->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab584:
  INS_HOOK_R(251);
  if (TestEventOrHeapWarnOverflow(G->heap_top)) goto lab585; else goto lab588;
lab585:
  if (Stop_This_Goal(w)) goto lab1352; else goto lab586;
lab586:
  var169 = handle_event(w, PDEF);
  if (var169 == PDEF) goto lab588; else goto lab587;
lab587:
  P = DEF_INSNP(var169);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab588:
  PRED_HOOK("E", PDEF);
  var170 = PDEF->code.incoreinfo->varcase;
  w->previous_choice = w->choice;
  if (var170->next == NULL) goto lab594; else goto lab589;
lab589:
  if (ValidLocalTop()) goto lab590; else goto lab591;
lab590:
  G->local_top = G->local_top;
  goto lab593;
lab591:
  G->local_top = w->choice->local_top;
  if (StackYounger(G->local_top, G->frame)) goto lab593; else goto lab592;
lab592:
  G->local_top = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab593;
lab593:
  G->next_alt = var170->next;
  var171 = ChoiceNext0(w->choice, var170->next->arity);
  var171->flags = 0;
  var171->trail_top = G->trail_top;
  var171->local_top = G->local_top;
  var171->heap_top = G->heap_top;
  SetShallowTry();
  w->global_uncond = Tagp(0, var171->heap_top);
  w->local_uncond = Tagp(2, var171->local_top);
  w->choice = var171;
  TEST_CHOICE_OVERFLOW(var171, CHOICEPAD);
  P = var170->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab594:
  SetDeep();
  P = var170->code;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab595:
  INS_HOOK_R(252);
  if (IsDeep()) goto lab603; else goto lab596;
lab596:
  if (IsShallowTry()) goto lab597; else goto lab602;
lab597:
  def_clock = use_clock + 1;
  if (def_clock == 65535) goto lab598; else goto lab599;
lab598:
  clock_overflow(w);
  goto lab599;
lab599:
  var172 = w->choice;
  var172->frame = G->frame;
  var172->next_insn = G->next_insn;
  var172->next_alt = G->next_alt;
  var173 = ChoiceArity(var172);
  var174 = 0;
  goto lab600;
lab600:
  if (var174 < var173) goto lab601; else goto lab602;
lab601:
  var172->x[var174] = G->x[var174];
  var174 = var174 + 1;
  goto lab600;
lab602:
  SetDeep();
  goto lab603;
lab603:
  if (X(3) == MakeSmall(2)) goto lab604; else goto lab605;
lab604:
  var175 = TaggedToRoot(X(RootArg));
  prolog_unlock_predicate(w, var175);
  goto lab614;
lab605:
  if (X(3) == MakeSmall(0)) goto lab606; else goto lab607;
lab606:
  var176 = w->ins;
  var177 = TaggedToRoot(X(RootArg));
  prolog_erase_ptr(w, var176);
  prolog_unlock_predicate(w, var177);
  goto lab614;
lab607:
  if (X(3) == MakeSmall(3)) goto lab614; else goto lab608;
lab608:
  if (X(3) == MakeSmall(4)) goto lab609; else goto lab611;
lab609:
  var179 = TaggedToRoot(X(RootArg));
  prolog_unlock_predicate(w, var179);
  DEREF(var178, X(1));
  if (var178 == atom_true) goto lab614; else goto lab610;
lab610:
  X(0) = var178;
  X(1) = ChoiceToTagged(w->previous_choice);
  X(2) = atom_dynamic;
  P = DEF_INSNP(address_metacall);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab611:
  if (IsVar(X(3))) goto lab612; else goto lab495;
lab612:
  var180 = w->ins;
  var181 = TaggedToRoot(X(RootArg));
  if (instance_to_ref(w, var180, X(3))) goto lab613; else goto lab495;
lab613:
  prolog_unlock_predicate(w, var181);
  goto lab614;
lab614:
  G->local_top = NULL;
  frame = G->frame;
  P = G->next_insn;
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab615:
  INS_HOOK_W(0);
  if (ValidLocalTop()) goto lab616; else goto lab617;
lab616:
  var182 = G->local_top;
  goto lab619;
lab617:
  var182 = w->choice->local_top;
  if (StackYounger(var182, G->frame)) goto lab619; else goto lab618;
lab618:
  var182 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab619;
lab619:
  frame = var182;
  var183 = POp(uint16_t, 2) - 4;
  goto lab620;
lab620:
  if (var183 >= FrameSize0(0)) goto lab621; else goto lab622;
lab621:
  Yb(var183) = Tagp(2, &Yb(var183));
  var183 = var183 - 4;
  goto lab620;
lab622:
  E->next_insn = G->next_insn;
  E->frame = G->frame;
  G->frame = E;
  G->next_insn = Poff(4);
  G->local_top = StackCharOffset(E, FrameSize(G->next_insn));
  if (OffStacktop(E, Stack_Warn)) goto lab623; else goto lab624;
lab623:
  SetEvent();
  goto lab624;
lab624:
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab625:
  INS_HOOK_W(1);
  var184 = POp(uint16_t, 2);
  P = Poff(2);
  goto lab626;
lab626:
  if (var184 > 0) goto lab627; else goto lab628;
lab627:
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  var184 = var184 - 1;
  goto lab626;
lab628:
  E->next_insn = G->next_insn;
  E->frame = G->frame;
  G->frame = E;
  G->next_insn = Poff(4);
  G->local_top = StackCharOffset(E, FrameSize(G->next_insn));
  if (OffStacktop(E, Stack_Warn)) goto lab629; else goto lab630;
lab629:
  SetEvent();
  goto lab630;
lab630:
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab631:
  INS_HOOK_W(2);
  P = Poff(2);
  goto lab632;
lab632:
  INS_HOOK_W(3);
  if (ValidLocalTop()) goto lab633; else goto lab634;
lab633:
  var185 = G->local_top;
  goto lab636;
lab634:
  var185 = w->choice->local_top;
  if (StackYounger(var185, G->frame)) goto lab636; else goto lab635;
lab635:
  var185 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab636;
lab636:
  frame = var185;
  var186 = POp(uint16_t, 6) - 4;
  goto lab637;
lab637:
  if (var186 >= FrameSize0(0)) goto lab638; else goto lab639;
lab638:
  Yb(var186) = Tagp(2, &Yb(var186));
  var186 = var186 - 4;
  goto lab637;
lab639:
  G->heap_top = H;
  E->next_insn = G->next_insn;
  E->frame = G->frame;
  G->frame = E;
  G->next_insn = Poff(8);
  G->local_top = StackCharOffset(E, FrameSize(G->next_insn));
  if (OffStacktop(E, Stack_Warn)) goto lab640; else goto lab641;
lab640:
  SetEvent();
  goto lab641;
lab641:
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab642:
  INS_HOOK_W(4);
  P = Poff(2);
  goto lab643;
lab643:
  INS_HOOK_W(5);
  var187 = POp(uint16_t, 2);
  P = Poff(2);
  goto lab644;
lab644:
  if (var187 > 8) goto lab645; else goto lab647;
lab645:
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  var187 = var187 - 1;
  goto lab644;
lab646:
  INS_HOOK_W(6);
  P = Poff(2);
  goto lab647;
lab647:
  INS_HOOK_W(7);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab649;
lab648:
  INS_HOOK_W(8);
  P = Poff(2);
  goto lab649;
lab649:
  INS_HOOK_W(9);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab651;
lab650:
  INS_HOOK_W(10);
  P = Poff(2);
  goto lab651;
lab651:
  INS_HOOK_W(11);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab653;
lab652:
  INS_HOOK_W(12);
  P = Poff(2);
  goto lab653;
lab653:
  INS_HOOK_W(13);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab655;
lab654:
  INS_HOOK_W(14);
  P = Poff(2);
  goto lab655;
lab655:
  INS_HOOK_W(15);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab657;
lab656:
  INS_HOOK_W(16);
  P = Poff(2);
  goto lab657;
lab657:
  INS_HOOK_W(17);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab659;
lab658:
  INS_HOOK_W(18);
  P = Poff(2);
  goto lab659;
lab659:
  INS_HOOK_W(19);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab661;
lab660:
  INS_HOOK_W(20);
  P = Poff(2);
  goto lab661;
lab661:
  INS_HOOK_W(21);
  Yb(POp(uint16_t, 2)) = Tagp(2, &Yb(POp(uint16_t, 2)));
  P = Poff(2);
  goto lab663;
lab662:
  INS_HOOK_W(22);
  P = Poff(2);
  goto lab663;
lab663:
  INS_HOOK_W(23);
  G->heap_top = H;
  E->next_insn = G->next_insn;
  E->frame = G->frame;
  G->frame = E;
  G->next_insn = Poff(8);
  G->local_top = StackCharOffset(E, FrameSize(G->next_insn));
  if (OffStacktop(E, Stack_Warn)) goto lab664; else goto lab665;
lab664:
  SetEvent();
  goto lab665;
lab665:
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab666:
  INS_HOOK_W(24);
  P = Poff(2);
  goto lab667;
lab667:
  INS_HOOK_W(25);
  var188 = POp(uint16_t, 2);
  P = Poff(2);
  goto lab668;
lab668:
  if (var188 > 8) goto lab669; else goto lab679;
lab669:
  var189 = POp(uint16_t, 2);
  if ((var189 & 1) != 0) goto lab670; else goto lab676;
lab670:
  var190 = Yb(var189 + 1);
  DerefUpToSVA_Sw_SVA_Other(var190, goto lab671;, goto lab675;);
lab671:
  if (UnsafeVar(E, var190)) goto lab672; else goto lab675;
lab672:
  var191 = var190;
  var192 = Tagp(0, H);
  var190 = var192;
  *H = var192;
  H = H + 1;
  if (CondSVA(var191)) goto lab673; else goto lab674;
lab673:
  trail_push_check(w, var191);
  goto lab674;
lab674:
  *TagpPtr(2, var191) = var190;
  goto lab675;
lab675:
  X(var188 - 1) = var190;
  goto lab677;
lab676:
  X(var188 - 1) = Yb(var189);
  goto lab677;
lab677:
  P = Poff(2);
  var188 = var188 - 1;
  goto lab668;
lab678:
  INS_HOOK_W(26);
  P = Poff(2);
  goto lab679;
lab679:
  INS_HOOK_W(27);
  var193 = POp(uint16_t, 2);
  if ((var193 & 1) != 0) goto lab680; else goto lab686;
lab680:
  var194 = Yb(var193 + 1);
  DerefUpToSVA_Sw_SVA_Other(var194, goto lab681;, goto lab685;);
lab681:
  if (UnsafeVar(E, var194)) goto lab682; else goto lab685;
lab682:
  var195 = var194;
  var196 = Tagp(0, H);
  var194 = var196;
  *H = var196;
  H = H + 1;
  if (CondSVA(var195)) goto lab683; else goto lab684;
lab683:
  trail_push_check(w, var195);
  goto lab684;
lab684:
  *TagpPtr(2, var195) = var194;
  goto lab685;
lab685:
  X(7) = var194;
  goto lab687;
lab686:
  X(7) = Yb(var193);
  goto lab687;
lab687:
  P = Poff(2);
  goto lab689;
lab688:
  INS_HOOK_W(28);
  P = Poff(2);
  goto lab689;
lab689:
  INS_HOOK_W(29);
  var197 = POp(uint16_t, 2);
  if ((var197 & 1) != 0) goto lab690; else goto lab696;
lab690:
  var198 = Yb(var197 + 1);
  DerefUpToSVA_Sw_SVA_Other(var198, goto lab691;, goto lab695;);
lab691:
  if (UnsafeVar(E, var198)) goto lab692; else goto lab695;
lab692:
  var199 = var198;
  var200 = Tagp(0, H);
  var198 = var200;
  *H = var200;
  H = H + 1;
  if (CondSVA(var199)) goto lab693; else goto lab694;
lab693:
  trail_push_check(w, var199);
  goto lab694;
lab694:
  *TagpPtr(2, var199) = var198;
  goto lab695;
lab695:
  X(6) = var198;
  goto lab697;
lab696:
  X(6) = Yb(var197);
  goto lab697;
lab697:
  P = Poff(2);
  goto lab699;
lab698:
  INS_HOOK_W(30);
  P = Poff(2);
  goto lab699;
lab699:
  INS_HOOK_W(31);
  var201 = POp(uint16_t, 2);
  if ((var201 & 1) != 0) goto lab700; else goto lab706;
lab700:
  var202 = Yb(var201 + 1);
  DerefUpToSVA_Sw_SVA_Other(var202, goto lab701;, goto lab705;);
lab701:
  if (UnsafeVar(E, var202)) goto lab702; else goto lab705;
lab702:
  var203 = var202;
  var204 = Tagp(0, H);
  var202 = var204;
  *H = var204;
  H = H + 1;
  if (CondSVA(var203)) goto lab703; else goto lab704;
lab703:
  trail_push_check(w, var203);
  goto lab704;
lab704:
  *TagpPtr(2, var203) = var202;
  goto lab705;
lab705:
  X(5) = var202;
  goto lab707;
lab706:
  X(5) = Yb(var201);
  goto lab707;
lab707:
  P = Poff(2);
  goto lab709;
lab708:
  INS_HOOK_W(32);
  P = Poff(2);
  goto lab709;
lab709:
  INS_HOOK_W(33);
  var205 = POp(uint16_t, 2);
  if ((var205 & 1) != 0) goto lab710; else goto lab716;
lab710:
  var206 = Yb(var205 + 1);
  DerefUpToSVA_Sw_SVA_Other(var206, goto lab711;, goto lab715;);
lab711:
  if (UnsafeVar(E, var206)) goto lab712; else goto lab715;
lab712:
  var207 = var206;
  var208 = Tagp(0, H);
  var206 = var208;
  *H = var208;
  H = H + 1;
  if (CondSVA(var207)) goto lab713; else goto lab714;
lab713:
  trail_push_check(w, var207);
  goto lab714;
lab714:
  *TagpPtr(2, var207) = var206;
  goto lab715;
lab715:
  X(4) = var206;
  goto lab717;
lab716:
  X(4) = Yb(var205);
  goto lab717;
lab717:
  P = Poff(2);
  goto lab719;
lab718:
  INS_HOOK_W(34);
  P = Poff(2);
  goto lab719;
lab719:
  INS_HOOK_W(35);
  var209 = POp(uint16_t, 2);
  if ((var209 & 1) != 0) goto lab720; else goto lab726;
lab720:
  var210 = Yb(var209 + 1);
  DerefUpToSVA_Sw_SVA_Other(var210, goto lab721;, goto lab725;);
lab721:
  if (UnsafeVar(E, var210)) goto lab722; else goto lab725;
lab722:
  var211 = var210;
  var212 = Tagp(0, H);
  var210 = var212;
  *H = var212;
  H = H + 1;
  if (CondSVA(var211)) goto lab723; else goto lab724;
lab723:
  trail_push_check(w, var211);
  goto lab724;
lab724:
  *TagpPtr(2, var211) = var210;
  goto lab725;
lab725:
  X(3) = var210;
  goto lab727;
lab726:
  X(3) = Yb(var209);
  goto lab727;
lab727:
  P = Poff(2);
  goto lab729;
lab728:
  INS_HOOK_W(36);
  P = Poff(2);
  goto lab729;
lab729:
  INS_HOOK_W(37);
  var213 = POp(uint16_t, 2);
  if ((var213 & 1) != 0) goto lab730; else goto lab736;
lab730:
  var214 = Yb(var213 + 1);
  DerefUpToSVA_Sw_SVA_Other(var214, goto lab731;, goto lab735;);
lab731:
  if (UnsafeVar(E, var214)) goto lab732; else goto lab735;
lab732:
  var215 = var214;
  var216 = Tagp(0, H);
  var214 = var216;
  *H = var216;
  H = H + 1;
  if (CondSVA(var215)) goto lab733; else goto lab734;
lab733:
  trail_push_check(w, var215);
  goto lab734;
lab734:
  *TagpPtr(2, var215) = var214;
  goto lab735;
lab735:
  X(2) = var214;
  goto lab737;
lab736:
  X(2) = Yb(var213);
  goto lab737;
lab737:
  P = Poff(2);
  goto lab739;
lab738:
  INS_HOOK_W(38);
  P = Poff(2);
  goto lab739;
lab739:
  INS_HOOK_W(39);
  var217 = POp(uint16_t, 2);
  if ((var217 & 1) != 0) goto lab740; else goto lab746;
lab740:
  var218 = Yb(var217 + 1);
  DerefUpToSVA_Sw_SVA_Other(var218, goto lab741;, goto lab745;);
lab741:
  if (UnsafeVar(E, var218)) goto lab742; else goto lab745;
lab742:
  var219 = var218;
  var220 = Tagp(0, H);
  var218 = var220;
  *H = var220;
  H = H + 1;
  if (CondSVA(var219)) goto lab743; else goto lab744;
lab743:
  trail_push_check(w, var219);
  goto lab744;
lab744:
  *TagpPtr(2, var219) = var218;
  goto lab745;
lab745:
  X(1) = var218;
  goto lab747;
lab746:
  X(1) = Yb(var217);
  goto lab747;
lab747:
  P = Poff(2);
  goto lab749;
lab748:
  INS_HOOK_W(40);
  P = Poff(2);
  goto lab749;
lab749:
  INS_HOOK_W(41);
  var221 = POp(uint16_t, 2);
  if ((var221 & 1) != 0) goto lab750; else goto lab756;
lab750:
  var222 = Yb(var221 + 1);
  DerefUpToSVA_Sw_SVA_Other(var222, goto lab751;, goto lab755;);
lab751:
  if (UnsafeVar(E, var222)) goto lab752; else goto lab755;
lab752:
  var223 = var222;
  var224 = Tagp(0, H);
  var222 = var224;
  *H = var224;
  H = H + 1;
  if (CondSVA(var223)) goto lab753; else goto lab754;
lab753:
  trail_push_check(w, var223);
  goto lab754;
lab754:
  *TagpPtr(2, var223) = var222;
  goto lab755;
lab755:
  X(0) = var222;
  goto lab757;
lab756:
  X(0) = Yb(var221);
  goto lab757;
lab757:
  P = Poff(2);
  goto lab759;
lab758:
  INS_HOOK_W(42);
  P = Poff(2);
  goto lab759;
lab759:
  INS_HOOK_W(43);
  G->heap_top = H;
  G->next_insn = Poff(8);
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab760:
  INS_HOOK_W(44);
  P = Poff(2);
  goto lab761;
lab761:
  INS_HOOK_W(45);
  var225 = POp(uint16_t, 2);
  P = Poff(2);
  goto lab762;
lab762:
  if (var225 > 8) goto lab763; else goto lab773;
lab763:
  var226 = POp(uint16_t, 2);
  if ((var226 & 1) != 0) goto lab764; else goto lab770;
lab764:
  var227 = Yb(var226 + 1);
  DerefUpToSVA_Sw_SVA_Other(var227, goto lab765;, goto lab769;);
lab765:
  if (UnsafeVar(E, var227)) goto lab766; else goto lab769;
lab766:
  var228 = var227;
  var229 = Tagp(0, H);
  var227 = var229;
  *H = var229;
  H = H + 1;
  if (CondSVA(var228)) goto lab767; else goto lab768;
lab767:
  trail_push_check(w, var228);
  goto lab768;
lab768:
  *TagpPtr(2, var228) = var227;
  goto lab769;
lab769:
  X(var225 - 1) = var227;
  goto lab771;
lab770:
  X(var225 - 1) = Yb(var226);
  goto lab771;
lab771:
  P = Poff(2);
  var225 = var225 - 1;
  goto lab762;
lab772:
  INS_HOOK_W(46);
  P = Poff(2);
  goto lab773;
lab773:
  INS_HOOK_W(47);
  var230 = POp(uint16_t, 2);
  if ((var230 & 1) != 0) goto lab774; else goto lab780;
lab774:
  var231 = Yb(var230 + 1);
  DerefUpToSVA_Sw_SVA_Other(var231, goto lab775;, goto lab779;);
lab775:
  if (UnsafeVar(E, var231)) goto lab776; else goto lab779;
lab776:
  var232 = var231;
  var233 = Tagp(0, H);
  var231 = var233;
  *H = var233;
  H = H + 1;
  if (CondSVA(var232)) goto lab777; else goto lab778;
lab777:
  trail_push_check(w, var232);
  goto lab778;
lab778:
  *TagpPtr(2, var232) = var231;
  goto lab779;
lab779:
  X(7) = var231;
  goto lab781;
lab780:
  X(7) = Yb(var230);
  goto lab781;
lab781:
  P = Poff(2);
  goto lab783;
lab782:
  INS_HOOK_W(48);
  P = Poff(2);
  goto lab783;
lab783:
  INS_HOOK_W(49);
  var234 = POp(uint16_t, 2);
  if ((var234 & 1) != 0) goto lab784; else goto lab790;
lab784:
  var235 = Yb(var234 + 1);
  DerefUpToSVA_Sw_SVA_Other(var235, goto lab785;, goto lab789;);
lab785:
  if (UnsafeVar(E, var235)) goto lab786; else goto lab789;
lab786:
  var236 = var235;
  var237 = Tagp(0, H);
  var235 = var237;
  *H = var237;
  H = H + 1;
  if (CondSVA(var236)) goto lab787; else goto lab788;
lab787:
  trail_push_check(w, var236);
  goto lab788;
lab788:
  *TagpPtr(2, var236) = var235;
  goto lab789;
lab789:
  X(6) = var235;
  goto lab791;
lab790:
  X(6) = Yb(var234);
  goto lab791;
lab791:
  P = Poff(2);
  goto lab793;
lab792:
  INS_HOOK_W(50);
  P = Poff(2);
  goto lab793;
lab793:
  INS_HOOK_W(51);
  var238 = POp(uint16_t, 2);
  if ((var238 & 1) != 0) goto lab794; else goto lab800;
lab794:
  var239 = Yb(var238 + 1);
  DerefUpToSVA_Sw_SVA_Other(var239, goto lab795;, goto lab799;);
lab795:
  if (UnsafeVar(E, var239)) goto lab796; else goto lab799;
lab796:
  var240 = var239;
  var241 = Tagp(0, H);
  var239 = var241;
  *H = var241;
  H = H + 1;
  if (CondSVA(var240)) goto lab797; else goto lab798;
lab797:
  trail_push_check(w, var240);
  goto lab798;
lab798:
  *TagpPtr(2, var240) = var239;
  goto lab799;
lab799:
  X(5) = var239;
  goto lab801;
lab800:
  X(5) = Yb(var238);
  goto lab801;
lab801:
  P = Poff(2);
  goto lab803;
lab802:
  INS_HOOK_W(52);
  P = Poff(2);
  goto lab803;
lab803:
  INS_HOOK_W(53);
  var242 = POp(uint16_t, 2);
  if ((var242 & 1) != 0) goto lab804; else goto lab810;
lab804:
  var243 = Yb(var242 + 1);
  DerefUpToSVA_Sw_SVA_Other(var243, goto lab805;, goto lab809;);
lab805:
  if (UnsafeVar(E, var243)) goto lab806; else goto lab809;
lab806:
  var244 = var243;
  var245 = Tagp(0, H);
  var243 = var245;
  *H = var245;
  H = H + 1;
  if (CondSVA(var244)) goto lab807; else goto lab808;
lab807:
  trail_push_check(w, var244);
  goto lab808;
lab808:
  *TagpPtr(2, var244) = var243;
  goto lab809;
lab809:
  X(4) = var243;
  goto lab811;
lab810:
  X(4) = Yb(var242);
  goto lab811;
lab811:
  P = Poff(2);
  goto lab813;
lab812:
  INS_HOOK_W(54);
  P = Poff(2);
  goto lab813;
lab813:
  INS_HOOK_W(55);
  var246 = POp(uint16_t, 2);
  if ((var246 & 1) != 0) goto lab814; else goto lab820;
lab814:
  var247 = Yb(var246 + 1);
  DerefUpToSVA_Sw_SVA_Other(var247, goto lab815;, goto lab819;);
lab815:
  if (UnsafeVar(E, var247)) goto lab816; else goto lab819;
lab816:
  var248 = var247;
  var249 = Tagp(0, H);
  var247 = var249;
  *H = var249;
  H = H + 1;
  if (CondSVA(var248)) goto lab817; else goto lab818;
lab817:
  trail_push_check(w, var248);
  goto lab818;
lab818:
  *TagpPtr(2, var248) = var247;
  goto lab819;
lab819:
  X(3) = var247;
  goto lab821;
lab820:
  X(3) = Yb(var246);
  goto lab821;
lab821:
  P = Poff(2);
  goto lab823;
lab822:
  INS_HOOK_W(56);
  P = Poff(2);
  goto lab823;
lab823:
  INS_HOOK_W(57);
  var250 = POp(uint16_t, 2);
  if ((var250 & 1) != 0) goto lab824; else goto lab830;
lab824:
  var251 = Yb(var250 + 1);
  DerefUpToSVA_Sw_SVA_Other(var251, goto lab825;, goto lab829;);
lab825:
  if (UnsafeVar(E, var251)) goto lab826; else goto lab829;
lab826:
  var252 = var251;
  var253 = Tagp(0, H);
  var251 = var253;
  *H = var253;
  H = H + 1;
  if (CondSVA(var252)) goto lab827; else goto lab828;
lab827:
  trail_push_check(w, var252);
  goto lab828;
lab828:
  *TagpPtr(2, var252) = var251;
  goto lab829;
lab829:
  X(2) = var251;
  goto lab831;
lab830:
  X(2) = Yb(var250);
  goto lab831;
lab831:
  P = Poff(2);
  goto lab833;
lab832:
  INS_HOOK_W(58);
  P = Poff(2);
  goto lab833;
lab833:
  INS_HOOK_W(59);
  var254 = POp(uint16_t, 2);
  if ((var254 & 1) != 0) goto lab834; else goto lab840;
lab834:
  var255 = Yb(var254 + 1);
  DerefUpToSVA_Sw_SVA_Other(var255, goto lab835;, goto lab839;);
lab835:
  if (UnsafeVar(E, var255)) goto lab836; else goto lab839;
lab836:
  var256 = var255;
  var257 = Tagp(0, H);
  var255 = var257;
  *H = var257;
  H = H + 1;
  if (CondSVA(var256)) goto lab837; else goto lab838;
lab837:
  trail_push_check(w, var256);
  goto lab838;
lab838:
  *TagpPtr(2, var256) = var255;
  goto lab839;
lab839:
  X(1) = var255;
  goto lab841;
lab840:
  X(1) = Yb(var254);
  goto lab841;
lab841:
  P = Poff(2);
  goto lab843;
lab842:
  INS_HOOK_W(60);
  P = Poff(2);
  goto lab843;
lab843:
  INS_HOOK_W(61);
  var258 = POp(uint16_t, 2);
  if ((var258 & 1) != 0) goto lab844; else goto lab850;
lab844:
  var259 = Yb(var258 + 1);
  DerefUpToSVA_Sw_SVA_Other(var259, goto lab845;, goto lab849;);
lab845:
  if (UnsafeVar(E, var259)) goto lab846; else goto lab849;
lab846:
  var260 = var259;
  var261 = Tagp(0, H);
  var259 = var261;
  *H = var261;
  H = H + 1;
  if (CondSVA(var260)) goto lab847; else goto lab848;
lab847:
  trail_push_check(w, var260);
  goto lab848;
lab848:
  *TagpPtr(2, var260) = var259;
  goto lab849;
lab849:
  X(0) = var259;
  goto lab851;
lab850:
  X(0) = Yb(var258);
  goto lab851;
lab851:
  P = Poff(2);
  goto lab853;
lab852:
  INS_HOOK_W(62);
  P = Poff(2);
  goto lab853;
lab853:
  INS_HOOK_W(63);
  G->next_insn = E->next_insn;
  G->frame = E->frame;
  goto lab855;
lab854:
  INS_HOOK_W(64);
  G->heap_top = H;
  P = DEF_INSNP(POp(definition_t *, 4));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab855:
  INS_HOOK_W(65);
  G->heap_top = H;
  P = DEF_INSNP(POp(definition_t *, 2));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab856:
  INS_HOOK_W(66);
  var262 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var262;
  *H = var262;
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab857:
  INS_HOOK_W(67);
  var263 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var263;
  Xb(POp(uint16_t, 2)) = var263;
  *H = var263;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab858:
  INS_HOOK_W(68);
  var264 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var264, goto lab859;, goto lab863;);
lab859:
  if (UnsafeVar(E, var264)) goto lab860; else goto lab863;
lab860:
  var265 = var264;
  var266 = Tagp(0, H);
  var264 = var266;
  *H = var266;
  H = H + 1;
  if (CondSVA(var265)) goto lab861; else goto lab862;
lab861:
  trail_push_check(w, var265);
  goto lab862;
lab862:
  *TagpPtr(2, var265) = var264;
  goto lab863;
lab863:
  Xb(POp(uint16_t, 4)) = var264;
  Xb(POp(uint16_t, 2)) = var264;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab864:
  INS_HOOK_W(69);
  if (ValidLocalTop()) goto lab865; else goto lab866;
lab865:
  var267 = G->local_top;
  goto lab868;
lab866:
  var267 = w->choice->local_top;
  if (StackYounger(var267, G->frame)) goto lab868; else goto lab867;
lab867:
  var267 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab868;
lab868:
  frame = var267;
  goto lab869;
lab869:
  INS_HOOK_W(70);
  var268 = Tagp(2, &Yb(POp(uint16_t, 4)));
  Yb(POp(uint16_t, 4)) = var268;
  Xb(POp(uint16_t, 2)) = var268;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab870:
  INS_HOOK_W(71);
  if (ValidLocalTop()) goto lab871; else goto lab872;
lab871:
  var269 = G->local_top;
  goto lab874;
lab872:
  var269 = w->choice->local_top;
  if (StackYounger(var269, G->frame)) goto lab874; else goto lab873;
lab873:
  var269 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab874;
lab874:
  frame = var269;
  goto lab875;
lab875:
  INS_HOOK_W(72);
  var270 = Tagp(2, &Yb(POp(uint16_t, 4)));
  Yb(POp(uint16_t, 4)) = var270;
  Xb(POp(uint16_t, 2)) = var270;
  var271 = Tagp(2, &Yb(POp(uint16_t, 8)));
  Yb(POp(uint16_t, 8)) = var271;
  Xb(POp(uint16_t, 6)) = var271;
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab876:
  INS_HOOK_W(73);
  Xb(POp(uint16_t, 4)) = Yb(POp(uint16_t, 2));
  Xb(POp(uint16_t, 8)) = Yb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab877:
  INS_HOOK_W(74);
  Xb(POp(uint16_t, 4)) = Yb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab878:
  INS_HOOK_W(75);
  var272 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var272, goto lab879;, goto lab883;);
lab879:
  if (UnsafeVar(E, var272)) goto lab880; else goto lab883;
lab880:
  var273 = var272;
  var274 = Tagp(0, H);
  var272 = var274;
  *H = var274;
  H = H + 1;
  if (CondSVA(var273)) goto lab881; else goto lab882;
lab881:
  trail_push_check(w, var273);
  goto lab882;
lab882:
  *TagpPtr(2, var273) = var272;
  goto lab883;
lab883:
  Xb(POp(uint16_t, 4)) = var272;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab884:
  INS_HOOK_W(76);
  Xb(POp(uint16_t, 4)) = POp(uint32_t, 6);
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab885:
  INS_HOOK_W(77);
  Xb(POp(uint16_t, 2)) = POp(uint32_t, 4);
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab886:
  INS_HOOK_W(78);
  Xb(POp(uint16_t, 2)) = atom_nil;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab887:
  INS_HOOK_W(79);
  G->heap_top = H;
  Xb(POp(uint16_t, 4)) = MakeBlob((uint32_t *)&POp(uint32_t, 6));
  H = G->heap_top;
  P = Poff(10 + BlobFunctorSizeAligned(POp(uint32_t, 6)));
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab888:
  INS_HOOK_W(80);
  G->heap_top = H;
  Xb(POp(uint16_t, 2)) = MakeBlob((uint32_t *)&POp(uint32_t, 4));
  H = G->heap_top;
  P = Poff(8 + BlobFunctorSizeAligned(POp(uint32_t, 4)));
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab889:
  INS_HOOK_W(81);
  Xb(POp(uint16_t, 4)) = Tagp(7, H);
  *H = POp(uint32_t, 6);
  H = H + 1;
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab890:
  INS_HOOK_W(82);
  Xb(POp(uint16_t, 2)) = Tagp(7, H);
  *H = POp(uint32_t, 4);
  H = H + 1;
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab891:
  INS_HOOK_W(83);
  Xb(POp(uint16_t, 2)) = Tagp(6, H);
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab892:
  INS_HOOK_W(84);
  Xb(POp(uint16_t, 4)) = Yb(POp(uint16_t, 2));
  var275 = Yb(POp(uint16_t, 6));
  DerefUpToSVA_Sw_SVA_Other(var275, goto lab893;, goto lab897;);
lab893:
  if (UnsafeVar(E, var275)) goto lab894; else goto lab897;
lab894:
  var276 = var275;
  var277 = Tagp(0, H);
  var275 = var277;
  *H = var277;
  H = H + 1;
  if (CondSVA(var276)) goto lab895; else goto lab896;
lab895:
  trail_push_check(w, var276);
  goto lab896;
lab896:
  *TagpPtr(2, var276) = var275;
  goto lab897;
lab897:
  Xb(POp(uint16_t, 8)) = var275;
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab898:
  INS_HOOK_W(85);
  var278 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var278, goto lab899;, goto lab903;);
lab899:
  if (UnsafeVar(E, var278)) goto lab900; else goto lab903;
lab900:
  var279 = var278;
  var280 = Tagp(0, H);
  var278 = var280;
  *H = var280;
  H = H + 1;
  if (CondSVA(var279)) goto lab901; else goto lab902;
lab901:
  trail_push_check(w, var279);
  goto lab902;
lab902:
  *TagpPtr(2, var279) = var278;
  goto lab903;
lab903:
  Xb(POp(uint16_t, 4)) = var278;
  Xb(POp(uint16_t, 8)) = Yb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab904:
  INS_HOOK_W(86);
  var281 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var281, goto lab905;, goto lab909;);
lab905:
  if (UnsafeVar(E, var281)) goto lab906; else goto lab909;
lab906:
  var282 = var281;
  var283 = Tagp(0, H);
  var281 = var283;
  *H = var283;
  H = H + 1;
  if (CondSVA(var282)) goto lab907; else goto lab908;
lab907:
  trail_push_check(w, var282);
  goto lab908;
lab908:
  *TagpPtr(2, var282) = var281;
  goto lab909;
lab909:
  Xb(POp(uint16_t, 4)) = var281;
  var284 = Yb(POp(uint16_t, 6));
  DerefUpToSVA_Sw_SVA_Other(var284, goto lab910;, goto lab914;);
lab910:
  if (UnsafeVar(E, var284)) goto lab911; else goto lab914;
lab911:
  var285 = var284;
  var286 = Tagp(0, H);
  var284 = var286;
  *H = var286;
  H = H + 1;
  if (CondSVA(var285)) goto lab912; else goto lab913;
lab912:
  trail_push_check(w, var285);
  goto lab913;
lab913:
  *TagpPtr(2, var285) = var284;
  goto lab914;
lab914:
  Xb(POp(uint16_t, 8)) = var284;
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab915:
  INS_HOOK_W(87);
  G->heap_top = H;
  goto lab98;
lab916:
  INS_HOOK_W(88);
  G->heap_top = H;
  goto lab101;
lab917:
  INS_HOOK_W(89);
  G->heap_top = H;
  goto lab104;
lab918:
  INS_HOOK_W(90);
  P = Poff(2);
  goto lab919;
lab919:
  INS_HOOK_W(91);
  G->heap_top = H;
  goto lab108;
lab920:
  INS_HOOK_W(92);
  P = Poff(2);
  goto lab921;
lab921:
  INS_HOOK_W(93);
  G->heap_top = H;
  goto lab119;
lab922:
  INS_HOOK_W(94);
  P = Poff(2);
  goto lab923;
lab923:
  INS_HOOK_W(95);
  G->heap_top = H;
  goto lab131;
lab924:
  INS_HOOK_W(96);
  G->heap_top = H;
  goto lab143;
lab925:
  INS_HOOK_W(97);
  G->heap_top = H;
  goto lab153;
lab926:
  INS_HOOK_W(98);
  P = Poff(2);
  goto lab927;
lab927:
  INS_HOOK_W(99);
  G->heap_top = H;
  goto lab165;
lab928:
  INS_HOOK_W(100);
  G->heap_top = H;
  goto lab174;
lab929:
  INS_HOOK_W(101);
  G->heap_top = H;
  goto lab183;
lab930:
  INS_HOOK_W(102);
  G->heap_top = H;
  goto lab184;
lab931:
  INS_HOOK_W(103);
  G->heap_top = H;
  goto lab185;
lab932:
  INS_HOOK_W(104);
  G->heap_top = H;
  goto lab186;
lab933:
  INS_HOOK_W(105);
  G->heap_top = H;
  goto lab187;
lab934:
  INS_HOOK_W(106);
  G->heap_top = H;
  goto lab188;
lab935:
  INS_HOOK_W(107);
  G->heap_top = H;
  goto lab189;
lab936:
  INS_HOOK_W(108);
  G->heap_top = H;
  goto lab190;
lab937:
  INS_HOOK_W(109);
  Xb(POp(uint16_t, 2)) = ChoiceToTagged(w->previous_choice);
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab938:
  INS_HOOK_W(110);
  if (ValidLocalTop()) goto lab939; else goto lab940;
lab939:
  var287 = G->local_top;
  goto lab942;
lab940:
  var287 = w->choice->local_top;
  if (StackYounger(var287, G->frame)) goto lab942; else goto lab941;
lab941:
  var287 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab942;
lab942:
  frame = var287;
  goto lab943;
lab943:
  INS_HOOK_W(111);
  Yb(POp(uint16_t, 2)) = ChoiceToTagged(w->previous_choice);
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab944:
  INS_HOOK_W(112);
  G->heap_top = H;
  CODE_KONTINUE(var288);
  G->next_insn = E->next_insn;
  G->frame = E->frame;
  P = DEF_INSNP(var288);
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab945:
  INS_HOOK_W(113);
  G->heap_top = H;
  goto lab199;
lab946:
  INS_HOOK_W(114);
  G->heap_top = H;
  goto lab200;
lab947:
  INS_HOOK_W(115);
  G->heap_top = H;
  goto lab203;
lab948:
  INS_HOOK_W(116);
  Xb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  Xb(POp(uint16_t, 8)) = Xb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab949:
  INS_HOOK_W(117);
  Xb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab950:
  INS_HOOK_W(118);
  if (ValidLocalTop()) goto lab951; else goto lab952;
lab951:
  var289 = G->local_top;
  goto lab954;
lab952:
  var289 = w->choice->local_top;
  if (StackYounger(var289, G->frame)) goto lab954; else goto lab953;
lab953:
  var289 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab954;
lab954:
  frame = var289;
  goto lab955;
lab955:
  INS_HOOK_W(119);
  Yb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab956:
  INS_HOOK_W(120);
  if (ValidLocalTop()) goto lab957; else goto lab958;
lab957:
  var290 = G->local_top;
  goto lab960;
lab958:
  var290 = w->choice->local_top;
  if (StackYounger(var290, G->frame)) goto lab960; else goto lab959;
lab959:
  var290 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab960;
lab960:
  frame = var290;
  goto lab961;
lab961:
  INS_HOOK_W(121);
  Yb(POp(uint16_t, 4)) = Xb(POp(uint16_t, 2));
  Yb(POp(uint16_t, 8)) = Xb(POp(uint16_t, 6));
  P = Poff(10);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab962:
  INS_HOOK_W(122);
  P = POp(char *, 4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab963:
  INS_HOOK_W(123);
  P = POp(char *, 2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab964:
  INS_HOOK_W(124);
  G->heap_top = H;
  goto lab220;
lab965:
  INS_HOOK_W(125);
  G->heap_top = H;
  goto lab221;
lab966:
  INS_HOOK_W(126);
  G->heap_top = H;
  goto lab222;
lab967:
  INS_HOOK_W(127);
  G->heap_top = H;
  goto lab223;
lab968:
  INS_HOOK_W(128);
  G->heap_top = H;
  goto lab224;
lab969:
  INS_HOOK_W(129);
  G->heap_top = H;
  goto lab226;
lab970:
  INS_HOOK_W(130);
  G->heap_top = H;
  goto lab228;
lab971:
  INS_HOOK_W(131);
  G->heap_top = H;
  goto lab230;
lab972:
  INS_HOOK_W(132);
  G->heap_top = H;
  goto lab232;
lab973:
  INS_HOOK_W(133);
  G->heap_top = H;
  goto lab234;
lab974:
  INS_HOOK_W(134);
  G->heap_top = H;
  goto lab236;
lab975:
  INS_HOOK_W(135);
  G->heap_top = H;
  goto lab238;
lab976:
  INS_HOOK_W(136);
  G->heap_top = H;
  goto lab240;
lab977:
  INS_HOOK_W(137);
  G->heap_top = H;
  goto lab242;
lab978:
  INS_HOOK_W(138);
  var291 = Xb(POp(uint16_t, 2));
  var292 = Tagp(1, H);
  var293 = var292;
  *H = var292;
  H = H + 1;
  DerefSw_HVA_CVA_SVA_Other(var291, goto lab979;, goto lab982;, goto lab983;, goto lab986;);
lab979:
  if (CondHVA(var291)) goto lab980; else goto lab981;
lab980:
  trail_push_check(w, var291);
  goto lab981;
lab981:
  *TagpPtr(0, var291) = var293;
  Xb(POp(uint16_t, 2)) = var293;
  goto lab987;
lab982:
  trail_push_check(w, var293);
  *TagpPtr(1, var293) = var291;
  IncWakeCount();
  goto lab987;
lab983:
  if (CondSVA(var291)) goto lab984; else goto lab985;
lab984:
  trail_push_check(w, var291);
  goto lab985;
lab985:
  *TagpPtr(2, var291) = var293;
  Xb(POp(uint16_t, 2)) = var293;
  goto lab987;
lab986:
  trail_push_check(w, var293);
  *TagpPtr(1, var293) = var291;
  IncWakeCount();
  goto lab987;
lab987:
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab988:
  INS_HOOK_W(139);
  var294 = POp(uint16_t, 2);
  P = Poff(2);
  goto lab989;
lab989:
  if (var294 > 4) goto lab990; else goto lab991;
lab990:
  *H = Tagp(0, H);
  H = H + 1;
  var294 = var294 - 1;
  goto lab989;
lab991:
  INS_HOOK_W(140);
  *H = Tagp(0, H);
  H = H + 1;
  goto lab992;
lab992:
  INS_HOOK_W(141);
  *H = Tagp(0, H);
  H = H + 1;
  goto lab993;
lab993:
  INS_HOOK_W(142);
  *H = Tagp(0, H);
  H = H + 1;
  goto lab994;
lab994:
  INS_HOOK_W(143);
  *H = Tagp(0, H);
  H = H + 1;
  P = Poff(2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab995:
  INS_HOOK_W(144);
  var295 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var295;
  *H = var295;
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab996:
  INS_HOOK_W(145);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab997:
  INS_HOOK_W(146);
  var296 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var296, goto lab998;, goto lab1001;);
lab998:
  var297 = var296;
  if (CondSVA(var297)) goto lab999; else goto lab1000;
lab999:
  trail_push_check(w, var297);
  goto lab1000;
lab1000:
  *TagpPtr(2, var297) = Tagp(0, H);
  var296 = Tagp(0, H);
  goto lab1001;
lab1001:
  *H = var296;
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1002:
  INS_HOOK_W(147);
  if (ValidLocalTop()) goto lab1003; else goto lab1004;
lab1003:
  var298 = G->local_top;
  goto lab1006;
lab1004:
  var298 = w->choice->local_top;
  if (StackYounger(var298, G->frame)) goto lab1006; else goto lab1005;
lab1005:
  var298 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1006;
lab1006:
  frame = var298;
  goto lab1007;
lab1007:
  INS_HOOK_W(148);
  var299 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var299;
  *H = var299;
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1008:
  INS_HOOK_W(149);
  var301 = Tagp(0, H);
  var300 = var301;
  *H = var301;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1009; else goto lab1010;
lab1009:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1010;
lab1010:
  Yb(POp(uint16_t, 2)) = var300;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1011:
  INS_HOOK_W(150);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1012:
  INS_HOOK_W(151);
  var302 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var302, goto lab1013;, goto lab1016;);
lab1013:
  var303 = var302;
  if (CondSVA(var303)) goto lab1014; else goto lab1015;
lab1014:
  trail_push_check(w, var303);
  goto lab1015;
lab1015:
  *TagpPtr(2, var303) = Tagp(0, H);
  var302 = Tagp(0, H);
  goto lab1016;
lab1016:
  *H = var302;
  H = H + 1;
  P = Poff(4);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1017:
  INS_HOOK_W(152);
  *H = POp(uint32_t, 4);
  H = H + 1;
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1018:
  INS_HOOK_W(153);
  *H = POp(uint32_t, 2);
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1019:
  INS_HOOK_W(154);
  P = Poff(2);
  goto lab1020;
lab1020:
  INS_HOOK_W(155);
  var304 = H;
  H = HeapCharOffset(H, 1 * 4);
  G->heap_top = H;
  *var304 = MakeBlob((uint32_t *)&POp(uint32_t, 2));
  P = Poff(6 + BlobFunctorSizeAligned(POp(uint32_t, 2)));
  COMPUTED_GOTO(var0[BCOp(P, uint16_t, 0)]);
lab1021:
  INS_HOOK_W(156);
  *H = Tagp(7, HeapCharOffset(H, 1 * 4));
  H = H + 1;
  *H = POp(uint32_t, 4);
  H = H + 1;
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1022:
  INS_HOOK_W(157);
  *H = Tagp(7, HeapCharOffset(H, 1 * 4));
  H = H + 1;
  *H = POp(uint32_t, 2);
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1023:
  INS_HOOK_W(158);
  *H = atom_nil;
  H = H + 1;
  P = Poff(2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1024:
  INS_HOOK_W(159);
  *H = Tagp(6, HeapCharOffset(H, 1 * 4));
  H = H + 1;
  P = Poff(2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1025:
  INS_HOOK_W(160);
  *H = POp(uint32_t, 4);
  H = H + 1;
  goto lab1338;
lab1026:
  INS_HOOK_W(161);
  *H = POp(uint32_t, 2);
  H = H + 1;
  goto lab1338;
lab1027:
  INS_HOOK_W(162);
  *H = atom_nil;
  H = H + 1;
  goto lab1338;
lab1028:
  INS_HOOK_W(163);
  var305 = POp(uint16_t, 2);
  goto lab1029;
lab1029:
  *H = Tagp(0, H);
  H = H + 1;
  var305 = var305 - 1;
  if (var305 != 0) goto lab1029; else goto lab1030;
lab1030:
  var306 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var306;
  *H = var306;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1031:
  INS_HOOK_W(164);
  if (ValidLocalTop()) goto lab1032; else goto lab1033;
lab1032:
  var307 = G->local_top;
  goto lab1035;
lab1033:
  var307 = w->choice->local_top;
  if (StackYounger(var307, G->frame)) goto lab1035; else goto lab1034;
lab1034:
  var307 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1035;
lab1035:
  frame = var307;
  goto lab1036;
lab1036:
  INS_HOOK_W(165);
  var308 = POp(uint16_t, 2);
  goto lab1037;
lab1037:
  *H = Tagp(0, H);
  H = H + 1;
  var308 = var308 - 1;
  if (var308 != 0) goto lab1037; else goto lab1038;
lab1038:
  var309 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var309;
  *H = var309;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1039:
  INS_HOOK_W(166);
  var310 = POp(uint16_t, 2);
  goto lab1040;
lab1040:
  *H = Tagp(0, H);
  H = H + 1;
  var310 = var310 - 1;
  if (var310 != 0) goto lab1040; else goto lab1041;
lab1041:
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1042:
  INS_HOOK_W(167);
  var311 = POp(uint16_t, 2);
  goto lab1043;
lab1043:
  *H = Tagp(0, H);
  H = H + 1;
  var311 = var311 - 1;
  if (var311 != 0) goto lab1043; else goto lab1044;
lab1044:
  var312 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var312, goto lab1045;, goto lab1048;);
lab1045:
  var313 = var312;
  if (CondSVA(var313)) goto lab1046; else goto lab1047;
lab1046:
  trail_push_check(w, var313);
  goto lab1047;
lab1047:
  *TagpPtr(2, var313) = Tagp(0, H);
  var312 = Tagp(0, H);
  goto lab1048;
lab1048:
  *H = var312;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1049:
  INS_HOOK_W(168);
  var314 = POp(uint16_t, 2);
  goto lab1050;
lab1050:
  *H = Tagp(0, H);
  H = H + 1;
  var314 = var314 - 1;
  if (var314 != 0) goto lab1050; else goto lab1051;
lab1051:
  var316 = Tagp(0, H);
  var315 = var316;
  *H = var316;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1052; else goto lab1053;
lab1052:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1053;
lab1053:
  Yb(POp(uint16_t, 4)) = var315;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1054:
  INS_HOOK_W(169);
  var317 = POp(uint16_t, 2);
  goto lab1055;
lab1055:
  *H = Tagp(0, H);
  H = H + 1;
  var317 = var317 - 1;
  if (var317 != 0) goto lab1055; else goto lab1056;
lab1056:
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1057:
  INS_HOOK_W(170);
  var318 = POp(uint16_t, 2);
  goto lab1058;
lab1058:
  *H = Tagp(0, H);
  H = H + 1;
  var318 = var318 - 1;
  if (var318 != 0) goto lab1058; else goto lab1059;
lab1059:
  var319 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var319, goto lab1060;, goto lab1063;);
lab1060:
  var320 = var319;
  if (CondSVA(var320)) goto lab1061; else goto lab1062;
lab1061:
  trail_push_check(w, var320);
  goto lab1062;
lab1062:
  *TagpPtr(2, var320) = Tagp(0, H);
  var319 = Tagp(0, H);
  goto lab1063;
lab1063:
  *H = var319;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1064:
  INS_HOOK_W(171);
  var321 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var321;
  *H = var321;
  H = H + 1;
  var322 = POp(uint16_t, 4);
  goto lab1065;
lab1065:
  *H = Tagp(0, H);
  H = H + 1;
  var322 = var322 - 1;
  if (var322 != 0) goto lab1065; else goto lab1066;
lab1066:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1067:
  INS_HOOK_W(172);
  var323 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var323;
  *H = var323;
  H = H + 1;
  var324 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var324;
  *H = var324;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1068:
  INS_HOOK_W(173);
  if (ValidLocalTop()) goto lab1069; else goto lab1070;
lab1069:
  var325 = G->local_top;
  goto lab1072;
lab1070:
  var325 = w->choice->local_top;
  if (StackYounger(var325, G->frame)) goto lab1072; else goto lab1071;
lab1071:
  var325 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1072;
lab1072:
  frame = var325;
  goto lab1073;
lab1073:
  INS_HOOK_W(174);
  var326 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var326;
  *H = var326;
  H = H + 1;
  var327 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var327;
  *H = var327;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1074:
  INS_HOOK_W(175);
  var328 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var328;
  *H = var328;
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1075:
  INS_HOOK_W(176);
  var329 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var329;
  *H = var329;
  H = H + 1;
  var330 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var330, goto lab1076;, goto lab1079;);
lab1076:
  var331 = var330;
  if (CondSVA(var331)) goto lab1077; else goto lab1078;
lab1077:
  trail_push_check(w, var331);
  goto lab1078;
lab1078:
  *TagpPtr(2, var331) = Tagp(0, H);
  var330 = Tagp(0, H);
  goto lab1079;
lab1079:
  *H = var330;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1080:
  INS_HOOK_W(177);
  var332 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var332;
  *H = var332;
  H = H + 1;
  var334 = Tagp(0, H);
  var333 = var334;
  *H = var334;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1081; else goto lab1082;
lab1081:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1082;
lab1082:
  Yb(POp(uint16_t, 4)) = var333;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1083:
  INS_HOOK_W(178);
  var335 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var335;
  *H = var335;
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1084:
  INS_HOOK_W(179);
  var336 = Tagp(0, H);
  Xb(POp(uint16_t, 2)) = var336;
  *H = var336;
  H = H + 1;
  var337 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var337, goto lab1085;, goto lab1088;);
lab1085:
  var338 = var337;
  if (CondSVA(var338)) goto lab1086; else goto lab1087;
lab1086:
  trail_push_check(w, var338);
  goto lab1087;
lab1087:
  *TagpPtr(2, var338) = Tagp(0, H);
  var337 = Tagp(0, H);
  goto lab1088;
lab1088:
  *H = var337;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1089:
  INS_HOOK_W(180);
  if (ValidLocalTop()) goto lab1090; else goto lab1091;
lab1090:
  var339 = G->local_top;
  goto lab1093;
lab1091:
  var339 = w->choice->local_top;
  if (StackYounger(var339, G->frame)) goto lab1093; else goto lab1092;
lab1092:
  var339 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1093;
lab1093:
  frame = var339;
  goto lab1094;
lab1094:
  INS_HOOK_W(181);
  var340 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var340;
  *H = var340;
  H = H + 1;
  var341 = POp(uint16_t, 4);
  goto lab1095;
lab1095:
  *H = Tagp(0, H);
  H = H + 1;
  var341 = var341 - 1;
  if (var341 != 0) goto lab1095; else goto lab1096;
lab1096:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1097:
  INS_HOOK_W(182);
  if (ValidLocalTop()) goto lab1098; else goto lab1099;
lab1098:
  var342 = G->local_top;
  goto lab1101;
lab1099:
  var342 = w->choice->local_top;
  if (StackYounger(var342, G->frame)) goto lab1101; else goto lab1100;
lab1100:
  var342 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1101;
lab1101:
  frame = var342;
  goto lab1102;
lab1102:
  INS_HOOK_W(183);
  var343 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var343;
  *H = var343;
  H = H + 1;
  var344 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var344;
  *H = var344;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1103:
  INS_HOOK_W(184);
  if (ValidLocalTop()) goto lab1104; else goto lab1105;
lab1104:
  var345 = G->local_top;
  goto lab1107;
lab1105:
  var345 = w->choice->local_top;
  if (StackYounger(var345, G->frame)) goto lab1107; else goto lab1106;
lab1106:
  var345 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1107;
lab1107:
  frame = var345;
  goto lab1108;
lab1108:
  INS_HOOK_W(185);
  var346 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var346;
  *H = var346;
  H = H + 1;
  var347 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var347;
  *H = var347;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1109:
  INS_HOOK_W(186);
  if (ValidLocalTop()) goto lab1110; else goto lab1111;
lab1110:
  var348 = G->local_top;
  goto lab1113;
lab1111:
  var348 = w->choice->local_top;
  if (StackYounger(var348, G->frame)) goto lab1113; else goto lab1112;
lab1112:
  var348 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1113;
lab1113:
  frame = var348;
  goto lab1119;
lab1114:
  INS_HOOK_W(187);
  if (ValidLocalTop()) goto lab1115; else goto lab1116;
lab1115:
  var349 = G->local_top;
  goto lab1118;
lab1116:
  var349 = w->choice->local_top;
  if (StackYounger(var349, G->frame)) goto lab1118; else goto lab1117;
lab1117:
  var349 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1118;
lab1118:
  frame = var349;
  goto lab1120;
lab1119:
  INS_HOOK_W(188);
  var350 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var350;
  *H = var350;
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1120:
  INS_HOOK_W(189);
  var351 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var351;
  *H = var351;
  H = H + 1;
  var352 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var352, goto lab1121;, goto lab1124;);
lab1121:
  var353 = var352;
  if (CondSVA(var353)) goto lab1122; else goto lab1123;
lab1122:
  trail_push_check(w, var353);
  goto lab1123;
lab1123:
  *TagpPtr(2, var353) = Tagp(0, H);
  var352 = Tagp(0, H);
  goto lab1124;
lab1124:
  *H = var352;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1125:
  INS_HOOK_W(190);
  if (ValidLocalTop()) goto lab1126; else goto lab1127;
lab1126:
  var354 = G->local_top;
  goto lab1129;
lab1127:
  var354 = w->choice->local_top;
  if (StackYounger(var354, G->frame)) goto lab1129; else goto lab1128;
lab1128:
  var354 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1129;
lab1129:
  frame = var354;
  goto lab1135;
lab1130:
  INS_HOOK_W(191);
  if (ValidLocalTop()) goto lab1131; else goto lab1132;
lab1131:
  var355 = G->local_top;
  goto lab1134;
lab1132:
  var355 = w->choice->local_top;
  if (StackYounger(var355, G->frame)) goto lab1134; else goto lab1133;
lab1133:
  var355 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1134;
lab1134:
  frame = var355;
  goto lab1136;
lab1135:
  INS_HOOK_W(192);
  var356 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var356;
  *H = var356;
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1136:
  INS_HOOK_W(193);
  var357 = Tagp(0, H);
  Yb(POp(uint16_t, 2)) = var357;
  *H = var357;
  H = H + 1;
  var358 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var358, goto lab1137;, goto lab1140;);
lab1137:
  var359 = var358;
  if (CondSVA(var359)) goto lab1138; else goto lab1139;
lab1138:
  trail_push_check(w, var359);
  goto lab1139;
lab1139:
  *TagpPtr(2, var359) = Tagp(0, H);
  var358 = Tagp(0, H);
  goto lab1140;
lab1140:
  *H = var358;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1141:
  INS_HOOK_W(194);
  var361 = Tagp(0, H);
  var360 = var361;
  *H = var361;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1142; else goto lab1143;
lab1142:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1143;
lab1143:
  Yb(POp(uint16_t, 2)) = var360;
  var362 = POp(uint16_t, 4);
  goto lab1144;
lab1144:
  *H = Tagp(0, H);
  H = H + 1;
  var362 = var362 - 1;
  if (var362 != 0) goto lab1144; else goto lab1145;
lab1145:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1146:
  INS_HOOK_W(195);
  var364 = Tagp(0, H);
  var363 = var364;
  *H = var364;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1147; else goto lab1148;
lab1147:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1148;
lab1148:
  Yb(POp(uint16_t, 2)) = var363;
  var365 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var365;
  *H = var365;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1149:
  INS_HOOK_W(196);
  var367 = Tagp(0, H);
  var366 = var367;
  *H = var367;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1150; else goto lab1151;
lab1150:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1151;
lab1151:
  Yb(POp(uint16_t, 2)) = var366;
  var369 = Tagp(0, H);
  var368 = var369;
  *H = var369;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1152; else goto lab1153;
lab1152:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1153;
lab1153:
  Yb(POp(uint16_t, 4)) = var368;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1154:
  INS_HOOK_W(197);
  var371 = Tagp(0, H);
  var370 = var371;
  *H = var371;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1155; else goto lab1156;
lab1155:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1156;
lab1156:
  Yb(POp(uint16_t, 2)) = var370;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1157:
  INS_HOOK_W(198);
  var373 = Tagp(0, H);
  var372 = var373;
  *H = var373;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1158; else goto lab1159;
lab1158:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1159;
lab1159:
  Yb(POp(uint16_t, 2)) = var372;
  var374 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var374, goto lab1160;, goto lab1163;);
lab1160:
  var375 = var374;
  if (CondSVA(var375)) goto lab1161; else goto lab1162;
lab1161:
  trail_push_check(w, var375);
  goto lab1162;
lab1162:
  *TagpPtr(2, var375) = Tagp(0, H);
  var374 = Tagp(0, H);
  goto lab1163;
lab1163:
  *H = var374;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1164:
  INS_HOOK_W(199);
  var377 = Tagp(0, H);
  var376 = var377;
  *H = var377;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1165; else goto lab1166;
lab1165:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1166;
lab1166:
  Yb(POp(uint16_t, 2)) = var376;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1167:
  INS_HOOK_W(200);
  var379 = Tagp(0, H);
  var378 = var379;
  *H = var379;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 2)))) goto lab1168; else goto lab1169;
lab1168:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 2))));
  goto lab1169;
lab1169:
  Yb(POp(uint16_t, 2)) = var378;
  var380 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var380, goto lab1170;, goto lab1173;);
lab1170:
  var381 = var380;
  if (CondSVA(var381)) goto lab1171; else goto lab1172;
lab1171:
  trail_push_check(w, var381);
  goto lab1172;
lab1172:
  *TagpPtr(2, var381) = Tagp(0, H);
  var380 = Tagp(0, H);
  goto lab1173;
lab1173:
  *H = var380;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1174:
  INS_HOOK_W(201);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var382 = POp(uint16_t, 4);
  goto lab1175;
lab1175:
  *H = Tagp(0, H);
  H = H + 1;
  var382 = var382 - 1;
  if (var382 != 0) goto lab1175; else goto lab1176;
lab1176:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1177:
  INS_HOOK_W(202);
  var383 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var383, goto lab1178;, goto lab1181;);
lab1178:
  var384 = var383;
  if (CondSVA(var384)) goto lab1179; else goto lab1180;
lab1179:
  trail_push_check(w, var384);
  goto lab1180;
lab1180:
  *TagpPtr(2, var384) = Tagp(0, H);
  var383 = Tagp(0, H);
  goto lab1181;
lab1181:
  *H = var383;
  H = H + 1;
  var385 = POp(uint16_t, 4);
  goto lab1182;
lab1182:
  *H = Tagp(0, H);
  H = H + 1;
  var385 = var385 - 1;
  if (var385 != 0) goto lab1182; else goto lab1183;
lab1183:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1184:
  INS_HOOK_W(203);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var386 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var386;
  *H = var386;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1185:
  INS_HOOK_W(204);
  var387 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var387, goto lab1186;, goto lab1189;);
lab1186:
  var388 = var387;
  if (CondSVA(var388)) goto lab1187; else goto lab1188;
lab1187:
  trail_push_check(w, var388);
  goto lab1188;
lab1188:
  *TagpPtr(2, var388) = Tagp(0, H);
  var387 = Tagp(0, H);
  goto lab1189;
lab1189:
  *H = var387;
  H = H + 1;
  var389 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var389;
  *H = var389;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1190:
  INS_HOOK_W(205);
  if (ValidLocalTop()) goto lab1191; else goto lab1192;
lab1191:
  var390 = G->local_top;
  goto lab1194;
lab1192:
  var390 = w->choice->local_top;
  if (StackYounger(var390, G->frame)) goto lab1194; else goto lab1193;
lab1193:
  var390 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1194;
lab1194:
  frame = var390;
  goto lab1200;
lab1195:
  INS_HOOK_W(206);
  if (ValidLocalTop()) goto lab1196; else goto lab1197;
lab1196:
  var391 = G->local_top;
  goto lab1199;
lab1197:
  var391 = w->choice->local_top;
  if (StackYounger(var391, G->frame)) goto lab1199; else goto lab1198;
lab1198:
  var391 = StackCharOffset(G->frame, FrameSize(G->next_insn));
  goto lab1199;
lab1199:
  frame = var391;
  goto lab1201;
lab1200:
  INS_HOOK_W(207);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var392 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var392;
  *H = var392;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1201:
  INS_HOOK_W(208);
  var393 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var393, goto lab1202;, goto lab1205;);
lab1202:
  var394 = var393;
  if (CondSVA(var394)) goto lab1203; else goto lab1204;
lab1203:
  trail_push_check(w, var394);
  goto lab1204;
lab1204:
  *TagpPtr(2, var394) = Tagp(0, H);
  var393 = Tagp(0, H);
  goto lab1205;
lab1205:
  *H = var393;
  H = H + 1;
  var395 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var395;
  *H = var395;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1206:
  INS_HOOK_W(209);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1207:
  INS_HOOK_W(210);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var396 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var396, goto lab1208;, goto lab1211;);
lab1208:
  var397 = var396;
  if (CondSVA(var397)) goto lab1209; else goto lab1210;
lab1209:
  trail_push_check(w, var397);
  goto lab1210;
lab1210:
  *TagpPtr(2, var397) = Tagp(0, H);
  var396 = Tagp(0, H);
  goto lab1211;
lab1211:
  *H = var396;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1212:
  INS_HOOK_W(211);
  var398 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var398, goto lab1213;, goto lab1216;);
lab1213:
  var399 = var398;
  if (CondSVA(var399)) goto lab1214; else goto lab1215;
lab1214:
  trail_push_check(w, var399);
  goto lab1215;
lab1215:
  *TagpPtr(2, var399) = Tagp(0, H);
  var398 = Tagp(0, H);
  goto lab1216;
lab1216:
  *H = var398;
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1217:
  INS_HOOK_W(212);
  var400 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var400, goto lab1218;, goto lab1221;);
lab1218:
  var401 = var400;
  if (CondSVA(var401)) goto lab1219; else goto lab1220;
lab1219:
  trail_push_check(w, var401);
  goto lab1220;
lab1220:
  *TagpPtr(2, var401) = Tagp(0, H);
  var400 = Tagp(0, H);
  goto lab1221;
lab1221:
  *H = var400;
  H = H + 1;
  var402 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var402, goto lab1222;, goto lab1225;);
lab1222:
  var403 = var402;
  if (CondSVA(var403)) goto lab1223; else goto lab1224;
lab1223:
  trail_push_check(w, var403);
  goto lab1224;
lab1224:
  *TagpPtr(2, var403) = Tagp(0, H);
  var402 = Tagp(0, H);
  goto lab1225;
lab1225:
  *H = var402;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1226:
  INS_HOOK_W(213);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var405 = Tagp(0, H);
  var404 = var405;
  *H = var405;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1227; else goto lab1228;
lab1227:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1228;
lab1228:
  Yb(POp(uint16_t, 4)) = var404;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1229:
  INS_HOOK_W(214);
  var406 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var406, goto lab1230;, goto lab1233;);
lab1230:
  var407 = var406;
  if (CondSVA(var407)) goto lab1231; else goto lab1232;
lab1231:
  trail_push_check(w, var407);
  goto lab1232;
lab1232:
  *TagpPtr(2, var407) = Tagp(0, H);
  var406 = Tagp(0, H);
  goto lab1233;
lab1233:
  *H = var406;
  H = H + 1;
  var409 = Tagp(0, H);
  var408 = var409;
  *H = var409;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1234; else goto lab1235;
lab1234:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1235;
lab1235:
  Yb(POp(uint16_t, 4)) = var408;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1236:
  INS_HOOK_W(215);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1237:
  INS_HOOK_W(216);
  *H = Xb(POp(uint16_t, 2));
  H = H + 1;
  var410 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var410, goto lab1238;, goto lab1241;);
lab1238:
  var411 = var410;
  if (CondSVA(var411)) goto lab1239; else goto lab1240;
lab1239:
  trail_push_check(w, var411);
  goto lab1240;
lab1240:
  *TagpPtr(2, var411) = Tagp(0, H);
  var410 = Tagp(0, H);
  goto lab1241;
lab1241:
  *H = var410;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1242:
  INS_HOOK_W(217);
  var412 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var412, goto lab1243;, goto lab1246;);
lab1243:
  var413 = var412;
  if (CondSVA(var413)) goto lab1244; else goto lab1245;
lab1244:
  trail_push_check(w, var413);
  goto lab1245;
lab1245:
  *TagpPtr(2, var413) = Tagp(0, H);
  var412 = Tagp(0, H);
  goto lab1246;
lab1246:
  *H = var412;
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1247:
  INS_HOOK_W(218);
  var414 = Xb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var414, goto lab1248;, goto lab1251;);
lab1248:
  var415 = var414;
  if (CondSVA(var415)) goto lab1249; else goto lab1250;
lab1249:
  trail_push_check(w, var415);
  goto lab1250;
lab1250:
  *TagpPtr(2, var415) = Tagp(0, H);
  var414 = Tagp(0, H);
  goto lab1251;
lab1251:
  *H = var414;
  H = H + 1;
  var416 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var416, goto lab1252;, goto lab1255;);
lab1252:
  var417 = var416;
  if (CondSVA(var417)) goto lab1253; else goto lab1254;
lab1253:
  trail_push_check(w, var417);
  goto lab1254;
lab1254:
  *TagpPtr(2, var417) = Tagp(0, H);
  var416 = Tagp(0, H);
  goto lab1255;
lab1255:
  *H = var416;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1256:
  INS_HOOK_W(219);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var418 = POp(uint16_t, 4);
  goto lab1257;
lab1257:
  *H = Tagp(0, H);
  H = H + 1;
  var418 = var418 - 1;
  if (var418 != 0) goto lab1257; else goto lab1258;
lab1258:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1259:
  INS_HOOK_W(220);
  var419 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var419, goto lab1260;, goto lab1263;);
lab1260:
  var420 = var419;
  if (CondSVA(var420)) goto lab1261; else goto lab1262;
lab1261:
  trail_push_check(w, var420);
  goto lab1262;
lab1262:
  *TagpPtr(2, var420) = Tagp(0, H);
  var419 = Tagp(0, H);
  goto lab1263;
lab1263:
  *H = var419;
  H = H + 1;
  var421 = POp(uint16_t, 4);
  goto lab1264;
lab1264:
  *H = Tagp(0, H);
  H = H + 1;
  var421 = var421 - 1;
  if (var421 != 0) goto lab1264; else goto lab1265;
lab1265:
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1266:
  INS_HOOK_W(221);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var422 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var422;
  *H = var422;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1267:
  INS_HOOK_W(222);
  var423 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var423, goto lab1268;, goto lab1271;);
lab1268:
  var424 = var423;
  if (CondSVA(var424)) goto lab1269; else goto lab1270;
lab1269:
  trail_push_check(w, var424);
  goto lab1270;
lab1270:
  *TagpPtr(2, var424) = Tagp(0, H);
  var423 = Tagp(0, H);
  goto lab1271;
lab1271:
  *H = var423;
  H = H + 1;
  var425 = Tagp(0, H);
  Xb(POp(uint16_t, 4)) = var425;
  *H = var425;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1272:
  INS_HOOK_W(223);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var426 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var426;
  *H = var426;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1273:
  INS_HOOK_W(224);
  var427 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var427, goto lab1274;, goto lab1277;);
lab1274:
  var428 = var427;
  if (CondSVA(var428)) goto lab1275; else goto lab1276;
lab1275:
  trail_push_check(w, var428);
  goto lab1276;
lab1276:
  *TagpPtr(2, var428) = Tagp(0, H);
  var427 = Tagp(0, H);
  goto lab1277;
lab1277:
  *H = var427;
  H = H + 1;
  var429 = Tagp(0, H);
  Yb(POp(uint16_t, 4)) = var429;
  *H = var429;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1278:
  INS_HOOK_W(225);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var431 = Tagp(0, H);
  var430 = var431;
  *H = var431;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1279; else goto lab1280;
lab1279:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1280;
lab1280:
  Yb(POp(uint16_t, 4)) = var430;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1281:
  INS_HOOK_W(226);
  var432 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var432, goto lab1282;, goto lab1285;);
lab1282:
  var433 = var432;
  if (CondSVA(var433)) goto lab1283; else goto lab1284;
lab1283:
  trail_push_check(w, var433);
  goto lab1284;
lab1284:
  *TagpPtr(2, var433) = Tagp(0, H);
  var432 = Tagp(0, H);
  goto lab1285;
lab1285:
  *H = var432;
  H = H + 1;
  var435 = Tagp(0, H);
  var434 = var435;
  *H = var435;
  H = H + 1;
  if (CondSVA(Yb(POp(uint16_t, 4)))) goto lab1286; else goto lab1287;
lab1286:
  trail_push_check(w, Tagp(2, &Yb(POp(uint16_t, 4))));
  goto lab1287;
lab1287:
  Yb(POp(uint16_t, 4)) = var434;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1288:
  INS_HOOK_W(227);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1289:
  INS_HOOK_W(228);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var436 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var436, goto lab1290;, goto lab1293;);
lab1290:
  var437 = var436;
  if (CondSVA(var437)) goto lab1291; else goto lab1292;
lab1291:
  trail_push_check(w, var437);
  goto lab1292;
lab1292:
  *TagpPtr(2, var437) = Tagp(0, H);
  var436 = Tagp(0, H);
  goto lab1293;
lab1293:
  *H = var436;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1294:
  INS_HOOK_W(229);
  var438 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var438, goto lab1295;, goto lab1298;);
lab1295:
  var439 = var438;
  if (CondSVA(var439)) goto lab1296; else goto lab1297;
lab1296:
  trail_push_check(w, var439);
  goto lab1297;
lab1297:
  *TagpPtr(2, var439) = Tagp(0, H);
  var438 = Tagp(0, H);
  goto lab1298;
lab1298:
  *H = var438;
  H = H + 1;
  *H = Xb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1299:
  INS_HOOK_W(230);
  var440 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var440, goto lab1300;, goto lab1303;);
lab1300:
  var441 = var440;
  if (CondSVA(var441)) goto lab1301; else goto lab1302;
lab1301:
  trail_push_check(w, var441);
  goto lab1302;
lab1302:
  *TagpPtr(2, var441) = Tagp(0, H);
  var440 = Tagp(0, H);
  goto lab1303;
lab1303:
  *H = var440;
  H = H + 1;
  var442 = Xb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var442, goto lab1304;, goto lab1307;);
lab1304:
  var443 = var442;
  if (CondSVA(var443)) goto lab1305; else goto lab1306;
lab1305:
  trail_push_check(w, var443);
  goto lab1306;
lab1306:
  *TagpPtr(2, var443) = Tagp(0, H);
  var442 = Tagp(0, H);
  goto lab1307;
lab1307:
  *H = var442;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1308:
  INS_HOOK_W(231);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1309:
  INS_HOOK_W(232);
  *H = Yb(POp(uint16_t, 2));
  H = H + 1;
  var444 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var444, goto lab1310;, goto lab1313;);
lab1310:
  var445 = var444;
  if (CondSVA(var445)) goto lab1311; else goto lab1312;
lab1311:
  trail_push_check(w, var445);
  goto lab1312;
lab1312:
  *TagpPtr(2, var445) = Tagp(0, H);
  var444 = Tagp(0, H);
  goto lab1313;
lab1313:
  *H = var444;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1314:
  INS_HOOK_W(233);
  var446 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var446, goto lab1315;, goto lab1318;);
lab1315:
  var447 = var446;
  if (CondSVA(var447)) goto lab1316; else goto lab1317;
lab1316:
  trail_push_check(w, var447);
  goto lab1317;
lab1317:
  *TagpPtr(2, var447) = Tagp(0, H);
  var446 = Tagp(0, H);
  goto lab1318;
lab1318:
  *H = var446;
  H = H + 1;
  *H = Yb(POp(uint16_t, 4));
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1319:
  INS_HOOK_W(234);
  var448 = Yb(POp(uint16_t, 2));
  DerefUpToSVA_Sw_SVA_Other(var448, goto lab1320;, goto lab1323;);
lab1320:
  var449 = var448;
  if (CondSVA(var449)) goto lab1321; else goto lab1322;
lab1321:
  trail_push_check(w, var449);
  goto lab1322;
lab1322:
  *TagpPtr(2, var449) = Tagp(0, H);
  var448 = Tagp(0, H);
  goto lab1323;
lab1323:
  *H = var448;
  H = H + 1;
  var450 = Yb(POp(uint16_t, 4));
  DerefUpToSVA_Sw_SVA_Other(var450, goto lab1324;, goto lab1327;);
lab1324:
  var451 = var450;
  if (CondSVA(var451)) goto lab1325; else goto lab1326;
lab1325:
  trail_push_check(w, var451);
  goto lab1326;
lab1326:
  *TagpPtr(2, var451) = Tagp(0, H);
  var450 = Tagp(0, H);
  goto lab1327;
lab1327:
  *H = var450;
  H = H + 1;
  P = Poff(6);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1328:
  INS_HOOK_W(235);
  COMPUTED_GOTO(var1[BCOp(FAIL_INSNP, uint16_t, 0)]);
lab1329:
  INS_HOOK_W(236);
  P = Poff(2);
  goto lab1330;
lab1330:
  INS_HOOK_W(237);
  TEST_HEAP_OVERFLOW(H, POp(uint32_t, 2), POp(uint16_t, 6));
  P = Poff(8);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1331:
  INS_HOOK_W(238);
  if (IsDeep()) goto lab1337; else goto lab1332;
lab1332:
  if (IsShallowTry()) goto lab1333; else goto lab1336;
lab1333:
  var452 = w->choice;
  var452->frame = G->frame;
  var452->next_insn = G->next_insn;
  var452->next_alt = G->next_alt;
  var453 = ChoiceArity(var452);
  var454 = 0;
  goto lab1334;
lab1334:
  if (var454 < var453) goto lab1335; else goto lab1336;
lab1335:
  var452->x[var454] = G->x[var454];
  var454 = var454 + 1;
  goto lab1334;
lab1336:
  frame = G->local_top;
  SetDeep();
  goto lab1337;
lab1337:
  P = Poff(2);
  COMPUTED_GOTO(var1[BCOp(P, uint16_t, 0)]);
lab1338:
  INS_HOOK_W(239);
  G->heap_top = H;
  goto lab506;
lab1339:
  INS_HOOK_W(240);
  G->heap_top = H;
  goto lab513;
lab1340:
  INS_HOOK_W(241);
  G->heap_top = H;
  goto lab514;
lab1341:
  INS_HOOK_W(242);
  G->heap_top = H;
  goto lab515;
lab1342:
  INS_HOOK_W(243);
  G->heap_top = H;
  goto lab531;
lab1343:
  INS_HOOK_W(244);
  G->heap_top = H;
  goto lab547;
lab1344:
  INS_HOOK_W(245);
  G->heap_top = H;
  goto lab548;
lab1345:
  INS_HOOK_W(246);
  G->heap_top = H;
  goto lab553;
lab1346:
  INS_HOOK_W(247);
  G->heap_top = H;
  goto lab558;
lab1347:
  INS_HOOK_W(248);
  G->heap_top = H;
  goto lab563;
lab1348:
  INS_HOOK_W(249);
  G->heap_top = H;
  goto lab568;
lab1349:
  INS_HOOK_W(250);
  G->heap_top = H;
  goto lab573;
lab1350:
  INS_HOOK_W(251);
  G->heap_top = H;
  goto lab584;
lab1351:
  INS_HOOK_W(252);
  G->heap_top = H;
  goto lab595;
lab1352:
  w->insn = P;
  return;
}
bool_t prolog_repeat(worker_t *);
bool_t metachoice(worker_t *);
bool_t metacut(worker_t *);
bool_t bu1_if(worker_t *, uint32_t);
bool_t disasm(worker_t *);
bool_t dectok(worker_t *);
void basiccontrol__init(worker_t *w) {
  atm_var = GET_ATOM("var");
  atm_attv = GET_ATOM("attv");
  atm_float = GET_ATOM("float");
  atm_int = GET_ATOM("integer");
  atm_str = GET_ATOM("structure");
  atm_atm = GET_ATOM("atom");
  atm_lst = GET_ATOM("list");
  atom_success = GET_ATOM("success");
  atom_failure = GET_ATOM("failure");
  atom_share = GET_ATOM("share");
  atom_noshare = GET_ATOM("noshare");
  atom_user_input = GET_ATOM("user_input");
  atom_user_output = GET_ATOM("user_output");
  atom_user_error = GET_ATOM("user_error");
  atom_read = GET_ATOM("read");
  atom_write = GET_ATOM("write");
  atom_append = GET_ATOM("append");
  atom_socket = GET_ATOM("socket");
  atom_symlink = GET_ATOM("symlink");
  atom_regular = GET_ATOM("regular");
  atom_directory = GET_ATOM("directory");
  atom_fifo = GET_ATOM("fifo");
  atom_unknown = GET_ATOM("unknown");
  atom_user = GET_ATOM("user");
  atom_prolog = GET_ATOM("prolog");
  atom_lessthan = GET_ATOM("<");
  atom_greaterthan = GET_ATOM(">");
  atom_equal = GET_ATOM("=");
  atom_lst = GET_ATOM(".");
  atom_nil = GET_ATOM("[]");
  atom_on = GET_ATOM("on");
  atom_off = GET_ATOM("off");
  atom_error = GET_ATOM("error");
  atom_trace = GET_ATOM("trace");
  atom_debug = GET_ATOM("debug");
  atom_fail = GET_ATOM("fail");
  atom_all = GET_ATOM("all");
  atom_terse = GET_ATOM("terse");
  atom_verbose = GET_ATOM("verbose");
  atom_compiled = GET_ATOM("compiled");
  atom_interpreted = GET_ATOM("interpreted");
  atom_builtin = GET_ATOM("built_in");
  atom_true = GET_ATOM("true");
  atom_basiccontroltrue = GET_ATOM("basiccontrol:true");
  atom_retry_hook = GET_ATOM("$$retry_hook");
  atom_unprofiled = GET_ATOM("unprofiled");
  atom_profiled = GET_ATOM("profiled");
  atom_concurrent = GET_ATOM("concurrent");
  atom_wait = GET_ATOM("wait");
  atom_dynamic = GET_ATOM("dynamic");
  atom_multifile = GET_ATOM("multifile");
  atom_block = GET_ATOM("block");
  atom_no_block = GET_ATOM("no_block");
  atom_self = GET_ATOM("self");
  atom_create = GET_ATOM("create");
  atom_dash = GET_ATOM("-");
  basiccontrol__0 = register_cbool("basiccontrol:repeat", 0, prolog_repeat);
  register_builtin("basiccontrol:repeat", 0, prolog_repeat);
  basiccontrol__1 = register_cbool("basiccontrol:$metachoice", 1, metachoice);
  register_builtin("basiccontrol:$metachoice", 1, metachoice);
  basiccontrol__2 = register_cbool("basiccontrol:$metacut", 1, metacut);
  register_builtin("basiccontrol:$metacut", 1, metacut);
  register_builtin("basiccontrol:IF BUILTIN", 1, bu1_if);
  basiccontrol__3 = register_cbool("basiccontrol:$disasm", 1, disasm);
  register_builtin("basiccontrol:$disasm", 1, disasm);
  basiccontrol__4 = register_cbool("basiccontrol:$dectok", 1, dectok);
  register_builtin("basiccontrol:$dectok", 1, dectok);
}
void basiccontrol__end(worker_t *w) {
  unregister_cbool("basiccontrol:repeat", 0);
  unregister_cbool("basiccontrol:$metachoice", 1);
  unregister_cbool("basiccontrol:$metacut", 1);
  unregister_cbool("basiccontrol:$disasm", 1);
  unregister_cbool("basiccontrol:$dectok", 1);
}
