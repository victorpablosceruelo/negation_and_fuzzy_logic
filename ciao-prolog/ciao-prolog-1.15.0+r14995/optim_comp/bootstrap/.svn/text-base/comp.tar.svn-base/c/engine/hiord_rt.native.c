#include <engine/basiccontrol.native.h>
definition_t *hiord__rt__0;
definition_t *hiord__rt__1;
bcp_t code_call1(worker_t *);
bcp_t code_call1(worker_t *);
void hiord__rt__init(worker_t *w) {
  hiord__rt__0 = register_cinsnp("hiord_rt:call", 1, code_call1);
  set_defbits("hiord_rt:call", 1, 8);
  register_builtin("hiord_rt:call", 1, code_call1);
  hiord__rt__1 = register_cinsnp("hiord_rt:SYSCALL", 1, code_call1);
  register_builtin("hiord_rt:SYSCALL", 1, code_call1);
}
void hiord__rt__end(worker_t *w) {
  unregister_cinsnp("hiord_rt:call", 1);
  unregister_cinsnp("hiord_rt:SYSCALL", 1);
}
