#include <engine/basiccontrol.native.h>
definition_t *compiler__object____rt__0;
bool_t prolog_ooget2(worker_t *);
void compiler__object____rt__init(worker_t *w) {
  compiler__object____rt__0 = register_cbool("compiler_object__rt:obj_attr_unify", 3, prolog_ooget2);
  register_builtin("compiler_object__rt:obj_attr_unify", 3, prolog_ooget2);
}
void compiler__object____rt__end(worker_t *w) {
  unregister_cbool("compiler_object__rt:obj_attr_unify", 3);
}
