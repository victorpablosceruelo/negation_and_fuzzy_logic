#include <engine/basiccontrol.native.h>
void init_everything(worker_t *);
void terms__check__init(worker_t *);
void store__init(worker_t *);
void dynlink__init(worker_t *);
void concurrency__init(worker_t *);
void ql__inout__init(worker_t *);
void attributes__init(worker_t *);
void system__init(worker_t *);
void timing__init(worker_t *);
void prolog__sys__init(worker_t *);
void hiord__rt__init(worker_t *);
void term__compare__init(worker_t *);
void rt__exp__init(worker_t *);
void system__info__init(worker_t *);
void streams__basic__init(worker_t *);
void io__basic__init(worker_t *);
void exceptions__init(worker_t *);
void atomic__basic__init(worker_t *);
void internals__init(worker_t *);
void term__typing__init(worker_t *);
void term__basic__init(worker_t *);
void arithmetic__init(worker_t *);
void basiccontrol__init(worker_t *);
void compiler__object____rt__init(worker_t *);
void compiler__object____base__init(worker_t *);
void init_everything(worker_t *w) {
  terms__check__init(w);
  store__init(w);
  dynlink__init(w);
  concurrency__init(w);
  ql__inout__init(w);
  attributes__init(w);
  system__init(w);
  timing__init(w);
  prolog__sys__init(w);
  hiord__rt__init(w);
  term__compare__init(w);
  rt__exp__init(w);
  system__info__init(w);
  streams__basic__init(w);
  io__basic__init(w);
  exceptions__init(w);
  atomic__basic__init(w);
  internals__init(w);
  term__typing__init(w);
  term__basic__init(w);
  arithmetic__init(w);
  basiccontrol__init(w);
  compiler__object____rt__init(w);
  compiler__object____base__init(w);
  return;
}
void internal__init__init(worker_t *w) { }
void internal__init__end(worker_t *w) { }
