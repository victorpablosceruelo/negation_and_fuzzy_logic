#include <engine/basiccontrol.native.h>
definition_t *store__0;
bool_t prolog_list_to_path(worker_t *);
void store__init(worker_t *w) {
  store__0 = register_cbool("store:list_to_path", 5, prolog_list_to_path);
  register_builtin("store:list_to_path", 5, prolog_list_to_path);
}
void store__end(worker_t *w) {
  unregister_cbool("store:list_to_path", 5);
}
